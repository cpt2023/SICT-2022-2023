import 'package:flutter/material.dart';

import '../components/groups.dart';
import '../utils/app_colors.dart';

class PeoplesGroups extends StatefulWidget {
  const PeoplesGroups({super.key});

  @override
  State<PeoplesGroups> createState() => _PeoplesGroupsState();
}

class _PeoplesGroupsState extends State<PeoplesGroups> {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 10,
      itemBuilder: (BuildContext context, int index) {
        return Container(
          padding: const EdgeInsets.all(0),
          child: const Column(
            children: [
              Groups(),
              Padding(
                padding: EdgeInsets.only(left: 50, right: 15),
                child: Divider(
                  color: kTextColor,
                  thickness: 1,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
