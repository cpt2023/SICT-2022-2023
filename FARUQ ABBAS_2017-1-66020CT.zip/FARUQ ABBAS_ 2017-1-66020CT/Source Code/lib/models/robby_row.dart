import 'package:flutter/material.dart';

import '../utils/app_colors.dart';

class RobbyRow extends StatelessWidget {
  const RobbyRow({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListTile(
          leading: const CircleAvatar(
            radius: 20,
            child: Image(
              image: AssetImage("assets/cap.png"),
            ),
          ),
          title: const Text(
            "Robby",
            style: TextStyle(
                color: kTextColor, fontSize: 10, fontWeight: FontWeight.bold),
          ),
          subtitle: const Text(
            "Call of duty.2k followers",
            style: TextStyle(color: kTextColor, fontSize: 10),
          ),
          trailing: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kTabBarColor),
            onPressed: () {},
            child: const Text(
              "Unfollow",
              style: TextStyle(
                color: kTextColor,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
