import 'package:flutter/material.dart';

import '../utils/app_colors.dart';

class LockScreen extends StatefulWidget {
  const LockScreen({super.key});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  int pinLength = 4;
  List<String> pinEntered = List.filled(4, "");

  void numberClicked(int item) {
    for (int i = 0; i < pinLength; i++) {
      if (pinEntered[i] == "") {
        pinEntered[i] = item.toString();
        print(pinEntered);
        setState(() {});
        break; // Exit the loop after adding the number
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        backgroundColor: kBackgroundColor,
        leading: IconButton(
          onPressed: () {},
          icon: Icon(
            Icons.adaptive.arrow_back,
            color: kTextColor,
          ),
        ),
      ),
      body: SafeArea(
        child: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.only(left: 15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Enter your confirmation code",
                      style: TextStyle(
                        color: kTextColor,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "Enter the code sent to john@gmail.com",
                      style: TextStyle(
                        color: kTextColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(3),
                      child: Icon(
                        (pinEntered.isNotEmpty)
                            ? Icons.circle
                            : Icons.circle_outlined,
                        color: kPrimaryColor,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(3),
                      child: Icon(
                        (pinEntered.length >= 2)
                            ? Icons.circle
                            : Icons.circle_outlined,
                        color: kPrimaryColor,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(3),
                      child: Icon(
                        (pinEntered.length >= 3)
                            ? Icons.circle
                            : Icons.circle_outlined,
                        color: kPrimaryColor,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(3),
                      child: Icon(
                        (pinEntered.length == 4)
                            ? Icons.circle
                            : Icons.circle_outlined,
                        color: kPrimaryColor,
                      ),
                    ),
                  ],
                ),
              ),
              const Center(
                child: Text(
                  "Resend",
                  style: TextStyle(
                    color: kPrimaryColor,
                    fontSize: 16,
                  ),
                ),
              ),
              const SizedBox(
                height: 40,
              ),
              const Padding(
                padding: EdgeInsets.all(kDefaultPadding),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    NumberRow(
                      child: Text(
                        "1",
                        style: TextStyle(color: kTextColor),
                      ),
                    ),
                    NumberRow(
                      child: Text(
                        "2",
                        style: TextStyle(color: kTextColor),
                      ),
                    ),
                    NumberRow(
                      child: Text(
                        "3",
                        style: TextStyle(color: kTextColor),
                      ),
                    ),
                  ],
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(kDefaultPadding),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    NumberRow(
                      child: Text(
                        "4",
                        style: TextStyle(color: kTextColor),
                      ),
                    ),
                    NumberRow(
                      child: Text(
                        "5",
                        style: TextStyle(color: kTextColor),
                      ),
                    ),
                    NumberRow(
                      child: Text(
                        "6",
                        style: TextStyle(color: kTextColor),
                      ),
                    ),
                  ],
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(kDefaultPadding),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    NumberRow(
                      child: Text(
                        "7",
                        style: TextStyle(color: kTextColor),
                      ),
                    ),
                    NumberRow(
                      child: Text(
                        "8",
                        style: TextStyle(color: kTextColor),
                      ),
                    ),
                    NumberRow(
                      child: Text(
                        "9",
                        style: TextStyle(color: kTextColor),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                      width: 50,
                      height: 50,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: kBackgroundColor,
                      ),
                      child: null,
                    ),
                    Container(
                      width: 50,
                      height: 50,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: kTabBarColor,
                      ),
                      child: TextButton(
                        onPressed: () {},
                        child: const Text(
                          "0",
                          style: TextStyle(color: kTextColor),
                        ),
                      ),
                    ),
                    Container(
                      width: 50,
                      height: 50,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: kTabBarColor,
                      ),
                      child: IconButton(
                        onPressed: () {},
                        icon: const Icon(
                          Icons.backspace_outlined,
                          color: kTextColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class NumberRow extends StatelessWidget {
  final child;
  const NumberRow({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        var numberClicked = (int.parse(child));
      },
      child: Container(
        width: 50,
        height: 50,
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          color: kTabBarColor,
        ),
        child: TextButton(
          onPressed: () {},
          child: child,
        ),
      ),
    );
  }
}
