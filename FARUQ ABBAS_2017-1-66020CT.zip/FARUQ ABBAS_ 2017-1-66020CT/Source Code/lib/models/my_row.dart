import 'package:flutter/material.dart';

import '../utils/app_colors.dart';

class MyRow extends StatelessWidget {
  const MyRow({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListTile(
          leading: const CircleAvatar(
            radius: 20,
            child: Image(
              image: AssetImage("assets/cap.png"),
            ),
          ),
          title: const Text(
            "Droid Villaz",
            style: TextStyle(
                color: kTextColor, fontSize: 10, fontWeight: FontWeight.bold),
          ),
          subtitle: const Text(
            "Umar Farouk.2k followers",
            style: TextStyle(color: kTextColor, fontSize: 10),
          ),
          trailing: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kTabBarColor),
            onPressed: () {},
            child: const Text(
              "Unfollow",
              style: TextStyle(
                color: kTextColor,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
