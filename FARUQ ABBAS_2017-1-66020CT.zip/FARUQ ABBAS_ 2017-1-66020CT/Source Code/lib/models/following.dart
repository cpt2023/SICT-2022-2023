import 'package:flutter/material.dart';

import '../utils/app_colors.dart';
import 'my_row.dart';
import 'robby_row.dart';

class Following extends StatefulWidget {
  const Following({super.key});

  @override
  State<Following> createState() => _FollowingState();
}

class _FollowingState extends State<Following> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(
          height: 15,
        ),
        Row(
          children: [
            const SizedBox(
              width: 20,
            ),
            Expanded(
              child: TextFormField(
                style: const TextStyle(color: kTextColor),
                decoration: const InputDecoration(
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: kPrimaryColor)),
                  hintText: "Search Following",
                  hintStyle: TextStyle(color: kTextColor),
                  fillColor: kTabBarColor,
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: kTabBarColor),
                  ),
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                  color: kPrimaryColor, borderRadius: BorderRadius.circular(4)),
              width: 50,
              height: 50,
              child: IconButton(
                onPressed: () {},
                icon: const Icon(
                  Icons.search_outlined,
                  color: kTextColor,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        Expanded(
          child: ListView.builder(
            itemCount: 1,
            itemBuilder: (BuildContext context, int index) {
              return Column(
                children: [
                  ListTile(
                    leading: const CircleAvatar(
                      radius: 20,
                      backgroundImage: AssetImage("assets/guy.png"),
                    ),
                    title: const Text(
                      "Call of Duty",
                      style: TextStyle(
                          color: kTextColor,
                          fontSize: 10,
                          fontWeight: FontWeight.w200),
                    ),
                    subtitle: const Text(
                      "Mobile game.24M followers\n 10 + posts last week",
                      style: TextStyle(
                        color: kTextColor,
                        fontSize: 10,
                      ),
                    ),
                    trailing: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: kPrimaryColor),
                      onPressed: () {},
                      child: const Text(
                        "Unfollow",
                        style: TextStyle(color: kTabBarColor),
                      ),
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.only(left: 60),
                    child: Divider(
                      color: kTabBarColor,
                      thickness: 1,
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const MyRow(),
                  const Padding(
                    padding: EdgeInsets.only(left: 60),
                    child: Divider(
                      color: kTabBarColor,
                      thickness: 1,
                    ),
                  ),
                  const RobbyRow(),
                  const Padding(
                    padding: EdgeInsets.only(left: 60),
                    child: Divider(
                      color: kTabBarColor,
                      thickness: 1,
                    ),
                  ),
                  const RobbyRow(),
                  const Padding(
                    padding: EdgeInsets.only(left: 60),
                    child: Divider(
                      color: kTabBarColor,
                      thickness: 1,
                    ),
                  ),
                  const RobbyRow(),
                  const Padding(
                    padding: EdgeInsets.only(left: 60),
                    child: Divider(
                      color: kTabBarColor,
                      thickness: 1,
                    ),
                  ),
                  const RobbyRow(),
                  const Padding(
                    padding: EdgeInsets.only(left: 60),
                    child: Divider(
                      color: kTabBarColor,
                      thickness: 1,
                    ),
                  ),
                  const RobbyRow(),
                  const Padding(
                    padding: EdgeInsets.only(left: 60),
                    child: Divider(
                      color: kTabBarColor,
                      thickness: 1,
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ],
    );
  }
}
