import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../utils/app_colors.dart';

class PeoplesPage extends StatefulWidget {
  const PeoplesPage({super.key});

  @override
  State<PeoplesPage> createState() => _PeoplesPageState();
}

class _PeoplesPageState extends State<PeoplesPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      body: ListView.builder(
        itemCount: 10,
        scrollDirection: Axis.vertical,
        itemBuilder: (BuildContext context, int index) {
          return Container(
            padding: const EdgeInsets.all(0),
            child: Column(
              children: [
                ListTile(
                  leading: const CircleAvatar(
                    radius: 20,
                    child: Image(
                      image: AssetImage("assets/cap.png"),
                    ),
                  ),
                  title: Text(
                    "Call of duty",
                    style: GoogleFonts.poppins(
                        textStyle: kbtn2text, color: kTextColor),
                  ),
                  subtitle: Text(
                    "Call of duty followers",
                    style: GoogleFonts.poppins(
                        textStyle: kbtn2text, color: kTextColor),
                  ),
                  trailing: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: kPrimaryColor),
                    onPressed: () {},
                    child: const Text(
                      "Follow",
                      style: TextStyle(
                        color: kTextColor,
                      ),
                    ),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.only(left: 50, right: 15),
                  child: Divider(
                    color: kTabBarColor,
                    thickness: 1,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
