import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../utils/app_colors.dart';

class Discover extends StatefulWidget {
  const Discover({super.key});

  @override
  State<Discover> createState() => _DiscoverState();
}

class _DiscoverState extends State<Discover> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          height: 150,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
            color: kBackgroundColor,
          ),
          child: ListView.builder(
            itemCount: 10,
            itemBuilder: (BuildContext context, int index) {
              return Column(
                children: [
                  const SizedBox(
                    height: 10,
                  ),
                  ListTile(
                    leading: const CircleAvatar(
                      radius: 20,
                      child: Image(
                        image: AssetImage("assets/cap.png"),
                      ),
                    ),
                    title: Text(
                      "Call of duty",
                      style: GoogleFonts.poppins(
                          textStyle: kbtn2text, color: kTextColor),
                    ),
                    subtitle: Text(
                      "Call of duty followers",
                      style: GoogleFonts.poppins(
                          textStyle: kbtn2text, color: kTextColor),
                    ),
                    trailing: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: kPrimaryColor),
                      onPressed: () {},
                      child: const Text(
                        "Follow",
                        style: TextStyle(
                          color: kTextColor,
                        ),
                      ),
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.only(left: 50, right: 15),
                    child: Divider(
                      color: kTextColor,
                    ),
                  ),
                ],
              );
            },
          ),
        )
      ],
    );
  }
}
