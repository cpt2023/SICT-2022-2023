import 'package:flutter/material.dart';

import '../utils/app_colors.dart';
import 'my_row.dart';
import 'robby_row.dart';

class UmarFollowing extends StatefulWidget {
  const UmarFollowing({super.key});

  @override
  State<UmarFollowing> createState() => _UmarFollowingState();
}

class _UmarFollowingState extends State<UmarFollowing> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ListView.builder(
          itemCount: 1,
          itemBuilder: (BuildContext context, int index) {
            return Column(
              children: [
                ListTile(
                  leading: const CircleAvatar(
                    radius: 20,
                    backgroundImage: AssetImage("assets/guy.png"),
                  ),
                  title: const Text(
                    "Call of Duty",
                    style: TextStyle(
                        color: kTextColor,
                        fontSize: 10,
                        fontWeight: FontWeight.w200),
                  ),
                  subtitle: const Text(
                    "Mobile game.24M followers\n 10 + posts last week",
                    style: TextStyle(
                      color: kTextColor,
                      fontSize: 10,
                    ),
                  ),
                  trailing: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: kPrimaryColor),
                    onPressed: () {},
                    child: const Text(
                      "Unfollow",
                      style: TextStyle(color: kTabBarColor),
                    ),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.only(left: 60),
                  child: Divider(
                    color: kTabBarColor,
                    thickness: 1,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                const MyRow(),
                const Padding(
                  padding: EdgeInsets.only(left: 60),
                  child: Divider(
                    color: kTabBarColor,
                    thickness: 1,
                  ),
                ),
                const RobbyRow(),
                const Padding(
                  padding: EdgeInsets.only(left: 60),
                  child: Divider(
                    color: kTabBarColor,
                    thickness: 1,
                  ),
                ),
                const RobbyRow(),
                const Padding(
                  padding: EdgeInsets.only(left: 60),
                  child: Divider(
                    color: kTabBarColor,
                    thickness: 1,
                  ),
                ),
                const RobbyRow(),
                const Padding(
                  padding: EdgeInsets.only(left: 60),
                  child: Divider(
                    color: kTabBarColor,
                    thickness: 1,
                  ),
                ),
                const RobbyRow(),
                const Padding(
                  padding: EdgeInsets.only(left: 60),
                  child: Divider(
                    color: kTabBarColor,
                    thickness: 1,
                  ),
                ),
                const RobbyRow(),
                const Padding(
                  padding: EdgeInsets.only(left: 60),
                  child: Divider(
                    color: kTabBarColor,
                    thickness: 1,
                  ),
                ),
              ],
            );
          },
        ),
      ],
    );
  }
}
