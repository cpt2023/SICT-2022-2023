import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_image_stack/flutter_image_stack.dart';

class ImageStack extends StatelessWidget {
  const ImageStack({super.key});

  @override
  Widget build(BuildContext context) {
    return FlutterImageStack(
      imageList: const [
        "assets/cap.png",
        "assets/guy.png",
        "assets/yellow.png",
      ],
      totalCount: 3,
      itemCount: 3,
      itemRadius: 20,
      imageSource: ImageSource.asset,
      itemBorderWidth: 3,
    );
  }
}
