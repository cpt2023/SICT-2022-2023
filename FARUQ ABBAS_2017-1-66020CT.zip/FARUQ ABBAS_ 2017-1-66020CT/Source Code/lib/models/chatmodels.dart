class ChatModels {
  String name;

  bool isGroup;
  String elevatedButton;
  String currentMessage;
  ChatModels(
    this.elevatedButton,
    this.currentMessage,
    this.isGroup,
    this.name,
  );
}
