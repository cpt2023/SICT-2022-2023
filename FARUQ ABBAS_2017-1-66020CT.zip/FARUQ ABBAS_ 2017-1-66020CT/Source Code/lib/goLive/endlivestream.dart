import 'package:flutter/material.dart';

import 'package:google_fonts/google_fonts.dart';

import '../utils/app_colors.dart';

class EndliveStream extends StatefulWidget {
  const EndliveStream({super.key});
  static String id = "EndliveStream";

  @override
  State<EndliveStream> createState() => _EndliveStreamState();
}

class _EndliveStreamState extends State<EndliveStream> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: kBackgroundColor,
          centerTitle: true,
          title: const Text(
            "Live Streaming",
            style: TextStyle(
                color: kTextColor, fontSize: 20, fontWeight: FontWeight.bold),
          ),
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.adaptive.arrow_back,
              color: kTextColor,
            ),
          ),
        ),
        // backgroundColor: kBackgroundColor,
        body: Column(
          children: [
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: const BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage(
                          "assets/endlive.png",
                        ),
                        fit: BoxFit.cover)),
                child: Stack(
                  children: [
                    Positioned(
                        left: 340,
                        top: 20,
                        child: Column(
                          children: [
                            GestureDetector(
                                onTap: () => showModalBottomSheet(
                                    isScrollControlled: true,
                                    backgroundColor: Colors.blue,
                                    shape: const RoundedRectangleBorder(
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(10),
                                            topRight: Radius.circular(10))),
                                    context: context,
                                    builder: (context) {
                                      return SizedBox(
                                        height: 202,
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 25.0, vertical: 25.0),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Text(
                                                "Do you want to stop your live streaming?",
                                                style: GoogleFonts.poppins(
                                                    textStyle: ksemiboldingtext,
                                                    color: Colors.white),
                                                textAlign: TextAlign.center,
                                              ),
                                              const SizedBox(
                                                height: 0,
                                              ),
                                              Expanded(
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Flexible(
                                                      child: GestureDetector(
                                                        onTap: () =>
                                                            Navigator.pop(
                                                                context),
                                                        child: Container(
                                                          width: 179,
                                                          height: 50,
                                                          decoration:
                                                              BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        5),
                                                            color: const Color(
                                                                0xff161626),
                                                          ),
                                                          child: Center(
                                                              child: Text(
                                                            "Cancel",
                                                            style: GoogleFonts
                                                                .poppins(
                                                                    textStyle:
                                                                        kbtntext),
                                                          )),
                                                        ),
                                                      ),
                                                    ),
                                                    const SizedBox(
                                                      width: 20,
                                                    ),
                                                    Flexible(
                                                      child: GestureDetector(
                                                        onTap: () =>
                                                            showModalBottomSheet(
                                                                isScrollControlled:
                                                                    true,
                                                                backgroundColor:
                                                                    Colors.blue,
                                                                shape: const RoundedRectangleBorder(
                                                                    borderRadius: BorderRadius.only(
                                                                        topLeft:
                                                                            Radius.circular(
                                                                                10),
                                                                        topRight:
                                                                            Radius.circular(
                                                                                10))),
                                                                context:
                                                                    context,
                                                                builder:
                                                                    (context) {
                                                                  return SizedBox(
                                                                    height: 202,
                                                                    child:
                                                                        Padding(
                                                                      padding: const EdgeInsets
                                                                          .symmetric(
                                                                          horizontal:
                                                                              25.0,
                                                                          vertical:
                                                                              25.0),
                                                                      child:
                                                                          Column(
                                                                        mainAxisSize:
                                                                            MainAxisSize.min,
                                                                        children: [
                                                                          Text(
                                                                            "Live Stream finished do you want to share your live stream"
                                                                            "on the news feed?",
                                                                            style:
                                                                                GoogleFonts.poppins(textStyle: ksemiboldingtext, color: Colors.white),
                                                                            textAlign:
                                                                                TextAlign.center,
                                                                          ),
                                                                          const SizedBox(
                                                                            height:
                                                                                0,
                                                                          ),
                                                                          Expanded(
                                                                            child:
                                                                                Row(
                                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                              children: [
                                                                                Flexible(
                                                                                  child: GestureDetector(
                                                                                    onTap: () => Navigator.pop(context),
                                                                                    child: Container(
                                                                                      width: 179,
                                                                                      height: 50,
                                                                                      decoration: BoxDecoration(
                                                                                        borderRadius: BorderRadius.circular(5),
                                                                                        color: const Color(0xff161626),
                                                                                      ),
                                                                                      child: Center(
                                                                                          child: Text(
                                                                                        "No",
                                                                                        style: GoogleFonts.poppins(textStyle: kbtntext),
                                                                                      )),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                const SizedBox(
                                                                                  width: 20,
                                                                                ),
                                                                                Flexible(
                                                                                  child: GestureDetector(
                                                                                    // work on the navigation
                                                                                    //onTap: () => Navigator.pushNamed(context, LiveStream.id),
                                                                                    child: Container(
                                                                                      width: 179,
                                                                                      height: 50,
                                                                                      decoration: BoxDecoration(
                                                                                        borderRadius: BorderRadius.circular(5),
                                                                                        color: kPrimaryColor,
                                                                                      ),
                                                                                      child: Center(
                                                                                          child: Text(
                                                                                        "Yes",
                                                                                        style: GoogleFonts.poppins(textStyle: kbtntext),
                                                                                      )),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          )
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  );
                                                                }),
                                                        child: Container(
                                                          width: 179,
                                                          height: 50,
                                                          decoration:
                                                              BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        5),
                                                            color:
                                                                kPrimaryColor,
                                                          ),
                                                          child: Center(
                                                              child: Text(
                                                            "Continue",
                                                            style: GoogleFonts
                                                                .poppins(
                                                                    textStyle:
                                                                        kbtntext),
                                                          )),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                      );
                                    }),
                                //end of it
                                child: const Icon(Icons.cancel)),
                          ],
                        ))
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
