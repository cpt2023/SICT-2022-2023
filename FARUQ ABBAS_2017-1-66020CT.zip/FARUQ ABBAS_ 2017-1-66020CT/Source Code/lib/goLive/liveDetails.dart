import 'package:flutter/material.dart';
import 'package:game_on/goLive/livestream.dart';
import 'package:game_on/screens/navbar.dart';
import 'package:google_fonts/google_fonts.dart';

import '../utils/app_colors.dart';

class LiveDetails extends StatefulWidget {
  const LiveDetails({super.key});
  static String id = "LiveDetails";

  @override
  State<LiveDetails> createState() => _LiveDetailsState();
}

class _LiveDetailsState extends State<LiveDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        backgroundColor: kBackgroundColor,
        title: Row(
          children: [
            GestureDetector(
                onTap: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => NavBar()));
                },
                child: const Icon(Icons.arrow_back)),
            const SizedBox(
              width: 100,
            ),
            Center(
                child: Text(
              "Go Live",
              style: GoogleFonts.poppins(textStyle: kHeadingtext),
            )),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25.0),
        child: Column(
          children: [
            ListTile(
              contentPadding: const EdgeInsets.all(0.0),
              leading: const CircleAvatar(
                //radius: 50,
                backgroundImage: AssetImage("assets/boy1.png"),
              ),
              title: Text("DroidVillaz",
                  style: GoogleFonts.poppins(
                      textStyle: ksemiboldingtext, color: Colors.white)),
              subtitle: Text("Umar Faruq",
                  style: GoogleFonts.poppins(
                    textStyle: kregulartext,
                  )),
            ),
            const SizedBox(
              height: 21,
            ),
            TextFormField(
              decoration: InputDecoration(
                  fillColor: const Color(0xff161626),
                  hintText: "Stream title",
                  hintStyle: GoogleFonts.poppins(
                      textStyle: kregulartext, color: Colors.white),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(5),
                      borderSide: const BorderSide(
                          color: Color(0xff535353), width: 2.0))),
            ),
            const SizedBox(
              height: 36,
            ),
            TextFormField(
              decoration: InputDecoration(
                  fillColor: const Color(0xff161626),
                  hintText: "Game title",
                  hintStyle: GoogleFonts.poppins(
                      textStyle: kregulartext, color: Colors.white),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(5),
                      borderSide: const BorderSide(
                          color: Color(0xff535353), width: 2.0))),
            ),
            const SizedBox(
              height: 36,
            ),
            GestureDetector(
              onTap: () => showModalBottomSheet(
                  isScrollControlled: true,
                  backgroundColor: Colors.blue,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10))),
                  context: context,
                  builder: (context) {
                    return SizedBox(
                      height: 268,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 25.0, vertical: 25.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Image.asset("assets/live.png"),
                            const SizedBox(
                              height: 19,
                            ),
                            const Divider(
                              thickness: 1,
                              color: Color(0xff535353),
                              height: 1,
                            ),
                            const SizedBox(
                              height: 37,
                            ),
                            Text(
                              "Gameon will start capturing what is displayed on"
                              "your screen",
                              style: GoogleFonts.poppins(
                                  textStyle: ksemiboldingtext,
                                  color: Colors.white),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(
                              height: 0,
                            ),
                            Expanded(
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Flexible(
                                    child: GestureDetector(
                                      onTap: () => Navigator.pop(context),
                                      child: Container(
                                        width: 179,
                                        height: 50,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(5),
                                          color: const Color(0xff161626),
                                        ),
                                        child: Center(
                                            child: Text(
                                          "Cancel",
                                          style: GoogleFonts.poppins(
                                              textStyle: kbtntext),
                                        )),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 20,
                                  ),
                                  Flexible(
                                    child: GestureDetector(
                                      onTap: () {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    const LiveStream()));
                                      },
                                      child: Container(
                                        width: 179,
                                        height: 50,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(5),
                                          color: kPrimaryColor,
                                        ),
                                        child: Center(
                                            child: Text(
                                          "Next",
                                          style: GoogleFonts.poppins(
                                              textStyle: kbtntext),
                                        )),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    );
                  }),
              // End of bottonshowmodal
              child: Container(
                width: 378,
                height: 50,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: kPrimaryColor,
                ),
                child: Center(
                    child: Text(
                  "Next",
                  style: GoogleFonts.poppins(textStyle: kbtntext),
                )),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
