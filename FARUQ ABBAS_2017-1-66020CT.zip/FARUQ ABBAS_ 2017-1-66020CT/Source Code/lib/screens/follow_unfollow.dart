import 'package:flutter/material.dart';

import '../models/followers.dart';
import '../models/following.dart';
import '../utils/app_colors.dart';
import 'users_accounts/blocked_account.dart';

class FollowUnfollow extends StatefulWidget {
  const FollowUnfollow({super.key});

  @override
  State<FollowUnfollow> createState() => _FollowUnfollowState();
}

class _FollowUnfollowState extends State<FollowUnfollow> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: kBackgroundColor,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: kBackgroundColor,
          leading: IconButton(
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const BlockedAccount(),
                  ));
            },
            icon: Icon(
              Icons.adaptive.arrow_back,
              color: kTextColor,
            ),
          ),
          centerTitle: true,
          title: const Text(
            "John Doe",
            style: TextStyle(
                color: kTextColor, fontSize: 20, fontWeight: FontWeight.bold),
          ),
          bottom: const TabBar(
            indicatorColor: kTextColor,
            tabs: [
              Tab(
                text: "Followers",
              ),
              Tab(
                text: "Following",
              ),
            ],
          ),
        ),
        body: const TabBarView(children: [
          Followers(),
          Following(),
        ]),
      ),
    );
  }
}
