import 'package:flutter/material.dart';

import '../components/comment.dart';
import '../components/customtile.dart';
import '../utils/app_colors.dart';
import 'user_registration/recent_screen.dart';

class Iphone15 extends StatefulWidget {
  const Iphone15({super.key});

  @override
  State<Iphone15> createState() => _Iphone15State();
}

class _Iphone15State extends State<Iphone15> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        backgroundColor: kBackgroundColor,
        elevation: 0,
        leading: Container(
          width: 50,
          height: 50,
          decoration: const BoxDecoration(
              image: DecorationImage(image: AssetImage("assets/yellow.png"))),
        ),
        centerTitle: true,
        title: const Text(
          "GameOn",
          style: TextStyle(
              color: kTextColor, fontSize: 18, fontWeight: FontWeight.w300),
        ),
        actions: const [
          Row(
            children: [
              CircleAvatar(
                radius: 10,
                backgroundImage: AssetImage("assets/yellow.png"),
              ),
              SizedBox(
                width: 10,
              ),
              Padding(
                padding: EdgeInsets.only(right: 15),
                child: Row(
                  children: [
                    Icon(
                      Icons.mark_chat_unread_outlined,
                      color: Colors.red,
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Icon(
                      Icons.notification_add_rounded,
                      color: kTextColor,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: 10,
        itemBuilder: (BuildContext context, int index) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // customtile
              const CustomTile(),

              // game image
              Container(
                  height: 200,
                  width: MediaQuery.of(context).size.width,
                  decoration: const BoxDecoration(color: kTextColor),
                  child: const Image(
                    image: AssetImage("assets/duty.png"),
                    fit: BoxFit.cover,
                  )),
              // call of duty mobile
              Container(
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(color: kTabBarColor),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Padding(
                      padding: EdgeInsets.only(left: 15, right: 15),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Call of Duty Mobile",
                            style: TextStyle(color: kTextColor),
                          ),
                          Text(
                            "Peoples working",
                            style: TextStyle(color: kTextColor, fontSize: 10),
                          ),

                          // call of duty game comment
                        ],
                      ),
                    ),
                    Container(
                      decoration: const BoxDecoration(color: kTabBarColor),
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      height: 40,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              IconButton(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          const RecentScreen(),
                                    ),
                                  );
                                },
                                icon: const Icon(
                                  Icons.thumb_up_off_alt_outlined,
                                  color: kTextColor,
                                ),
                              ),
                              const SizedBox(
                                width: 4,
                              ),
                              const Text(
                                "2.4k",
                                style: TextStyle(color: kTextColor),
                              ),
                              const SizedBox(
                                width: 30,
                              ),
                              IconButton(
                                onPressed: () {},
                                icon: const Icon(
                                  Icons.message_outlined,
                                  color: kTextColor,
                                ),
                              ),
                              const SizedBox(
                                width: 4,
                              ),
                              const Text(
                                "2.4k",
                                style: TextStyle(color: kTextColor),
                              ),
                            ],
                          ),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: kPrimaryColor),
                            onPressed: () {},
                            child: const Text(
                              "Join stream",
                              style: TextStyle(color: kTextColor),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),

                    // what game are you playing today
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const CustomTile(),
                        const Padding(
                          padding: EdgeInsets.only(left: 15),
                          child: Text(
                            "What game are you playing today",
                            style: TextStyle(color: kTextColor),
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Padding(
                              padding: EdgeInsets.only(
                                left: 15,
                              ),
                              child: CommentTile(
                                color: kPrimaryColor,
                                icon: Icons.thumb_up_alt,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                right: 15,
                              ),
                              child: IconButton(
                                onPressed: () {},
                                icon: const Icon(
                                  Icons.bookmark_border_outlined,
                                  color: kTextColor,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const CustomTile(),

                  Container(
                    padding: const EdgeInsets.only(left: 15),
                    color: kTabBarColor,
                    child: const Row(children: [
                      Text(
                        "I will be entire playing matches and will be streaming it all",
                        style: TextStyle(
                          color: kTextColor,
                        ),
                      ),
                    ]),
                  ),

                  // game image
                  Container(
                    height: 200,
                    width: MediaQuery.of(context).size.width,
                    decoration: const BoxDecoration(),
                    child: const Image(
                      image: AssetImage("assets/sniper.png"),
                      fit: BoxFit.cover,
                    ),
                  ),

                  // sniper game comment
                  Column(
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width,
                        decoration: const BoxDecoration(color: kTabBarColor),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 15, right: 15),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    "Sniper",
                                    style: TextStyle(color: kTextColor),
                                  ),
                                  const Text(
                                    "Peoples working",
                                    style: TextStyle(
                                        color: kTextColor, fontSize: 10),
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const CommentTile(
                                        icon: Icons.thumb_up_alt_outlined,
                                        color: kTextColor,
                                      ),
                                      ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: kPrimaryColor),
                                        onPressed: () {},
                                        child: const Text(
                                          "Join stream",
                                          style: TextStyle(color: kTextColor),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(
                height: 15,
              ),
            ],
          );
        },
      ),
    );
  }
}
