import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:game_on/createpost.dart/createPost.dart';
import 'package:game_on/goLive/livestream.dart';
import 'package:game_on/screens/sign_in.dart';
import 'package:game_on/screens/users_accounts/edit_profile.dart';

import '../components/customtile.dart';
import '../utils/app_colors.dart';

class Iphone29 extends StatefulWidget {
  const Iphone29({super.key});

  @override
  State<Iphone29> createState() => _Iphone29State();
}

class _Iphone29State extends State<Iphone29> {
  void logOut() async {
    await FirebaseAuth.instance.signOut();

    // ignore: use_build_context_synchronously
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const SignIn()),
      (Route<dynamic> route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              width: MediaQuery.of(context).size.width,
              height: 300,
              decoration: const BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("assets/guy.png"), fit: BoxFit.cover)),
              child: customIcons(),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              color: kBackgroundColor,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 60,
                            height: 60,
                            decoration:
                                const BoxDecoration(shape: BoxShape.circle),
                            child: Image.asset("assets/yellow.png"),
                          ),
                          const SizedBox(
                            width: 4,
                          ),
                          Container(
                            alignment: Alignment.center,
                            child: const Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "DroidVillaz",
                                  style: TextStyle(
                                      color: kTextColor, fontSize: 10),
                                ),
                                SizedBox(
                                  height: 4,
                                ),
                                Text(
                                  "Dream League Soccer",
                                  style:
                                      TextStyle(color: kTextColor, fontSize: 8),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          // Image.asset('assets/mes.png'),
                          const SizedBox(
                            width: 10,
                          ),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: kfillColor),
                            onPressed: () {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) => EditProfile()));
                            },
                            child: const Text(
                              "Edit profile",
                              style: TextStyle(color: kTextColor),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const Divider(
                    color: kTabBarColor,
                    thickness: 1,
                  ),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        children: [
                          Text(
                            "35",
                            style: TextStyle(
                                color: kTextColor, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            height: 4,
                          ),
                          Text(
                            "Posts",
                            style: TextStyle(color: kTextColor),
                          ),
                        ],
                      ),
                      Column(
                        children: [
                          Text(
                            "2k",
                            style: TextStyle(
                                color: kTextColor, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            height: 4,
                          ),
                          Text(
                            "Followers",
                            style: TextStyle(color: kTextColor),
                          ),
                        ],
                      ),
                      Column(
                        children: [
                          Text(
                            "20",
                            style: TextStyle(
                                color: kTextColor, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            height: 4,
                          ),
                          Text(
                            "Following",
                            style: TextStyle(color: kTextColor),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const Divider(
                    color: kTabBarColor,
                    thickness: 1,
                  ),
                ],
              ),
            ),
            const Expanded(
              child: MyTabbs(),
            ),
          ],
        ),
      ),
    );
  }

  Column customIcons() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(
          height: 20,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              width: 50,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: kTabBarColor,
              ),
              child: IconButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: Icon(
                  Icons.adaptive.arrow_back,
                  color: kTextColor,
                ),
              ),
            ),
            Row(
              children: [
                // Container(
                //   width: 50,
                //   decoration: const BoxDecoration(
                //     shape: BoxShape.circle,
                //     color: kTabBarColor,
                //   ),
                //   child: IconButton(
                //     onPressed: () {},
                //     icon: const Icon(
                //       Icons.notifications_none_outlined,
                //       color: kTextColor,
                //     ),
                //   ),
                // ),
                const SizedBox(
                  width: 10,
                ),
                Container(
                  width: 50,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: kTabBarColor,
                  ),
                  child: IconButton(
                    onPressed: () {
                      // show modal
                      showModalBottomSheet(
                          isScrollControlled: true,
                          backgroundColor: const Color.fromARGB(255, 1, 1, 32),
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(10),
                                  topRight: Radius.circular(10))),
                          context: context,
                          builder: (context) {
                            return Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 25.0, vertical: 25.0),
                              child: SizedBox(
                                height: 200,
                                child: Column(
                                  children: [
                                    GestureDetector(
                                      onTap: () {
                                        // Navigator.of(context).push(
                                        //     MaterialPageRoute(
                                        //         builder: (context) =>
                                        //             CreatePost()));
                                      },
                                      child: Row(
                                        children: [
                                          Image.asset('assets/set.png'),
                                          const SizedBox(
                                            width: 20,
                                          ),
                                          const Text(
                                            'Settings and privacy',
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 15),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    const Divider(
                                      thickness: 1,
                                      color: Color(0xff535353),
                                      height: 1,
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    GestureDetector(
                                      onTap: () {
                                        // Navigator.of(context).push(
                                        //     MaterialPageRoute(
                                        //         builder: (context) =>
                                        //             LiveStream()));
                                      },
                                      child: Row(
                                        children: [
                                          Image.asset('assets/save.png'),
                                          const SizedBox(
                                            width: 20,
                                          ),
                                          const Text(
                                            'Saved',
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 15),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    const Divider(
                                      thickness: 1,
                                      color: Color(0xff535353),
                                      height: 1,
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    GestureDetector(
                                      onTap: () {
                                        showModalBottomSheet(
                                            isScrollControlled: true,
                                            backgroundColor:
                                                const Color.fromARGB(
                                                    255, 1, 1, 32),
                                            shape: const RoundedRectangleBorder(
                                                borderRadius: BorderRadius.only(
                                                    topLeft:
                                                        Radius.circular(10),
                                                    topRight:
                                                        Radius.circular(10))),
                                            context: context,
                                            builder: (context) {
                                              return Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 25.0,
                                                        vertical: 25.0),
                                                child: SizedBox(
                                                  height: 300,
                                                  child: Column(
                                                    children: [
                                                      Image.asset(
                                                          'assets/log2.png'),
                                                      const SizedBox(
                                                        height: 10,
                                                      ),
                                                      const Text(
                                                        'Log out',
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white),
                                                      ),
                                                      const SizedBox(
                                                        height: 10,
                                                      ),
                                                      const Text(
                                                        'By Login out you will need to login to us the app personal details are still safe',
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white),
                                                      ),
                                                      const SizedBox(
                                                        height: 20,
                                                      ),
                                                      Row(
                                                        children: [
                                                          Flexible(
                                                            child:
                                                                GestureDetector(
                                                              onTap: () {
                                                                Navigator.pop(
                                                                    context);
                                                              },
                                                              child: Container(
                                                                height: 50,
                                                                width: 179,
                                                                decoration: BoxDecoration(
                                                                    borderRadius:
                                                                        BorderRadius
                                                                            .circular(
                                                                                5),
                                                                    color: Color(
                                                                        0xff161626)),
                                                                child:
                                                                    const Center(
                                                                  child: Text(
                                                                    'Cancel',
                                                                    style: TextStyle(
                                                                        color: Colors
                                                                            .white),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Flexible(
                                                            child:
                                                                GestureDetector(
                                                              onTap: () {
                                                                logOut();
                                                              },
                                                              child: Container(
                                                                height: 50,
                                                                width: 179,
                                                                decoration: BoxDecoration(
                                                                    borderRadius:
                                                                        BorderRadius
                                                                            .circular(
                                                                                5),
                                                                    color:
                                                                        kPrimaryColor),
                                                                child:
                                                                    const Center(
                                                                  child: Text(
                                                                    'Continue',
                                                                    style: TextStyle(
                                                                        color: Colors
                                                                            .white),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 10,
                                                          )
                                                        ],
                                                      )
                                                    ],
                                                  ),
                                                ),
                                              );
                                            });
                                      },
                                      child: Row(
                                        children: [
                                          Image.asset('assets/log.png'),
                                          const SizedBox(
                                            width: 20,
                                          ),
                                          const Text(
                                            'Log out',
                                            style: TextStyle(
                                              color: Colors.red,
                                              fontSize: 15,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          });
                      //end show modal
                    },
                    icon: const Icon(
                      Icons.more_vert_outlined,
                      color: kTextColor,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(
          height: 150,
        ),
        const Text(
          "Umar",
          style: TextStyle(
              color: kTextColor, fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(
          height: 10,
        ),
        const Text(
          "Faruq",
          style: TextStyle(
              color: kTextColor, fontSize: 18, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}

class MyTabbs extends StatelessWidget {
  const MyTabbs({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: kBackgroundColor,
      child: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            backgroundColor: kBackgroundColor,
            toolbarHeight: 0,
            bottom: const TabBar(indicatorColor: kTextColor, tabs: [
              Tab(
                text: "Posts",
              ),
              Tab(
                text: "Streaming live",
              ),
            ]),
          ),
          body: TabBarView(children: [
            ListView.builder(
              itemCount: 10,
              itemBuilder: (BuildContext context, int index) {
                return Column(
                  children: [
                    const CustomTile(),

                    // game image
                    Container(
                        height: 200,
                        width: MediaQuery.of(context).size.width,
                        decoration: const BoxDecoration(color: kTextColor),
                        child: const Image(
                          image: AssetImage("assets/sniper.png"),
                          fit: BoxFit.cover,
                        )),
                    // call of duty mobile
                    Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(color: kBackgroundColor),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding: EdgeInsets.only(left: 15, right: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Mortal Kombat",
                                  style: TextStyle(color: kTextColor),
                                ),
                                Text(
                                  "Peoples working",
                                  style: TextStyle(
                                      color: kTextColor, fontSize: 10),
                                ),

                                // call of duty game comment
                              ],
                            ),
                          ),
                          Container(
                            decoration:
                                const BoxDecoration(color: kBackgroundColor),
                            padding: const EdgeInsets.symmetric(horizontal: 15),
                            height: 40,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    IconButton(
                                      onPressed: () {},
                                      icon: const Icon(
                                        Icons.thumb_up_off_alt_outlined,
                                        color: kTextColor,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 4,
                                    ),
                                    const Text(
                                      "2.4k",
                                      style: TextStyle(color: kTextColor),
                                    ),
                                    const SizedBox(
                                      width: 30,
                                    ),
                                    Image.asset('assets/mes.png'),
                                    const SizedBox(
                                      width: 4,
                                    ),
                                    const Text(
                                      "2.4k",
                                      style: TextStyle(color: kTextColor),
                                    ),
                                  ],
                                ),
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: kfillColor),
                                  onPressed: () {},
                                  child: const Text(
                                    "Join stream",
                                    style: TextStyle(color: kTextColor),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                  ],
                );
              },
            ),
            ListView.builder(
              itemCount: 10,
              itemBuilder: (BuildContext context, int index) {
                return Column(
                  children: [
                    const CustomTile(),

                    // game image
                    Container(
                        height: 200,
                        width: MediaQuery.of(context).size.width,
                        decoration: const BoxDecoration(color: kTextColor),
                        child: const Image(
                          image: AssetImage("assets/fcb.png"),
                          fit: BoxFit.cover,
                        )),
                    // call of duty mobile
                    Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(color: kBackgroundColor),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding: EdgeInsets.only(left: 15, right: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Man utd vs Man city",
                                  style: TextStyle(color: kTextColor),
                                ),
                                Text(
                                  "Peoples working",
                                  style: TextStyle(
                                      color: kTextColor, fontSize: 10),
                                ),

                                // call of duty game comment
                              ],
                            ),
                          ),
                          Container(
                            decoration:
                                const BoxDecoration(color: kBackgroundColor),
                            padding: const EdgeInsets.symmetric(horizontal: 15),
                            height: 40,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    IconButton(
                                      onPressed: () {},
                                      icon: const Icon(
                                        Icons.thumb_up_off_alt_outlined,
                                        color: kTextColor,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 4,
                                    ),
                                    const Text(
                                      "2.4k",
                                      style: TextStyle(color: kTextColor),
                                    ),
                                    const SizedBox(
                                      width: 30,
                                    ),
                                    Image.asset('assets/mes.png'),
                                    // IconButton(
                                    //   onPressed: () {},
                                    //   icon: const Icon(
                                    //     Icons.message_outlined,
                                    //     color: kTextColor,
                                    //   ),
                                    // ),
                                    const SizedBox(
                                      width: 4,
                                    ),
                                    const Text(
                                      "2.4k",
                                      style: TextStyle(color: kTextColor),
                                    ),
                                  ],
                                ),
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: kPrimaryColor),
                                  onPressed: () {},
                                  child: const Text(
                                    "Join stream",
                                    style: TextStyle(color: kTextColor),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                  ],
                );
              },
            ),
          ]),
        ),
      ),
    );
  }
}
