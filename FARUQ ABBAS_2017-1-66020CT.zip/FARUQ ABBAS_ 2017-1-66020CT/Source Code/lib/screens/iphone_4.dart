import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../components/loginbuttons.dart';
import '../utils/app_colors.dart';

class Iphone4 extends StatefulWidget {
  const Iphone4({super.key});

  @override
  State<Iphone4> createState() => _Iphone4State();
}

class _Iphone4State extends State<Iphone4> {
  double availableScreenWidth = 0;
  @override
  Widget build(BuildContext context) {
    availableScreenWidth = MediaQuery.of(context).size.width - 30;
    return Scaffold(
      backgroundColor: kBackgroundColor,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(kDefaultPadding),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Row(
                children: [
                  buildFile(kPrimaryColor, .32),
                  const SizedBox(
                    width: 5,
                  ),
                  buildFile(kPrimaryColor, .32),
                  const SizedBox(
                    width: 5,
                  ),
                  buildFile(kPrimaryColor, .32),
                ],
              ),
              Center(
                child: CircleAvatar(
                  radius: 100,
                  child: Image.asset("assets/bltd.png"),
                ),
              ),
              ListTile(
                title: Text(
                  "Stream your Gameplay",
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(
                      textStyle: kBigheading, color: kTextColor),
                ),
                subtitle: Text(
                  "Show off your skills, Stream your gameplay and build"
                  "your own fanbase, Lets Get Started",
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(
                      textStyle: kbtn2text, color: kTextColor),
                ),
              ),
              const SizedBox(
                height: 4,
              ),
              const SizedBox(
                height: 10,
              ),
              const LoginButton(),
            ],
          ),
        ),
      ),
    );
  }

  Container buildFile(Color color, double width) {
    return Container(
      height: 4,
      width: availableScreenWidth * width,
      color: color,
    );
  }
}
