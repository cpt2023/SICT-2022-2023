import 'package:flutter/material.dart';
import 'package:game_on/screens/iphone_4.dart';
import 'package:google_fonts/google_fonts.dart';

import '../components/buttons.dart';
import '../components/stepper_tile.dart';
import '../utils/app_colors.dart';

class Iphone3 extends StatefulWidget {
  const Iphone3({super.key});

  @override
  State<Iphone3> createState() => _Iphone3State();
}

class _Iphone3State extends State<Iphone3> {
  double availableScreenWidth = 0;
  @override
  Widget build(BuildContext context) {
    availableScreenWidth = MediaQuery.of(context).size.width - 30;
    return Scaffold(
      backgroundColor: kBackgroundColor,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(kDefaultPadding),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(
                height: 20,
              ),
              const Row(
                children: [
                  StepperTile(
                    color: kPrimaryColor,
                  ),
                  SizedBox(
                    width: 6,
                  ),
                  StepperTile(
                    color: kPrimaryColor,
                  ),
                  SizedBox(
                    width: 6,
                  ),
                  StepperTile(
                    color: kTextColor,
                  ),
                ],
              ),
              const SizedBox(
                height: 100,
              ),
              Center(
                child: CircleAvatar(
                  radius: 100,
                  child: Image.asset("assets/handle.png"),
                ),
              ),
              ListTile(
                title: Text(
                  "Stay in the Loop",
                  style: GoogleFonts.poppins(
                      textStyle: kBigheading, color: kTextColor),
                  textAlign: TextAlign.center,
                ),
                subtitle: Text(
                  "Never miss a moment, Got notifications for live "
                  "streams, updates and new gaming content.",
                  style: GoogleFonts.poppins(
                      textStyle: kbtn2text, color: kTextColor),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(
                height: 4,
              ),
              const SizedBox(
                height: 10,
              ),
              Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(16),
                              backgroundColor: Color.fromARGB(255, 28, 28, 48),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const Iphone4(),
                                ),
                              );
                            },
                            child: const Text(
                              "Skip",
                              style: TextStyle(
                                color: kTextColor,
                                fontSize: 20,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 20,
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(16),
                              backgroundColor: kPrimaryColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const Iphone4(),
                                ),
                              );
                            },
                            child: const Text(
                              "Next",
                              style: TextStyle(
                                fontSize: 20,
                                color: kTextColor,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
