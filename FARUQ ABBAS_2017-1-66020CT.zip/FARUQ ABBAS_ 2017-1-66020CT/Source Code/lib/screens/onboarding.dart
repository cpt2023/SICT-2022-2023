import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../components/buttons.dart';
import '../components/stepper_tile.dart';
import '../utils/app_colors.dart';

class Iphone2 extends StatefulWidget {
  const Iphone2({super.key});

  @override
  State<Iphone2> createState() => _Iphone2State();
}

class _Iphone2State extends State<Iphone2> {
  double availableScreenWidth = 0;
  @override
  Widget build(BuildContext context) {
    availableScreenWidth = MediaQuery.of(context).size.width - 40;
    return Scaffold(
      backgroundColor: kBackgroundColor,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              const Row(
                children: [
                  StepperTile(
                    color: kPrimaryColor,
                  ),
                  SizedBox(
                    width: 6,
                  ),
                  StepperTile(
                    color: kTextColor,
                  ),
                  SizedBox(
                    width: 6,
                  ),
                  StepperTile(
                    color: kTextColor,
                  ),
                ],
              ),
              Center(
                child: CircleAvatar(
                  radius: 100,
                  child: Image.asset("assets/horror.png"),
                ),
              ),
              ListTile(
                title: Text(
                  "Discover the World of Gaming",
                  style: GoogleFonts.poppins(
                      textStyle: kBiigheading, color: kTextColor),
                  textAlign: TextAlign.center,
                ),
                subtitle: Text(
                  "Join a global gaming community, watch lives"
                  "streams, chat with ganers and share your gaming"
                  "journey",
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(
                      textStyle: kbtn2text, color: kTextColor),
                ),
              ),
              const SizedBox(
                height: 4,
              ),
              const SizedBox(
                height: 10,
              ),
              const Roundedbutton()
            ],
          ),
        ),
      ),
    );
  }
}
