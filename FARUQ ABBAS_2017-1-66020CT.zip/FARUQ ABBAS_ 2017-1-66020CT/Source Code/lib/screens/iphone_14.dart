import 'package:flutter/material.dart';

import '../utils/app_colors.dart';

class Iphone14 extends StatefulWidget {
  const Iphone14({super.key});

  @override
  State<Iphone14> createState() => _Iphone14State();
}

class _Iphone14State extends State<Iphone14> {
  bool _isVisible = false;
  bool _isPasswordEightCharacters = false;
  bool _hasPasswordOneNumber = false;
  bool _hasPasswordUppercase = false;
  bool _hasPasswordUniqueCharacters = false;

  onPasswordChanged(String password) {
    final numericRegex = RegExp(r'[0-9]');
    final stringRegex = RegExp(r'[A-Z]');
    final intRegex = RegExp(r'[!,@,#,^,*_,+,?,~,`,&,]');
    setState(() {
      _isPasswordEightCharacters = false;
      if (password.length >= 8) _isPasswordEightCharacters = true;

      _hasPasswordOneNumber = false;
      if (numericRegex.hasMatch(password)) _hasPasswordOneNumber = true;

      _hasPasswordUppercase = false;

      if (stringRegex.hasMatch(password)) _hasPasswordUppercase = true;

      _hasPasswordUniqueCharacters = false;
      if (intRegex.hasMatch(password)) _hasPasswordUniqueCharacters = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: kBackgroundColor,
        leading: IconButton(
          onPressed: () {},
          icon: Icon(
            Icons.adaptive.arrow_back,
            color: kTextColor,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: SingleChildScrollView(
          child: Column(
            children: [
              const Text(
                "Create new password",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w300,
                  color: kTextColor,
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              const Text(
                "Make use of a long password to maintain account security",
                style: TextStyle(
                  color: kTextColor,
                ),
              ),
              const SizedBox(
                height: 15,
              ),

              // ppassword
              TextFormField(
                style: const TextStyle(color: kTextColor),
                onChanged: (password) => onPasswordChanged(password),
                obscureText: !_isVisible,
                decoration: InputDecoration(
                  suffixIcon: IconButton(
                    onPressed: () {
                      setState(() {
                        _isVisible = !_isVisible;
                      });
                    },
                    icon: Icon(
                        _isVisible ? Icons.visibility : Icons.visibility_off),
                  ),
                  fillColor: kTabBarColor,
                  filled: true,
                  hintText: "password",
                  hintStyle: const TextStyle(color: kTextColor),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: Colors.black),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: Colors.black),
                  ),
                ),
              ),
              const SizedBox(
                height: 15,
              ),

              // comfirm password
              TextField(
                style: const TextStyle(color: kTextColor),
                obscureText: !_isVisible,
                decoration: InputDecoration(
                  suffixIcon: IconButton(
                    onPressed: () {
                      setState(() {
                        _isVisible = !_isVisible;
                      });
                    },
                    icon: Icon(
                        _isVisible ? Icons.visibility : Icons.visibility_off),
                  ),
                  fillColor: kTabBarColor,
                  filled: true,
                  hintText: "Comfirm password",
                  hintStyle: const TextStyle(color: kTextColor),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: Colors.black),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: Colors.black),
                  ),
                ),
              ),
              const SizedBox(
                height: 20,
              ),

              // ElevatedButton
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kPrimaryColor,
                      ),
                      onPressed: () {},
                      child: const Text(
                        "Next",
                        style: TextStyle(color: kTextColor),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),

              // Minimum of 8 character
              Row(
                children: [
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 500),
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      border: _isPasswordEightCharacters
                          ? Border.all(color: Colors.transparent)
                          : Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(50),
                      color: _isPasswordEightCharacters
                          ? kPrimaryColor
                          : kBackgroundColor,
                    ),
                    child: const Icon(
                      Icons.check,
                      color: kBackgroundColor,
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  const Text(
                    "Minimum of 8 characters",
                    style: TextStyle(color: kTextColor),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),

              // Uppercase
              Row(
                children: [
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 500),
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      border: _hasPasswordUppercase
                          ? Border.all(color: Colors.transparent)
                          : Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(50),
                      color: _hasPasswordUppercase
                          ? kPrimaryColor
                          : kBackgroundColor,
                    ),
                    child: const Icon(
                      Icons.check,
                      color: kBackgroundColor,
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  const Text(
                    "Uppercase",
                    style: TextStyle(color: kTextColor),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),

              // Numeric characters
              Row(
                children: [
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 500),
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      border: _hasPasswordOneNumber
                          ? Border.all(color: Colors.transparent)
                          : Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(50),
                      color: _hasPasswordOneNumber
                          ? kPrimaryColor
                          : Colors.transparent,
                    ),
                    child: const Icon(
                      Icons.check,
                      color: kBackgroundColor,
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  const Text(
                    "Numeric digits",
                    style: TextStyle(color: kTextColor),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),

              // unique character e.g [!,@,#,$,%,^]
              Row(
                children: [
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 500),
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      border: _hasPasswordUniqueCharacters
                          ? Border.all(color: Colors.transparent)
                          : Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(50),
                      color: _hasPasswordUniqueCharacters
                          ? kPrimaryColor
                          : Colors.transparent,
                    ),
                    child: const Icon(
                      Icons.check,
                      color: kBackgroundColor,
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  const Text(
                    "Unique characters eg: # * & %",
                    style: TextStyle(color: kTextColor),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
