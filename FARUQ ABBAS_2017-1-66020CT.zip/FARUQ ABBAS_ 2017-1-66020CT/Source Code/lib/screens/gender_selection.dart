import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../utils/app_colors.dart';
import 'home.dart';
import 'user_registration/password_screen.dart';

class GenderSelection extends StatefulWidget {
  final Map<String, String> userDetails;

  const GenderSelection({Key? key, required this.userDetails})
      : super(key: key);

  @override
  State<GenderSelection> createState() => _GenderSelectionState();
}

class _GenderSelectionState extends State<GenderSelection> {
  String selectedGender = "Male";

  Color maleColor = kPrimaryColor;
  Color femaleColor = kPrimaryColor;
  Color otherColor = kPrimaryColor;

  void _handleRadioValue(String gender) {
    setState(() {
      selectedGender = gender;
    });
  }

  void _userData() {
    final newGender = selectedGender;
    final previousUserData = widget.userDetails;

    final updatedUserData = Map<String, String>.from(previousUserData);
    updatedUserData['gender'] = newGender;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PasswordScreen(updatedUserData: updatedUserData),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        backgroundColor: kBackgroundColor,
        elevation: 0,
        leading: Icon(
          Icons.adaptive.arrow_back,
          color: kTextColor,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(kDefaultPadding),
        child: SingleChildScrollView(
            child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // choose gender
            Text(
              "Choose gender",
              style: GoogleFonts.poppins(
                  textStyle: kBigheading, color: kTextColor),
            ),
            const SizedBox(
              height: 10,
            ),

            //ElevatedButton
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: kfillColor,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5),
                      side: const BorderSide(color: ksidebarcolor))),
              onPressed: () {},
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Male
                  const Text(
                    "Male",
                    style: TextStyle(color: kTextColor),
                  ),
                  Radio(
                    value: "Male",
                    groupValue: selectedGender,
                    onChanged: (value) => _handleRadioValue(value as String),
                    activeColor: maleColor,
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 10,
            ),

            // ElevatedButton
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: kfillColor,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5),
                      side: const BorderSide(color: ksidebarcolor))),
              onPressed: () {},
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  //Female
                  const Text(
                    "Female",
                    style: TextStyle(color: kTextColor),
                  ),
                  Radio(
                    value: "Female",
                    groupValue: selectedGender,
                    onChanged: (value) => _handleRadioValue(value as String),
                    activeColor: maleColor,
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 10,
            ),

            // ElevatedButton
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: kfillColor,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5),
                      side: const BorderSide(color: ksidebarcolor))),
              onPressed: () {},
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "Prefer not to say",
                    style: TextStyle(color: kTextColor),
                  ),
                  Radio(
                    value: "Prefer not to say",
                    groupValue: selectedGender,
                    onChanged: (value) => _handleRadioValue(value as String),
                    activeColor: maleColor,
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 100,
            ),
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kPrimaryColor,
                        shape: const RoundedRectangleBorder(
                            side: BorderSide(color: Colors.black)),
                      ),
                      onPressed: () {
                        _userData();
                      },
                      child: const Text(
                        "Next",
                        style: TextStyle(color: kTextColor),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 100,
            ),
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    "",
                    style: TextStyle(color: kTextColor),
                  ),
                  const SizedBox(
                    width: 2,
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const HomePage(),
                        ),
                      );
                    },
                    child: const Text(
                      "",
                      style: TextStyle(color: kPrimaryColor),
                    ),
                  ),
                ],
              ),
            ),
          ],
        )),
      ),
    );
  }
}
