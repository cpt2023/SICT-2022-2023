import 'package:flutter/material.dart';

import '../components/comment.dart';
import '../components/customtile.dart';
import '../utils/app_colors.dart';

class Iphone19 extends StatefulWidget {
  const Iphone19({super.key});

  @override
  State<Iphone19> createState() => _Iphone19State();
}

class _Iphone19State extends State<Iphone19> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: kBackgroundColor,
        appBar: AppBar(
          centerTitle: true,
          title: const Text(
            "Videos",
            style: TextStyle(color: kTextColor),
          ),
          elevation: 0,
          backgroundColor: kBackgroundColor,
          leading: IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.adaptive.arrow_back,
              color: kTextColor,
            ),
          ),
          bottom: const TabBar(tabs: [
            Tab(
              text: "Discover",
            ),
            Tab(
              text: "Following",
            ),
            Tab(
              text: "Streaming",
            ),
          ]),
        ),
        body: TabBarView(
          children: [
            ListView.builder(
              itemCount: 10,
              itemBuilder: (BuildContext context, int index) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // customtile
                    const CustomTile(),
                    Container(
                      color: kBackgroundColor,
                      child: const Padding(
                        padding: EdgeInsets.all(15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Man united vs Man city",
                              style: TextStyle(color: kTextColor),
                            ),
                            Text(
                              "3.5M views",
                              style: TextStyle(color: kTextColor),
                            )
                          ],
                        ),
                      ),
                    ),
                    // game image
                    Container(
                      height: 200,
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(),
                      child: const Image(
                        image: AssetImage("assets/fcb.png"),
                        fit: BoxFit.cover,
                      ),
                    ),
                    // call of duty mobile
                    Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(color: kBackgroundColor),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 15, right: 15),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Padding(
                                        padding: EdgeInsets.only(
                                          left: 10,
                                        ),
                                        child: CommentTile(
                                          color: kTextColor,
                                          icon: Icons.thumb_up_alt_outlined,
                                        ),
                                      ),
                                      IconButton(
                                        onPressed: () {},
                                        icon: const Icon(
                                          Icons.bookmark_border_outlined,
                                          color: kTextColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ]),
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    const CustomTile(),
                    Container(
                      color: kBackgroundColor,
                      child: const Padding(
                        padding: EdgeInsets.all(15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Duty solo vs Squard",
                              style: TextStyle(color: kTextColor),
                            ),
                            Text(
                              "2.7M views",
                              style: TextStyle(color: kTextColor),
                            )
                          ],
                        ),
                      ),
                    ),
                    // game image
                    Container(
                      height: 200,
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(),
                      child: const Image(
                        image: AssetImage("assets/trunk.png"),
                        fit: BoxFit.cover,
                      ),
                    ),
                    // call of duty mobile
                    Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(color: Colors.black),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 15, right: 15),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Padding(
                                        padding: EdgeInsets.only(
                                          left: 10,
                                        ),
                                        child: CommentTile(
                                          color: kTextColor,
                                          icon: Icons.thumb_up_alt_outlined,
                                        ),
                                      ),
                                      IconButton(
                                        onPressed: () {},
                                        icon: const Icon(
                                          Icons.bookmark_border_outlined,
                                          color: kTextColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ]),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                );
              },
            ),
            ListView.builder(
              itemCount: 10,
              itemBuilder: (BuildContext context, int index) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // customtile
                    const CustomTile(),
                    Container(
                      color: kBackgroundColor,
                      child: const Padding(
                        padding: EdgeInsets.all(15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Mortal Kombat",
                              style: TextStyle(color: kTextColor),
                            ),
                            Text(
                              "3.5M views",
                              style: TextStyle(color: kTextColor),
                            )
                          ],
                        ),
                      ),
                    ),
                    // game image
                    Container(
                      height: 200,
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(),
                      child: const Image(
                        image: AssetImage("assets/sniper.png"),
                        fit: BoxFit.cover,
                      ),
                    ),
                    // call of duty mobile
                    Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(color: kBackgroundColor),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 15, right: 15),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Padding(
                                        padding: EdgeInsets.only(
                                          left: 10,
                                        ),
                                        child: CommentTile(
                                          color: kTextColor,
                                          icon: Icons.thumb_up_alt_outlined,
                                        ),
                                      ),
                                      IconButton(
                                        onPressed: () {},
                                        icon: const Icon(
                                          Icons.bookmark_border_outlined,
                                          color: kTextColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ]),
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    const CustomTile(),
                    Container(
                      color: kBackgroundColor,
                      child: const Padding(
                        padding: EdgeInsets.all(15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Duty solo vs Squard",
                              style: TextStyle(color: kTextColor),
                            ),
                            Text(
                              "2.7M views",
                              style: TextStyle(color: kTextColor),
                            )
                          ],
                        ),
                      ),
                    ),
                    // game image
                    Container(
                      height: 200,
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(),
                      child: const Image(
                        image: AssetImage("assets/trunk.png"),
                        fit: BoxFit.cover,
                      ),
                    ),
                    // call of duty mobile
                    Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(color: kBackgroundColor),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 15, right: 15),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Padding(
                                        padding: EdgeInsets.only(
                                          left: 10,
                                        ),
                                        child: CommentTile(
                                          color: kTextColor,
                                          icon: Icons.thumb_up_alt_outlined,
                                        ),
                                      ),
                                      IconButton(
                                        onPressed: () {},
                                        icon: const Icon(
                                          Icons.bookmark_border_outlined,
                                          color: kTextColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ]),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                );
              },
            ),
            ListView.builder(
              itemCount: 10,
              itemBuilder: (BuildContext context, int index) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // customtile
                    const CustomTile(),
                    Container(
                      color: kBackgroundColor,
                      child: const Padding(
                        padding: EdgeInsets.all(15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Duty solo vs Squard ",
                              style: TextStyle(color: kTextColor),
                            ),
                            Text(
                              "3.5M views",
                              style: TextStyle(color: kTextColor),
                            )
                          ],
                        ),
                      ),
                    ),
                    // game image
                    Container(
                      height: 200,
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(),
                      child: const Image(
                        image: AssetImage("assets/trunk.png"),
                        fit: BoxFit.cover,
                      ),
                    ),
                    // call of duty mobile
                    Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(color: kBackgroundColor),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 15, right: 15),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Padding(
                                        padding: EdgeInsets.only(
                                          left: 10,
                                        ),
                                        child: CommentTile(
                                          color: kTextColor,
                                          icon: Icons.thumb_up_alt_outlined,
                                        ),
                                      ),
                                      IconButton(
                                        onPressed: () {},
                                        icon: const Icon(
                                          Icons.bookmark_border_outlined,
                                          color: kTextColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ]),
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    const CustomTile(),
                    Container(
                      color: kBackgroundColor,
                      child: const Padding(
                        padding: EdgeInsets.all(15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Duty solo vs Squard",
                              style: TextStyle(color: kTextColor),
                            ),
                            Text(
                              "2.7M views",
                              style: TextStyle(color: kTextColor),
                            )
                          ],
                        ),
                      ),
                    ),
                    // game image
                    Container(
                      height: 200,
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(),
                      child: const Image(
                        image: AssetImage("assets/trunk.png"),
                        fit: BoxFit.cover,
                      ),
                    ),
                    // call of duty mobile
                    Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: const BoxDecoration(color: kBackgroundColor),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 15, right: 15),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Padding(
                                        padding: EdgeInsets.only(
                                          left: 10,
                                        ),
                                        child: CommentTile(
                                          color: kTextColor,
                                          icon: Icons.thumb_up_alt_outlined,
                                        ),
                                      ),
                                      IconButton(
                                        onPressed: () {},
                                        icon: const Icon(
                                          Icons.bookmark_border_outlined,
                                          color: kTextColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ]),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
