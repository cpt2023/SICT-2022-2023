import 'package:flutter/material.dart';
import 'package:game_on/screens/navbar.dart';
import 'package:google_fonts/google_fonts.dart';

import '../user_auth/firebase_auth_impl/auth_exception.dart';
import '../user_auth/firebase_auth_impl/auth_service.dart';
import '../utils/app_colors.dart';
import '../utils/show_error_log.dart';
import 'forget_password.dart';
import 'timeline.dart';
import 'user_registration/sign_up.dart';

class SignIn extends StatefulWidget {
  const SignIn({super.key});

  @override
  State<SignIn> createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  bool _isVisible = false;

  final TextEditingController _password = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  void signUserIn() async {
    try {
      await AuthService.firebase().logIn(
        emailController: _emailController.text.trim(),
        passwordController: _password.text.trim(),
      );

      final user = AuthService.firebase().currentUser;
      if (user?.isEmailVerified ?? false) {
        // ignore: use_build_context_synchronously
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => const NavBar()),
          (Route<dynamic> route) => false,
        );
      } else {
        //users email is NOT verified
        // ignore: use_build_context_synchronously
        showErrorDialog(context, 'Please verify your Email', Colors.red);
      }
      // devtools.log(userCredential.toString());
    } on UserNotFoundAuthException {
      // ignore: use_build_context_synchronously
      await showErrorDialog(
        context,
        'User not found',
        Colors.yellow,
      );
    } on WrongPasswordAuthException {
      // ignore: use_build_context_synchronously
      await showErrorDialog(
        context,
        'Wrong credentails',
        Colors.red,
      );
    } on GenericAuthException {
      // ignore: use_build_context_synchronously
      await showErrorDialog(
        context,
        'Authentication error',
        Colors.red,
      );
    }
  }

  @override
  void dispose() {
    _emailController.dispose();
    _password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: kBackgroundColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Welcome Back",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: kTextColor,
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              Text(
                "Login to account to continue conections and viewing latest gaming updates",
                style: GoogleFonts.poppins(
                    textStyle: kbtn2text, color: kTextColor),
              ),
              const SizedBox(
                height: 15,
              ),
              TextFormField(
                style: const TextStyle(color: kTextColor),
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  fillColor: Color(0xff161626),
                  filled: true,
                  labelText: "Email",
                  labelStyle: const TextStyle(color: kTextColor),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: Color(0xff535353)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: kPrimaryColor),
                  ),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: _password,
                keyboardType: TextInputType.name,
                style: const TextStyle(color: kTextColor),
                obscureText: !_isVisible,
                decoration: InputDecoration(
                  suffixIcon: IconButton(
                    onPressed: () {
                      setState(() {
                        _isVisible = !_isVisible;
                      });
                    },
                    icon: Icon(
                        _isVisible ? Icons.visibility : Icons.visibility_off),
                  ),
                  fillColor: Color(0xff161626),
                  filled: true,
                  hintText: "password",
                  hintStyle: const TextStyle(color: kTextColor),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: Color(0xff535353)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: kPrimaryColor),
                  ),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const ForgetPassword(),
                        ),
                      );
                    },
                    child: Text(
                      "Forgot password",
                      style: GoogleFonts.poppins(
                          textStyle: kbtntext, color: kPrimaryColor),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 50,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: kPrimaryColor,
                          ),
                          onPressed: () {
                            signUserIn();
                          },
                          child: const Text(
                            "Proceed",
                            style: TextStyle(color: kTextColor),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 40,
              ),
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "Don't have an account?",
                      style: TextStyle(color: kTextColor),
                    ),
                    const SizedBox(
                      width: 2,
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const SignUp(),
                          ),
                        );
                      },
                      child: const Text(
                        "Sign up",
                        style: TextStyle(color: kPrimaryColor),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
