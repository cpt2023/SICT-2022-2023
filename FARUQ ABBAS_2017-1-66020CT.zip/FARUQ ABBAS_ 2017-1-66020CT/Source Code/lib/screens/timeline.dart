import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:game_on/createpost.dart/createPost.dart';
import 'package:game_on/screens/iphone_29.dart';
import 'package:game_on/screens/notification_screen.dart';

import '../components/customtile.dart';
import '../message/users_list.dart';
import '../utils/app_colors.dart';
import 'sign_in.dart';

class TimeLineScreen extends StatefulWidget {
  const TimeLineScreen({super.key});

  @override
  State<TimeLineScreen> createState() => TimeLineScreenState();
}

class TimeLineScreenState extends State<TimeLineScreen> {
  void logOut() async {
    await FirebaseAuth.instance.signOut();

    // ignore: use_build_context_synchronously
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const SignIn()),
      (Route<dynamic> route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        backgroundColor: kBackgroundColor,
        elevation: 0,
        leading: Container(
          padding: const EdgeInsets.only(left: 5),
          alignment: Alignment.center,
          child: Flexible(
            child: Text(
              "GameOn",
              textAlign: TextAlign.right,
              style: TextStyle(
                  color: kTextColor, fontSize: 12, fontWeight: FontWeight.bold),
            ),
          ),
        ),
        actions: [
          Row(
            children: [
              Container(
                width: 25,
                height: 25,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50),
                ),
                child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const Iphone29()));
                    },
                    child: Image.asset("assets/currentUser.png")),
              ),
              const SizedBox(
                width: 10,
              ),
              Padding(
                padding: const EdgeInsets.only(right: 15),
                child: Row(
                  children: [
                    GestureDetector(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const UserLists()));
                        },
                        child: Image.asset('assets/message.png')),

                    const SizedBox(
                      width: 10,
                    ),
                    GestureDetector(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const NotificationScreen()));
                        },
                        child: Image.asset('assets/note.png')),
                    const SizedBox(
                      width: 10,
                    ),
                    // IconButton(
                    //   icon: const Icon(
                    //     Icons.logout,
                    //     color: kTextColor,
                    //   ),
                    //   onPressed: () {
                    //     logOut();
                    //   },
                    // ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: ListView.builder(
          itemCount: 10,
          itemBuilder: (BuildContext context, int index) {
            return Column(
              children: [
                const SizedBox(
                  height: 10,
                ),
                Container(
                  color: kBackgroundColor,
                  child: Column(children: [
                    const CustomTile(),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 15),
                      child: Row(
                        children: [
                          Text(
                            "Checkout what i will be streaming today",
                            style: TextStyle(color: kTextColor),
                          ),
                          SizedBox(
                            width: 2,
                          ),
                          Text(
                            "@Dream Le..",
                            style: TextStyle(color: Colors.blue),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width,
                      height: 250,
                      child: const Image(
                        image: AssetImage("assets/post1.png"),
                        fit: BoxFit.cover,
                      ),
                    ),
                    buildMyIcons()
                  ]),
                ),
                const SizedBox(
                  height: 15,
                ),
                Container(
                  color: kBackgroundColor,
                  child: Column(children: [
                    const CustomTile(),
                    SizedBox(
                      width: MediaQuery.of(context).size.width,
                      height: 250,
                      child: const Image(
                        image: AssetImage("assets/post2.png"),
                        fit: BoxFit.cover,
                      ),
                    ),
                    buildMyIcons()
                  ]),
                ),
              ],
            );
          }),
    );
  }

  buildMyIcons() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                IconButton(
                  onPressed: () {},
                  icon: const Icon(
                    Icons.thumb_up_alt_outlined,
                    color: kPrimaryColor,
                  ),
                ),
                const SizedBox(
                  width: 2,
                ),
                const Text(
                  "2.4k",
                  style: TextStyle(color: kTextColor),
                ),
                const SizedBox(
                  width: 50,
                ),
                Image.asset('assets/message2.png'),
                const SizedBox(
                  width: 2,
                ),
                const Text(
                  "2.4k",
                  style: TextStyle(color: kTextColor),
                ),
              ],
            ),
            IconButton(
                onPressed: () {
                  // Navigator.of(context).push(
                  //     MaterialPageRoute(builder: (context) => CreatePost()));
                },
                icon: const Icon(
                  Icons.bookmark_border_outlined,
                  color: kTextColor,
                ))
          ],
        ),
      ],
    );
  }
}
