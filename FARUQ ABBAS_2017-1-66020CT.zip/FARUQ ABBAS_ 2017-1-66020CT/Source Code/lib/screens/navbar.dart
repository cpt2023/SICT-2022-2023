import 'package:flutter/material.dart';
import 'package:game_on/createpost.dart/createPost.dart';
import 'package:game_on/goLive/liveDetails.dart';
import 'package:game_on/goLive/livestream.dart';
import 'package:game_on/groups_message/groups.dart';
import 'package:game_on/screens/home.dart';
import 'package:game_on/screens/onboarding.dart';
import 'package:game_on/screens/timeline.dart';
import 'package:game_on/screens/videos_screen.dart';

class NavBar extends StatefulWidget {
  const NavBar({super.key});

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int selectedindex = 0;
  void onItemTap(int index) {
    if (index == 2) {
      showModalBottomSheet(
          isScrollControlled: true,
          backgroundColor: const Color.fromARGB(255, 1, 1, 32),
          shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(10), topRight: Radius.circular(10))),
          context: context,
          builder: (context) {
            return Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 25.0, vertical: 25.0),
              child: SizedBox(
                height: 100,
                child: Column(
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => CreatePost()));
                      },
                      child: Row(
                        children: [
                          Image.asset('assets/create.png'),
                          SizedBox(
                            width: 20,
                          ),
                          Text(
                            'Create Post',
                            style: TextStyle(color: Colors.white, fontSize: 15),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    const Divider(
                      thickness: 1,
                      color: Color(0xff535353),
                      height: 1,
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => LiveStream()));
                      },
                      child: Row(
                        children: [
                          Image.asset('assets/live11.png'),
                          SizedBox(
                            width: 20,
                          ),
                          Text(
                            'Go Live',
                            style: TextStyle(color: Colors.white, fontSize: 15),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          });

      // else {
      //   selectedindex == index;
      // }
    } else {
      setState(() {
        selectedindex = index;
      });
    }
  }

  final tabs = [
    TimeLineScreen(),
    HomePage(),
    //CreatePost(),
    LiveDetails(),
    Iphone19(),
    Groupss(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        elevation: 0,
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.black,
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: selectedindex == 0
                ? Container(
                    height: 51,
                    width: 51,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(17),
                        color: Colors.black),
                    child: Image.asset(
                      "assets/menu.png",
                      color: Colors.white,
                    ),
                  )
                : Image.asset(
                    "assets/menu.png",
                    color: Color(0xff6A6666),
                  ),
            label: "",
          ),
          BottomNavigationBarItem(
              icon: selectedindex == 1
                  ? Container(
                      height: 51,
                      width: 51,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(17),
                          color: Colors.black),
                      child: Image.asset(
                        "assets/search.png",
                        color: Colors.white,
                      ),
                    )
                  : Image.asset(
                      "assets/search.png",
                      color: Color(0xff6A6666),
                    ),
              label: ""),
          BottomNavigationBarItem(
              icon: selectedindex == 2
                  ? Container(
                      height: 51,
                      width: 51,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(17),
                          color: Colors.black),
                      child: Image.asset(
                        "assets/add.png",
                        color: Colors.white,
                      ),
                    )
                  : Image.asset(
                      "assets/add.png",
                      color: Color(0xff6A6666),
                    ),
              label: ""),
          BottomNavigationBarItem(
              icon: selectedindex == 3
                  ? Container(
                      height: 51,
                      width: 51,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(17),
                          color: Colors.black),
                      child: Image.asset(
                        "assets/video.png",
                        color: Colors.white,
                      ),
                    )
                  : Image.asset(
                      "assets/video.png",
                      color: Color(0xff6A6666),
                    ),
              label: ""),
          BottomNavigationBarItem(
            icon: selectedindex == 4
                ? Container(
                    height: 51,
                    width: 51,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(17),
                        color: Colors.black),
                    child: Image.asset(
                      "assets/people.png",
                      color: Colors.white,
                    ),
                  )
                : Image.asset(
                    "assets/people.png",
                    color: Color(0xff6A6666),
                  ),
            label: "",
          ),
        ],
        currentIndex: selectedindex,
        onTap: onItemTap,
      ),
      //end btn
      body: tabs[selectedindex],
    );
  }
}
