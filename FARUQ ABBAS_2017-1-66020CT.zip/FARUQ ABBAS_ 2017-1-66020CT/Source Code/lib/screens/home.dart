import 'package:flutter/material.dart';

import '../components/view_videos.dart';
import '../models/dicover.dart';
import '../models/peoples_group.dart';
import '../models/peoples_page.dart';
import '../utils/app_colors.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        backgroundColor: kBackgroundColor,
        appBar: AppBar(
          actions: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: kBackgroundColor,
              ),
              margin: const EdgeInsets.symmetric(
                horizontal: 10,
              ),
              width: 50,
              child: IconButton(
                onPressed: () {},
                icon: const Icon(
                  Icons.search_outlined,
                  size: 40,
                  color: kTextColor,
                ),
              ),
            ),
          ],
          elevation: 0,
          backgroundColor: Colors.black,
          title: Padding(
            padding: EdgeInsets.only(right: 25),
            child: TextField(
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: "Search",
                hintStyle: TextStyle(color: kTextColor),
                fillColor: kTabBarColor,
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: kBackgroundColor),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: kBackgroundColor),
                ),
              ),
            ),
          ),
          bottom: const TabBar(
            indicatorColor: kTextColor,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white,
            isScrollable: false,
            tabs: [
              Tab(
                text: "Discover",
              ),
              Tab(
                text: "Peoples",
              ),
              Tab(
                text: "Groups",
              ),
              Tab(
                text: "Videos",
              ),
              Tab(
                text: "Recent",
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            SingleChildScrollView(
              child: Container(
                width: MediaQuery.of(context).size.width,
                color: kBackgroundColor,
                child: Column(
                  children: [
                    // Peoples see all
                    Padding(
                      padding: const EdgeInsets.only(
                          left: kDefaultPadding, right: kDefaultPadding),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            "People",
                            style: TextStyle(color: kTextColor),
                          ),
                          TextButton(
                            onPressed: () {},
                            child: const Text(
                              "See all",
                              style: TextStyle(color: kPrimaryColor),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Discover(),

                    //Videos see all
                    Padding(
                      padding: const EdgeInsets.only(
                          left: kDefaultPadding, right: kDefaultPadding),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            "Videos",
                            style: TextStyle(color: kTextColor),
                          ),
                          TextButton(
                            onPressed: () {},
                            child: const Text(
                              "See all",
                              style: TextStyle(color: kPrimaryColor),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const ViewVideos(),

                    // Groups see all
                    Padding(
                      padding: const EdgeInsets.only(
                          left: kDefaultPadding, right: kDefaultPadding),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            "Groups",
                            style: TextStyle(color: kTextColor),
                          ),
                          TextButton(
                            onPressed: () {},
                            child: const Text(
                              "See all",
                              style: TextStyle(color: kPrimaryColor),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const Discover(),
                  ],
                ),
              ),
            ),
            const PeoplesPage(),
            const PeoplesGroups(),
            const Text("p"),
            const PeoplesGroups(),
          ],
        ),
      ),
    );
  }
}
