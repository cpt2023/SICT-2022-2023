import 'package:easy_splash_screen/easy_splash_screen.dart';
import 'package:flutter/material.dart';
import 'package:game_on/screens/navbar.dart';
import 'package:game_on/screens/user_registration/sign_up.dart';

import '../user_auth/firebase_auth_impl/auth_service.dart';
import '../utils/app_colors.dart';
import 'onboarding.dart';
import 'sign_in.dart';
import 'timeline.dart';

class GameOn extends StatefulWidget {
  const GameOn({super.key});

  @override
  State<GameOn> createState() => _GameOnState();
}

class _GameOnState extends State<GameOn> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: kBackgroundColor,
        body: MaterialApp(
            title: 'GameOn',
            debugShowCheckedModeBanner: false,
            home: EasySplashScreen(
              logo: Image.asset(
                'assets/logo.png',
                width: 200.0,
                height: 200.0,
              ),
              title: const Text(
                '',
                style: TextStyle(
                  color: kBackgroundColor,
                ),
              ),
              backgroundColor: kBackgroundColor,
              durationInSeconds: 2,
              showLoader: false,
              navigator: const Iphone2(),
            )));
  }
}

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: AuthService.firebase().initializer(),
      builder: (context, snapshot) {
        switch (snapshot.connectionState) {
          case ConnectionState.done:
            {
              final user = AuthService.firebase().currentUser;
              if (user != null) {
                if (user.isEmailVerified) {
                  return const TimeLineScreen();
                } else {
                  return const Center(
                    child: Text("Please Verify your email!!!"),
                  );
                }
              } else {
                return const SignIn();
              }
            }
          case ConnectionState.waiting:
            {
              return EasySplashScreen(
                logo: Image.asset(
                  'assets/logo.png',
                  width: 150.0,
                  height: 150.0,
                ),
                title: const Text(
                  '',
                  style: TextStyle(
                    color: kBackgroundColor,
                  ),
                ),
                backgroundColor: kBackgroundColor,
                durationInSeconds: 1,
                showLoader: false,
              );
            }

          default:
            return EasySplashScreen(
              logo: Image.asset(
                'assets/logo.png',
                width: 200.0,
                height: 200.0,
              ),
              title: const Text(
                '',
                style: TextStyle(
                  color: kBackgroundColor,
                ),
              ),
              backgroundColor: kBackgroundColor,
              navigator: const Iphone2(),
              durationInSeconds: 5,
            );
        }
      },
    );
  }
}
