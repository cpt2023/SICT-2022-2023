import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../user_auth/firebase_auth_impl/auth_exception.dart';
import '../user_auth/firebase_auth_impl/auth_service.dart';
import '../utils/app_colors.dart';
import '../utils/show_error_log.dart';
import '../utils/show_success_log.dart';
import 'sign_in.dart';

class ForgetPassword extends StatefulWidget {
  const ForgetPassword({super.key});

  @override
  State<ForgetPassword> createState() => _ForgetPasswordState();
}

class _ForgetPasswordState extends State<ForgetPassword> {
  final TextEditingController _emailController = TextEditingController();

  void forgetPassword() async {
    try {
      final res = await AuthService.firebase()
          .forgetPassword(emailController: _emailController.text.trim());

      // ignore: use_build_context_synchronously
      await showSuccessDialog(context, res, Colors.green);
      // ignore: use_build_context_synchronously
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const SignIn()),
        (Route<dynamic> route) => false,
      );
    } on GenericAuthException {
      // ignore: use_build_context_synchronously
      await showErrorDialog(
        context,
        'Authentication error',
        Colors.red,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: kBackgroundColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Forgot password",
              style: GoogleFonts.poppins(
                  textStyle: kBigheading, color: kTextColor),
            ),
            const SizedBox(
              height: 15,
            ),
            Text(
              "Forgot password? Lets us help you get back your account",
              style:
                  GoogleFonts.poppins(textStyle: kbtn2text, color: kTextColor),
            ),
            const SizedBox(
              height: 15,
            ),
            TextFormField(
              controller: _emailController,
              style: const TextStyle(
                color: kTextColor,
              ),
              decoration: InputDecoration(
                fillColor: kfillColor,
                filled: true,
                labelText: "Enter your email",
                labelStyle: const TextStyle(color: kTextColor),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: ksidebarcolor),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: kPrimaryColor),
                ),
              ),
            ),
            const SizedBox(
              height: 40,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kPrimaryColor,
                        ),
                        onPressed: () {
                          forgetPassword();
                        },
                        child: const Text(
                          "Send Reset Password",
                          style: TextStyle(color: kTextColor),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
