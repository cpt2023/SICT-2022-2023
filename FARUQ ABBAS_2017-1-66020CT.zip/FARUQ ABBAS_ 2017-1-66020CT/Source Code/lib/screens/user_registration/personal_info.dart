import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../utils/app_colors.dart';
import '../gender_selection.dart';

class PersonalInformation extends StatefulWidget {
  final String username;
  final String email;

  const PersonalInformation(
      {Key? key, required this.username, required this.email})
      : super(key: key);

  @override
  State<PersonalInformation> createState() => _PersonalInformationState();
}

class _PersonalInformationState extends State<PersonalInformation> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    super.dispose();
  }

  String fullName = "";
  String lastName = "";

  void _userData() {
    if (_formKey.currentState!.validate()) {
      final userDetails = {
        'email': widget.email,
        'username': widget.username,
        'firstName': _firstNameController.text,
        'lastName': _lastNameController.text,
      };

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => GenderSelection(
            userDetails: userDetails,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: kBackgroundColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Tell us more about you",
                  style: GoogleFonts.poppins(
                      textStyle: kBigheading, color: kTextColor),
                ),
                const SizedBox(
                  height: 15,
                ),
                Text(
                  "Enter the names that you use on your legal documents if possible",
                  style: GoogleFonts.poppins(
                      textStyle: kbtn2text, color: kTextColor),
                ),
                const SizedBox(
                  height: 15,
                ),
                TextFormField(
                  controller: _firstNameController,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return "Please enter your First name";
                    } else {
                      return null;
                    }
                  },
                  onSaved: (value) {
                    setState(() {
                      fullName = value!;
                    });
                  },
                  style: const TextStyle(color: kTextColor),
                  decoration: InputDecoration(
                    fillColor: kfillColor,
                    filled: true,
                    labelText: "First name",
                    labelStyle: const TextStyle(color: kTextColor),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: ksidebarcolor),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: kPrimaryColor),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                TextFormField(
                  controller: _lastNameController,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return "Please enter your Last name";
                    } else {
                      return null;
                    }
                  },
                  onSaved: (value) {
                    setState(() {
                      lastName = value!;
                    });
                  },
                  style: const TextStyle(color: kTextColor),
                  decoration: InputDecoration(
                    fillColor: kfillColor,
                    filled: true,
                    labelText: "Last name",
                    labelStyle: const TextStyle(color: kTextColor),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: ksidebarcolor),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: kPrimaryColor),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 40,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 40),
                  child: Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 50,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(kDefaultPadding),
                              backgroundColor: kPrimaryColor,
                            ),
                            onPressed: () {
                              _userData();
                            },
                            child: const Text(
                              "Next",
                              style: TextStyle(color: kTextColor),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 150,
                ),
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        "",
                        style: TextStyle(color: kTextColor),
                      ),
                      const SizedBox(
                        width: 2,
                      ),
                      TextButton(
                        onPressed: () {},
                        child: const Text(
                          "",
                          style: TextStyle(color: kPrimaryColor),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
