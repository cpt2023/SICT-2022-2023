import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../user_auth/firebase_user_service/firebase_user_service.dart';
import '../../utils/app_colors.dart';
import 'personal_info.dart';

class UserName extends StatefulWidget {
  final String email;
  const UserName({Key? key, required this.email}) : super(key: key);

  @override
  State<UserName> createState() => _UserNameState();
}

class _UserNameState extends State<UserName> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _usernameController = TextEditingController();
  final FirebaseUserService _firebaseUserService = FirebaseUserService();

  Future<bool> checkUsernameAvailability(String username) async {
    return _firebaseUserService.usernameCheck(username);
  }

  void _handleUsernameCheck() async {
    if (_formKey.currentState!.validate()) {
      final username = _usernameController.text;
      final isUnique = await checkUsernameAvailability(username);

      if (isUnique) {
        // Username is unique, you can proceed
        // ignore: use_build_context_synchronously
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>
                PersonalInformation(username: username, email: widget.email),
          ),
        );
      } else {
        // Username is already in use, display an error message
        // ignore: use_build_context_synchronously
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
                'Username is already in use. Please choose a different username.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  String username = "";

  @override
  void dispose() {
    _usernameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: kBackgroundColor,
      ),
      body: Form(
        key: _formKey,
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Choose Username",
                  style: GoogleFonts.poppins(
                      textStyle: kBigheading, color: kTextColor),
                ),
                const SizedBox(
                  height: 15,
                ),
                Text(
                  "You can always change username later",
                  style: GoogleFonts.poppins(
                      textStyle: kbtn2text, color: kTextColor),
                ),
                const SizedBox(
                  height: 15,
                ),
                TextFormField(
                  controller: _usernameController,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return "Please choose a Username";
                    } else {
                      return null;
                    }
                  },
                  onSaved: (value) {
                    setState(() {
                      username = value!;
                    });
                  },
                  style: const TextStyle(color: kTextColor),
                  decoration: InputDecoration(
                    fillColor: Color.fromARGB(255, 28, 28, 48),
                    filled: true,
                    labelText: "Enter your username",
                    labelStyle: const TextStyle(color: kTextColor),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: ksidebarcolor),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: kPrimaryColor),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 40,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 50,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.all(kDefaultPadding),
                              backgroundColor: kPrimaryColor,
                            ),
                            onPressed: () {
                              _handleUsernameCheck();
                            },
                            child: const Text(
                              "Next",
                              style: TextStyle(color: kTextColor),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 200,
                ),
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        "",
                        style: TextStyle(color: kTextColor),
                      ),
                      const SizedBox(
                        width: 2,
                      ),
                      TextButton(
                        onPressed: () {},
                        child: const Text(
                          "",
                          style: TextStyle(color: kPrimaryColor),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
