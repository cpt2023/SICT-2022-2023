import 'package:flutter/material.dart';

import '../../components/groups.dart';
import '../../utils/app_colors.dart';

class RecentScreen extends StatefulWidget {
  const RecentScreen({super.key});

  @override
  State<RecentScreen> createState() => _RecentScreenState();
}

class _RecentScreenState extends State<RecentScreen> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 1,
      child: Scaffold(
        backgroundColor: kBackgroundColor,
        appBar: AppBar(
          actions: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: kPrimaryColor,
              ),
              margin: const EdgeInsets.symmetric(
                horizontal: 10,
              ),
              width: 50,
              child: IconButton(
                onPressed: () {},
                icon: const Icon(
                  Icons.search_outlined,
                  size: 40,
                  color: kTextColor,
                ),
              ),
            ),
          ],
          elevation: 0,
          backgroundColor: kBackgroundColor,
          title: const Padding(
            padding: EdgeInsets.only(right: 25),
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search",
                hintStyle: TextStyle(color: kTextColor),
                fillColor: kTabBarColor,
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: kTextColor),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: kPrimaryColor),
                ),
              ),
            ),
          ),
          bottom: const TabBar(tabs: [
            Tab(
              text: "Recent",
            )
          ]),
        ),
        body: TabBar(tabs: [
          Padding(
            padding: const EdgeInsets.all(kDefaultPadding),
            child: ListView.builder(
              itemCount: 6,
              itemBuilder: (BuildContext context, int index) {
                return const Column(
                  children: [Groups()],
                );
              },
            ),
          ),
        ]),
      ),
    );
  }
}
