import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../user_auth/firebase_auth_impl/firebase_auth_service.dart';
import '../../utils/app_colors.dart';
import '../sign_in.dart';
import 'choose_username.dart';

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  final FirebaseAuthService _auth = FirebaseAuthService();

  final _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final email = _emailController.text;
      if (email.isNotEmpty) {
        _auth.emailCheck(email).then((isEmailAvailable) {
          if (isEmailAvailable) {
            Navigator.push(context, MaterialPageRoute(builder: (context) {
              return UserName(email: email);
            }));
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text(
                    'Email is already in use. Please use a different email.'),
                backgroundColor: Colors.red,
              ),
            );
          }
        }).catchError((error) {
          print('Error checking email uniqueness: $error');
          // Handle the error, e.g., show an error message
        });
      } else {
        print('Email uniqueness');
        // Handle the case where the email is empty (you might want to show an error message)
      }
    }
  }

  String email = "";

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: kBackgroundColor,
      ),
      body: Form(
        key: _formKey,
        child: Padding(
          padding: const EdgeInsets.all(kDefaultPadding),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Create Account",
                  style: GoogleFonts.poppins(
                      textStyle: kBigheading, color: kTextColor),
                ),
                const SizedBox(
                  height: 15,
                ),
                Text(
                  "Create account, follow other gamers share posts and more",
                  style: GoogleFonts.poppins(
                      textStyle: kbtn2text, color: kTextColor),
                ),
                const SizedBox(
                  height: 15,
                ),
                TextFormField(
                  controller: _emailController,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return "Please enter your email";
                    } else {
                      return null;
                    }
                  },
                  onSaved: (value) {
                    setState(() {
                      email = value!;
                    });
                  },
                  style: const TextStyle(color: kTextColor),
                  decoration: InputDecoration(
                    labelText: "Enter your email",
                    labelStyle: const TextStyle(color: kTextColor),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: kTextColor),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide:
                          const BorderSide(width: 1, color: kPrimaryColor),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 40,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 40),
                  child: Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 50,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: kPrimaryColor,
                            ),
                            onPressed: () {
                              // Navigator.push(
                              //   context,
                              //   MaterialPageRoute(
                              //     builder: (context) => const UserName(),
                              //   ),
                              // );

                              _submitForm();
                            },
                            child: const Text(
                              "Proceed",
                              style: TextStyle(color: kTextColor),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 70,
                ),
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        "Already have an account?",
                        style: TextStyle(color: kTextColor),
                      ),
                      const SizedBox(
                        width: 2,
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const SignIn(),
                            ),
                          );
                        },
                        child: const Text(
                          "Login",
                          style: TextStyle(color: kPrimaryColor),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
