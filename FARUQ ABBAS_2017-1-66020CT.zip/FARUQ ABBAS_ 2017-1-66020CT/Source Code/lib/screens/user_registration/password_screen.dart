import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../user_auth/firebase_auth_impl/auth_exception.dart';
import '../../user_auth/firebase_auth_impl/auth_service.dart';
import '../../utils/app_colors.dart';
import '../../utils/show_error_log.dart';
import '../sign_in.dart';

class PasswordScreen extends StatefulWidget {
  final Map<String, String> updatedUserData;

  const PasswordScreen({Key? key, required this.updatedUserData})
      : super(key: key);

  @override
  State<PasswordScreen> createState() => _PasswordScreenState();
}

class _PasswordScreenState extends State<PasswordScreen> {
  bool _isVisible = false;
  bool _isConfirmVisible = false;
  bool _isPasswordEightCharacters = false;
  bool _hasPasswordOneNumber = false;
  bool _hasPasswordUppercase = false;
  bool _hasPasswordUniqueCharacters = false;

  onPasswordChanged(String password) {
    final numericRegex = RegExp(r'[0-9]');
    final stringRegex = RegExp(r'[A-Z]');
    final intRegex = RegExp(r'[!,@,#,^,*_,+,?,~,`,&,]');
    setState(() {
      _isPasswordEightCharacters = false;
      if (password.length >= 8) _isPasswordEightCharacters = true;

      _hasPasswordOneNumber = false;
      if (numericRegex.hasMatch(password)) _hasPasswordOneNumber = true;

      _hasPasswordUppercase = false;

      if (stringRegex.hasMatch(password)) _hasPasswordUppercase = true;

      _hasPasswordUniqueCharacters = false;
      if (intRegex.hasMatch(password)) _hasPasswordUniqueCharacters = true;
    });
  }

  final TextEditingController _confirmpassword = TextEditingController();

  final TextEditingController _password = TextEditingController();

  bool areAllConditionsMet() {
    return _isPasswordEightCharacters &&
        _hasPasswordUppercase &&
        _hasPasswordOneNumber &&
        _hasPasswordUniqueCharacters;
  }

  void _submitPassword() async {
    if (areAllConditionsMet()) {
      final finalPassword = _password.text;

      final previousUserData = widget.updatedUserData;

      final updatedUserData = Map<String, String>.from(previousUserData);
      updatedUserData['password'] = finalPassword;

      try {
        await AuthService.firebase().createUser(
          emailController: updatedUserData['email']!,
          firstNameController: updatedUserData['firstName']!,
          lastNameController: updatedUserData['lastName']!,
          passwordController: finalPassword,
          usernameController: updatedUserData['username']!,
          genderController: updatedUserData['gender']!,
        );
        // final user = FirebaseAuth.instance.currentUser;
        AuthService.firebase().sendEmailVerification();
        // ignore: use_build_context_synchronously
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Registration successful. Verification email sent."),
            backgroundColor: Colors.green,
          ),
        );
        // ignore: use_build_context_synchronously
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => const SignIn()),
          (Route<dynamic> route) => false,
        );
      } on WeakPasswordAuthException {
        // ignore: use_build_context_synchronously
        await showErrorDialog(
          context,
          'Weak Password',
          Colors.yellow.shade900,
        );
      } on EmailAlreadyInUseAuthException {
        // ignore: use_build_context_synchronously
        await showErrorDialog(
          context,
          'Email already in use',
          Colors.yellow.shade900,
        );
      } on InvalidEmailAuthException {
        // ignore: use_build_context_synchronously
        await showErrorDialog(
          context,
          'Invalid Email',
          Colors.yellow.shade900,
        );
      } on GenericAuthException {
        // ignore: use_build_context_synchronously
        await showErrorDialog(context, 'Failed to register', Colors.red);
      }
    }
  }

  @override
  void dispose() {
    _confirmpassword.dispose();
    _password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: kBackgroundColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Create password",
                style: GoogleFonts.poppins(
                    textStyle: kBigheading, color: kTextColor),
              ),
              const SizedBox(
                height: 15,
              ),
              Text(
                "Make use of a long password to maintain account security",
                style: GoogleFonts.poppins(
                    textStyle: kbtn2text, color: kTextColor),
              ),
              const SizedBox(
                height: 15,
              ),

              // ppassword
              TextFormField(
                controller: _password,
                style: const TextStyle(color: kTextColor),
                onChanged: (password) => onPasswordChanged(password),
                obscureText: !_isVisible,
                decoration: InputDecoration(
                  suffixIcon: IconButton(
                    onPressed: () {
                      setState(() {
                        _isVisible = !_isVisible;
                      });
                    },
                    icon: Icon(
                        _isVisible ? Icons.visibility : Icons.visibility_off),
                  ),
                  fillColor: kfillColor,
                  filled: true,
                  hintText: "password",
                  hintStyle: const TextStyle(color: kTextColor),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: ksidebarcolor),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: ksidebarcolor),
                  ),
                ),
              ),
              const SizedBox(
                height: 15,
              ),

              // comfirm password
              TextField(
                controller: _confirmpassword,
                onChanged: (confirmpassword) =>
                    onPasswordChanged(confirmpassword),
                style: const TextStyle(color: kTextColor),
                obscureText: !_isConfirmVisible,
                decoration: InputDecoration(
                  suffixIcon: IconButton(
                    onPressed: () {
                      setState(() {
                        _isConfirmVisible = !_isConfirmVisible;
                      });
                    },
                    icon: Icon(_isConfirmVisible
                        ? Icons.visibility
                        : Icons.visibility_off),
                  ),
                  fillColor: kfillColor,
                  filled: true,
                  hintText: "Comfirm password",
                  hintStyle: const TextStyle(color: kTextColor),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: ksidebarcolor),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: ksidebarcolor),
                  ),
                ),
              ),
              const SizedBox(
                height: 20,
              ),

              // ElevatedButton
              Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kPrimaryColor,
                          padding: const EdgeInsets.all(
                            kDefaultPadding,
                          ),
                        ),
                        onPressed: () {
                          _submitPassword();
                        },
                        child: const Text(
                          "Register",
                          style: TextStyle(color: kTextColor),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),

              // Minimum of 8 character
              Row(
                children: [
                  Icon(
                    _isPasswordEightCharacters
                        ? Icons.check_circle
                        : Icons.circle_outlined,
                    weight: .2,
                    color: _isPasswordEightCharacters
                        ? kPrimaryColor
                        : Colors.white.withOpacity(.4),
                  ),
                  const SizedBox(width: 20),
                  const Text(
                    "Minimum of 8 characters",
                    style: TextStyle(color: kTextColor),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),

              Row(
                children: [
                  Icon(
                    _hasPasswordUppercase
                        ? Icons.check_circle
                        : Icons.circle_outlined,
                    weight: .2,
                    color: _hasPasswordUppercase
                        ? kPrimaryColor
                        : Colors.white.withOpacity(.4),
                  ),
                  const SizedBox(width: 20),
                  const Text(
                    "Uppercase",
                    style: TextStyle(color: kTextColor),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),

              // Numeric characters
              Row(
                children: [
                  Icon(
                    _hasPasswordOneNumber
                        ? Icons.check_circle
                        : Icons.circle_outlined,
                    weight: .2,
                    color: _hasPasswordOneNumber
                        ? kPrimaryColor
                        : Colors.white.withOpacity(.4),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  const Text(
                    "Numeric digits",
                    style: TextStyle(color: kTextColor),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),

              // unique character e.g [!,@,#,$,%,^]
              Row(
                children: [
                  Icon(
                    _hasPasswordUniqueCharacters
                        ? Icons.check_circle
                        : Icons.circle_outlined,
                    weight: .2,
                    color: _hasPasswordUniqueCharacters
                        ? kPrimaryColor
                        : Colors.white.withOpacity(.4),
                  ),
                  const SizedBox(width: 20),
                  const Text(
                    "Unique characters eg: # * & %",
                    style: TextStyle(color: kTextColor),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
