import 'package:flutter/material.dart';

import '../../models/muted_row.dart';
import '../../models/robby_unmute.dart';
import '../../utils/app_colors.dart';
import 'umar_follow_unf.dart';

class MutedAccounts extends StatefulWidget {
  const MutedAccounts({super.key});

  @override
  State<MutedAccounts> createState() => _MutedAccountsState();
}

class _MutedAccountsState extends State<MutedAccounts> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: kBackgroundColor,
        leading: IconButton(
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const UmarFollowUnfollow()));
            },
            icon: Icon(
              Icons.adaptive.arrow_back,
              color: kTextColor,
            )),
        centerTitle: true,
        title: const Text(
          "Muted accounts",
          style: TextStyle(
              color: kTextColor, fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(kDefaultPadding),
        child: ListView(
          children: const [
            MutedRow(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
            RobbyUnmmute(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
            RobbyUnmmute(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
            RobbyUnmmute(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
            RobbyUnmmute(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
            RobbyUnmmute(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
            RobbyUnmmute(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
            RobbyUnmmute(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
