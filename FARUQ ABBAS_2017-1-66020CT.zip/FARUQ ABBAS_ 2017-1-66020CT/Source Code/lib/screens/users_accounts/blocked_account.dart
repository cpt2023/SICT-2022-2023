import 'package:flutter/material.dart';

import '../../models/blocked_row.dart';
import '../../models/robby_blocked_row.dart';
import '../../utils/app_colors.dart';
import 'muted_account.dart';


class BlockedAccount extends StatefulWidget {
  const BlockedAccount({super.key});

  @override
  State<BlockedAccount> createState() => _BlockedAccountState();
}

class _BlockedAccountState extends State<BlockedAccount> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: kBackgroundColor,
        leading: IconButton(
          onPressed: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const MutedAccounts(),
                ));
          },
          icon: Icon(
            Icons.adaptive.arrow_back,
            color: kTextColor,
          ),
        ),
        centerTitle: true,
        title: const Text(
          "Blocked accounts",
          style: TextStyle(
              color: kTextColor, fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(kDefaultPadding),
        child: ListView(
          children: const [
            BlockedRow(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
            RobbyBlocked(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
            RobbyBlocked(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
            RobbyBlocked(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
            RobbyBlocked(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
            RobbyBlocked(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
            RobbyBlocked(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
            RobbyBlocked(),
            Padding(
              padding: EdgeInsets.only(left: 50),
              child: Divider(
                color: kTabBarColor,
                thickness: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
