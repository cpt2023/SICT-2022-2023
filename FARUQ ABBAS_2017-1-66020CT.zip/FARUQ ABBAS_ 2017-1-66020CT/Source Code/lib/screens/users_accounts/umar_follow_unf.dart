import 'package:flutter/material.dart';

import '../../createpost.dart/createPost.dart';
import '../../goLive/endlivestream.dart';
import '../../models/umar_followers.dart';
import '../../utils/app_colors.dart';
import 'blocked_account.dart';
import 'edit_profile.dart';

class UmarFollowUnfollow extends StatefulWidget {
  const UmarFollowUnfollow({super.key});

  @override
  State<UmarFollowUnfollow> createState() => _UmarFollowUnfollowState();
}

class _UmarFollowUnfollowState extends State<UmarFollowUnfollow> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: kBackgroundColor,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: kBackgroundColor,
          leading: IconButton(
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const BlockedAccount(),
                  ));
            },
            icon: Icon(
              Icons.adaptive.arrow_back,
              color: kTextColor,
            ),
          ),
          centerTitle: true,
          title: const Text(
            "Umar Farouk",
            style: TextStyle(
                color: kTextColor, fontSize: 20, fontWeight: FontWeight.bold),
          ),
          bottom: const TabBar(
            indicatorColor: kTextColor,
            tabs: [
              Tab(
                text: "Followers",
              ),
              Tab(
                text: "Following",
              ),
            ],
          ),
        ),
        body: TabBarView(children: [
          ListView(
            children: [
              ListTile(
                leading: const CircleAvatar(
                  radius: 20,
                  backgroundImage: AssetImage("assets/guy.png"),
                ),
                title: const Text(
                  "Call of Duty",
                  style: TextStyle(
                      color: kTextColor,
                      fontSize: 10,
                      fontWeight: FontWeight.w200),
                ),
                subtitle: const Text(
                  "Mobile game.24M followers\n 10 + posts last week",
                  style: TextStyle(
                    color: kTextColor,
                    fontSize: 10,
                  ),
                ),
                trailing: ElevatedButton(
                  style:
                      ElevatedButton.styleFrom(backgroundColor: kPrimaryColor),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const EditProfile(),
                      ),
                    );
                  },
                  child: const Text(
                    "Follow",
                    style: TextStyle(color: kTextColor),
                  ),
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              const Umflls(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              buildUnfollow(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              buildRobby(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              buildRobby(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              buildRobby(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              buildRobby(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              buildRobby(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              buildRobby(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
            ],
          ),
          ListView(
            children: [
              ListTile(
                leading: const CircleAvatar(
                  radius: 20,
                  backgroundImage: AssetImage("assets/guy.png"),
                ),
                title: const Text(
                  "Call of Duty",
                  style: TextStyle(
                      color: kTextColor,
                      fontSize: 10,
                      fontWeight: FontWeight.w200),
                ),
                subtitle: const Text(
                  "Mobile game.24M followers\n 10 + posts last week",
                  style: TextStyle(
                    color: kTextColor,
                    fontSize: 10,
                  ),
                ),
                trailing: ElevatedButton(
                  style:
                      ElevatedButton.styleFrom(backgroundColor: kTabBarColor),
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const CreatePost()));
                  },
                  child: const Text(
                    "Unfollow",
                    style: TextStyle(color: kTextColor),
                  ),
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              const Umflls(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              buildUnfollow(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              buildRobby(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              buildRobby(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              buildRobby(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              buildRobby(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              buildRobby(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
              buildRobby(),
              const Padding(
                padding: EdgeInsets.only(left: 60),
                child: Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
              ),
            ],
          ),
        ]),
      ),
    );
  }

  buildUnfollow() {
    return Column(
      children: [
        ListTile(
          leading: const CircleAvatar(
            radius: 20,
            child: Image(
              image: AssetImage("assets/cap.png"),
            ),
          ),
          title: const Text(
            "Droid Villaz",
            style: TextStyle(
                color: kTextColor, fontSize: 10, fontWeight: FontWeight.bold),
          ),
          subtitle: const Text(
            "Umar Farouk.2k followers",
            style: TextStyle(color: kTextColor, fontSize: 10),
          ),
          trailing: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kTabBarColor),
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const EndliveStream()));
            },
            child: const Text(
              "Unfollow",
              style: TextStyle(
                color: kTextColor,
              ),
            ),
          ),
        ),
      ],
    );
  }

  buildRobby() {
    return Column(
      children: [
        ListTile(
          leading: const CircleAvatar(
            radius: 20,
            child: Image(
              image: AssetImage("assets/cap.png"),
            ),
          ),
          title: const Text(
            "Droid Villaz",
            style: TextStyle(
                color: kTextColor, fontSize: 10, fontWeight: FontWeight.bold),
          ),
          subtitle: const Text(
            "Umar Farouk.2k followers",
            style: TextStyle(color: kTextColor, fontSize: 10),
          ),
          trailing: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kTabBarColor),
            onPressed: () {},
            child: const Text(
              "Unfollow",
              style: TextStyle(
                color: kTextColor,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
