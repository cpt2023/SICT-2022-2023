import 'package:flutter/material.dart';

import '../../components/customtile.dart';
import '../../utils/app_colors.dart';

class Saved extends StatefulWidget {
  const Saved({super.key});

  @override
  State<Saved> createState() => _SavedState();
}

class _SavedState extends State<Saved> {
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: kBackgroundColor,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: kBackgroundColor,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.adaptive.arrow_back,
              color: kTextColor,
            ),
          ),
          centerTitle: true,
          title: const Text(
            "Saved",
            style: TextStyle(
                color: kTextColor, fontSize: 20, fontWeight: FontWeight.bold),
          ),
          bottom: const TabBar(
            indicatorColor: kTextColor,
            tabs: [
              Tab(
                text: "Posts",
              ),
              Tab(
                text: "Streams",
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            ListView.builder(
              itemCount: 10,
              itemBuilder: (BuildContext context, int index) {
                return Column(
                  children: [
                    const CustomTile(),
                    Container(
                      color: kBackgroundColor,
                      child: const Padding(
                        padding: EdgeInsets.all(15),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Call Of Duty Battle Royal",
                                style: TextStyle(color: kTextColor),
                              ),
                              Text(
                                "2.7M viewers",
                                style: TextStyle(color: kTextColor),
                              ),
                            ]),
                      ),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width,
                      height: 200,
                      child: const Image(
                        image: AssetImage("assets/duty.png"),
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      color: kBackgroundColor,
                      child: Row(
                        children: [
                          IconButton(
                              onPressed: () {},
                              icon: const Icon(
                                Icons.thumb_up_alt,
                                color: kPrimaryColor,
                              )),
                          const SizedBox(
                            width: 2,
                          ),
                          const Text(
                            "2.4k",
                            style: TextStyle(color: kTextColor),
                          ),
                          const SizedBox(
                            width: 20,
                          ),
                          IconButton(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.message,
                              color: kPrimaryColor,
                            ),
                          ),
                          const SizedBox(
                            width: 2,
                          ),
                          const Text(
                            "2.4k",
                            style: TextStyle(color: kTextColor),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    const CustomTile(),
                    Container(
                      color: kBackgroundColor,
                      child: const Padding(
                        padding: EdgeInsets.all(15),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Call Of Duty Battle Royal",
                                style: TextStyle(color: kTextColor),
                              ),
                              Text(
                                "2.7M viewers",
                                style: TextStyle(color: kTextColor),
                              ),
                            ]),
                      ),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width,
                      height: 200,
                      child: const Image(
                        image: AssetImage("assets/trunk.png"),
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      color: kBackgroundColor,
                      child: Row(
                        children: [
                          IconButton(
                              onPressed: () {},
                              icon: const Icon(
                                Icons.thumb_up_alt,
                                color: kPrimaryColor,
                              )),
                          const SizedBox(
                            width: 2,
                          ),
                          const Text(
                            "2.4k",
                            style: TextStyle(color: kTextColor),
                          ),
                          const SizedBox(
                            width: 20,
                          ),
                          IconButton(
                            onPressed: () {
                              showModalBottomSheet(
                                  isScrollControlled: true,
                                  backgroundColor: kBackgroundColor,
                                  context: context,
                                  builder: (context) {
                                    return Container(
                                      width: MediaQuery.of(context).size.width,
                                      height: height / 1.3,
                                      decoration: const BoxDecoration(
                                        color: kBackgroundColor,
                                        borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(50),
                                          topRight: Radius.circular(50),
                                        ),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(
                                            kDefaultPadding),
                                        child: Column(
                                          children: [
                                            Row(
                                              children: [
                                                Container(
                                                  height: 5,
                                                  width: 100,
                                                  color: kTabBarColor,
                                                )
                                              ],
                                            ),

                                            //  Save post
                                            InkWell(
                                              onTap: () {},
                                              child: const ListTile(
                                                leading: Icon(
                                                  Icons
                                                      .bookmark_border_outlined,
                                                  color: kTextColor,
                                                ),
                                                title: Text(
                                                  "Save post",
                                                  style: TextStyle(
                                                      color: kTextColor),
                                                ),
                                              ),
                                            ),
                                            const Padding(
                                              padding:
                                                  EdgeInsets.only(left: 50),
                                              child: Divider(
                                                color: kTabBarColor,
                                                thickness: 1,
                                              ),
                                            ),
                                            InkWell(
                                              onTap: () {},
                                              child: const ListTile(
                                                leading: Icon(
                                                  Icons.hourglass_disabled,
                                                  color: kTextColor,
                                                ),
                                                title: Text(
                                                  "Copy post URL",
                                                  style: TextStyle(
                                                      color: kTextColor),
                                                ),
                                              ),
                                            ),
                                            const Padding(
                                              padding:
                                                  EdgeInsets.only(left: 50),
                                              child: Divider(
                                                color: kTabBarColor,
                                                thickness: 1,
                                              ),
                                            ),

                                            // mute
                                            InkWell(
                                              onTap: () {},
                                              child: const ListTile(
                                                leading: Icon(
                                                  Icons.signal_wifi_bad,
                                                  color: kTextColor,
                                                ),
                                                title: Text(
                                                  "Mute",
                                                  style: TextStyle(
                                                      color: kTextColor),
                                                ),
                                              ),
                                            ),
                                            const Padding(
                                              padding:
                                                  EdgeInsets.only(left: 50),
                                              child: Divider(
                                                color: kTabBarColor,
                                                thickness: 1,
                                              ),
                                            ),

                                            // unfollow
                                            InkWell(
                                              onTap: () {},
                                              child: const ListTile(
                                                leading: Icon(
                                                  Icons
                                                      .bookmark_border_outlined,
                                                  color: kTextColor,
                                                ),
                                                title: Text(
                                                  "Unfollow",
                                                  style: TextStyle(
                                                      color: kTextColor),
                                                ),
                                              ),
                                            ),
                                            const Padding(
                                              padding:
                                                  EdgeInsets.only(left: 50),
                                              child: Divider(
                                                color: kTabBarColor,
                                                thickness: 1,
                                              ),
                                            ),

                                            // Repost
                                            InkWell(
                                              onTap: () {},
                                              child: const ListTile(
                                                leading: Icon(
                                                  Icons.message_outlined,
                                                  color: kTextColor,
                                                ),
                                                title: Text(
                                                  "Repost",
                                                  style: TextStyle(
                                                      color: kTextColor),
                                                ),
                                              ),
                                            ),
                                            const Padding(
                                              padding:
                                                  EdgeInsets.only(left: 50),
                                              child: Divider(
                                                color: kTabBarColor,
                                                thickness: 1,
                                              ),
                                            ),

                                            // Block
                                            InkWell(
                                              onTap: () {},
                                              child: const ListTile(
                                                leading: Icon(
                                                  Icons.block_outlined,
                                                  color: Colors.red,
                                                ),
                                                title: Text(
                                                  "Block",
                                                  style: TextStyle(
                                                      color: kTextColor),
                                                ),
                                              ),
                                            ),
                                            const Padding(
                                              padding:
                                                  EdgeInsets.only(left: 50),
                                              child: Divider(
                                                color: kTabBarColor,
                                                thickness: 1,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  });
                            },
                            icon: const Icon(
                              Icons.message,
                              color: kTextColor,
                            ),
                          ),
                          const SizedBox(
                            width: 2,
                          ),
                          const Text(
                            "2.4k",
                            style: TextStyle(color: kTextColor),
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
            const Text(
              "Stream",
              style: TextStyle(color: kTextColor),
            ),
          ],
        ),
      ),
    );
  }
}
