import 'package:flutter/material.dart';

import '../../utils/app_colors.dart';
import 'saved.dart';

class EditProfile extends StatefulWidget {
  const EditProfile({super.key});

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              width: MediaQuery.of(context).size.width,
              height: 300,
              decoration: const BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("assets/guy.png"), fit: BoxFit.cover)),
              child: Padding(
                padding: const EdgeInsets.all(kDefaultPadding),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      decoration: const BoxDecoration(
                          shape: BoxShape.circle, color: kTabBarColor),
                      child: IconButton(
                          onPressed: () {
                            Navigator.pop(context);
                            // Navigator.push(
                            //     context,
                            //     MaterialPageRoute(
                            //         builder: (context) => const Saved()));
                          },
                          icon: Icon(
                            Icons.adaptive.arrow_back,
                            color: kTextColor,
                          )),
                    ),
                    const SizedBox(
                      height: 60,
                    ),
                    Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          IconButton(
                              onPressed: () {},
                              icon: const Icon(
                                Icons.edit_note_outlined,
                                color: kTextColor,
                                size: 20,
                              )),
                          Column(
                            children: [
                              TextButton(
                                onPressed: () {},
                                child: const Text(
                                  "Tap to replace\n cover image",
                                  style: TextStyle(
                                      color: kTextColor,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            ListTile(
              title: const Text(
                "Droid Villaz",
                style: TextStyle(color: kTextColor, fontSize: 10),
              ),
              subtitle: const Text(
                "COD fan",
                style: TextStyle(color: kTextColor, fontSize: 10),
              ),
              leading: CircleAvatar(
                radius: 15,
                backgroundImage: const AssetImage("assets/guy.png"),
                child: Center(
                  child: IconButton(
                      onPressed: () {},
                      icon: const Icon(
                        Icons.edit_note,
                        color: kTextColor,
                      )),
                ),
              ),
            ),
            Expanded(
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: kDefaultPadding),
                color: kBackgroundColor,
                child: SingleChildScrollView(
                    child: Column(
                  children: [
                    // Name
                    TextFormField(
                      keyboardType: TextInputType.name,
                      decoration: const InputDecoration(
                        hintStyle: TextStyle(color: kTextColor),
                        hintText: "Name\nUmar Farouk",
                        labelStyle: TextStyle(color: kTextColor),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: kTextColor,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: kPrimaryColor,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),

                    //Username
                    TextFormField(
                      keyboardType: TextInputType.name,
                      decoration: const InputDecoration(
                        hintStyle: TextStyle(color: kTextColor),
                        hintText: "Username",
                        labelStyle: TextStyle(color: kTextColor),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: kTextColor,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: kPrimaryColor,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    //Gender
                    TextFormField(
                      keyboardType: TextInputType.name,
                      decoration: const InputDecoration(
                        hintStyle: TextStyle(color: kTextColor),
                        hintText: "Gender",
                        labelStyle: TextStyle(color: kTextColor),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: kTextColor,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: kPrimaryColor,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),

                    //Email
                    TextFormField(
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        hintStyle: TextStyle(color: kTextColor),
                        hintText: "Email",
                        labelStyle: TextStyle(color: kTextColor),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: kTextColor,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: kPrimaryColor,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),

                    // save changes
                    Row(
                      children: [
                        Expanded(
                          child: SizedBox(
                            height: 50,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: kPrimaryColor),
                              onPressed: () {},
                              child: const Text(
                                "Save changes",
                                style: TextStyle(color: kTextColor),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                )),
              ),
            )
          ],
        ),
      ),
    );
  }
}
