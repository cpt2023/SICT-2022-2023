import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFFFFAB00);
const kTextColor = Color(0xFFFFFFFF);
const kfillColor = Color.fromARGB(255, 28, 28, 48);
const ksidebarcolor = Color(0xff535353);
const kBackgroundColor = Color(0xFF161626);
const kTabBarColor = Color(0xFF90A4AE);
const kBigheading = TextStyle(fontSize: 20, fontWeight: FontWeight.bold);
const kBiigheading = TextStyle(fontSize: 16, fontWeight: FontWeight.bold);

const kHeadingtext = TextStyle(fontSize: 18, fontWeight: FontWeight.bold);
const ksemiboldingtext = TextStyle(fontSize: 12, fontWeight: FontWeight.bold);
const kregulartext = TextStyle(
  fontSize: 10,
);
const kbtntext = TextStyle(fontSize: 14, fontWeight: FontWeight.bold);
const kbtn2text = TextStyle(
  fontSize: 14,
);

const kDefaultPadding = 15.0;
