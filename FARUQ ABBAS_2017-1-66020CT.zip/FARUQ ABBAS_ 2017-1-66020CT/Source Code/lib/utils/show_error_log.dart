import 'package:flutter/material.dart';

Future<void> showErrorDialog(
  BuildContext context,
  String text,
  Color backgroundColor,
) {
  return showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        icon: const Icon(
          Icons.error_outline_rounded,
          size: 30,
          color: Colors.white,
        ),
        title: const Text(
          'An error occured',
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        content: Text(
          "Error Message: $text",
          style: const TextStyle(color: Colors.white),
        ),
        backgroundColor: backgroundColor,
        actions: [
          TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text(
                'Okay',
                style: TextStyle(color: Colors.white),
              ))
        ],
      );
    },
  );
}
