import 'package:flutter/material.dart';

Future<void> showSuccessDialog(
  BuildContext context,
  String text,
  Color backgroundColor,
) {
  return showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        icon: const Icon(
          Icons.mark_chat_read,
          size: 30,
          color: Colors.white,
        ),
        content: Text(
          text,
          style: const TextStyle(color: Colors.white),
        ),
        backgroundColor: backgroundColor,
        actions: [
          TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text(
                'Okay',
                style: TextStyle(color: Colors.white),
              ))
        ],
      );
    },
  );
}
