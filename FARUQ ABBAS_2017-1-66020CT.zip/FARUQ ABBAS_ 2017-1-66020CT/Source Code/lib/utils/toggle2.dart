import 'package:flutter/material.dart';
import 'package:game_on/screens/notification_screen.dart';
import 'package:game_on/utils/toogle.dart';

import '../models/image_stack.dart';
import '../utils/app_colors.dart';
//import 'follow_unfollow.dart';

class Toggle2 extends StatefulWidget {
  const Toggle2({super.key});

  @override
  State<Toggle2> createState() => _Toggle2State();
}

class _Toggle2State extends State<Toggle2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: kBackgroundColor,
        centerTitle: true,
        title: const Text(
          "Notifications",
          style: TextStyle(
              color: kTextColor, fontSize: 20, fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.adaptive.arrow_back,
            color: kTextColor,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
        child: ListView.builder(
          itemCount: 1,
          itemBuilder: (BuildContext context, int index) {
            return Column(
              children: [
                buildRow(context),
                const Padding(
                  padding: EdgeInsets.only(left: 50),
                  child: Divider(
                    color: kTextColor,
                  ),
                ),
                buildRob(context),
                const Padding(
                  padding: EdgeInsets.only(left: 50),
                  child: Divider(
                    color: kTextColor,
                  ),
                ),
                buildRob(context),
                const Padding(
                  padding: EdgeInsets.only(left: 50),
                  child: Divider(
                    color: kTextColor,
                  ),
                ),
                buildRob(context),
                const Padding(
                  padding: EdgeInsets.only(left: 50),
                  child: Divider(
                    color: kTextColor,
                  ),
                ),
                buildRob(context),
                const Padding(
                  padding: EdgeInsets.only(left: 50),
                  child: Divider(
                    color: kTextColor,
                  ),
                ),
                const CustomList(),
                const CustomList(),
                buildOnePerson(context),
                const SizedBox(
                  height: 20,
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  buildRow(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            const CircleAvatar(
              radius: 15,
              backgroundImage: AssetImage("assets/yellow.png"),
            ),
            const SizedBox(
              width: 4,
            ),
            Container(
              alignment: Alignment.center,
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Call of Duty",
                    style: TextStyle(
                      color: kTextColor,
                      fontSize: 12,
                    ),
                  ),
                  SizedBox(
                    height: 4,
                  ),
                  Text(
                    "Mobile game.24M followers",
                    style: TextStyle(color: kTextColor, fontSize: 8),
                  ),
                  SizedBox(
                    height: 4,
                  ),
                  Row(
                    children: [
                      Text(
                        "Started following you",
                        style: TextStyle(
                            color: kTextColor,
                            fontSize: 12,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: 2,
                      ),
                      Text(
                        ". Just now",
                        style: TextStyle(color: kTextColor, fontSize: 12),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
        Row(
          children: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: kPrimaryColor),
              onPressed: () {
                Navigator.pop(context);
                // Navigator.push(
                //     context,
                //     MaterialPageRoute(
                //         builder: (context) => NotificationScreen()));
              },
              child: const Text(
                "Follow",
                style: TextStyle(color: kTextColor),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// Robby Row
@override
Widget buildRob(BuildContext context) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Row(
        children: [
          const CircleAvatar(
            radius: 15,
            backgroundImage: AssetImage("assets/yellow.png"),
          ),
          const SizedBox(
            width: 4,
          ),
          Container(
            alignment: Alignment.center,
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Robby",
                  style: TextStyle(
                    color: kTextColor,
                    fontSize: 12,
                  ),
                ),
                SizedBox(
                  height: 4,
                ),
                Text(
                  "Mobile game.24M followers",
                  style: TextStyle(color: kTextColor, fontSize: 8),
                ),
                SizedBox(
                  height: 4,
                ),
                Row(
                  children: [
                    Text(
                      "Started following you",
                      style: TextStyle(
                          color: kTextColor,
                          fontSize: 12,
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      width: 2,
                    ),
                    Text(
                      ". Just now",
                      style: TextStyle(color: kTextColor, fontSize: 12),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
      Row(
        children: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kPrimaryColor),
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text(
              "Follow",
              style: TextStyle(color: kTextColor),
            ),
          ),
        ],
      ),
    ],
  );
}

class CustomList extends StatelessWidget {
  const CustomList({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                const ImageStack(),
                const CircleAvatar(
                  radius: 15,
                  backgroundImage: AssetImage("assets/yellow.png"),
                ),
                const SizedBox(
                  width: 4,
                ),
                Container(
                  alignment: Alignment.center,
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Robby",
                        style: TextStyle(
                          color: kTextColor,
                          fontSize: 12,
                        ),
                      ),
                      SizedBox(
                        height: 4,
                      ),
                      Text(
                        "Call of duty fan.2kfollowers",
                        style: TextStyle(color: kTextColor, fontSize: 8),
                      ),
                      SizedBox(
                        height: 4,
                      ),
                      Row(
                        children: [
                          Text(
                            "Started following you",
                            style: TextStyle(
                                color: kTextColor,
                                fontSize: 12,
                                fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            width: 2,
                          ),
                          Text(
                            ". 3hrs Ago",
                            style: TextStyle(color: kTextColor, fontSize: 12),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Row(
              children: [
                Container(
                  width: 70,
                  height: 40,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      image: const DecorationImage(
                          image: AssetImage("assets/hld.png"))),
                ),
              ],
            ),
          ],
        ),
        const Padding(
          padding: EdgeInsets.only(left: 50),
          child: Divider(
            color: kTextColor,
          ),
        ),
      ],
    );
  }
}

@override
Widget buildOnePerson(BuildContext context) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Row(
        children: [
          const CircleAvatar(
            radius: 15,
            backgroundImage: AssetImage("assets/yellow.png"),
          ),
          const SizedBox(
            width: 4,
          ),
          Container(
            alignment: Alignment.center,
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Call of Duty",
                  style: TextStyle(
                    color: kTextColor,
                    fontSize: 12,
                  ),
                ),
                SizedBox(
                  height: 4,
                ),
                Text(
                  "Mobile game.24M followers",
                  style: TextStyle(color: kTextColor, fontSize: 8),
                ),
                SizedBox(
                  height: 4,
                ),
                Row(
                  children: [
                    Text(
                      "Started following you",
                      style: TextStyle(
                          color: kTextColor,
                          fontSize: 12,
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      width: 2,
                    ),
                    Text(
                      ". 3 hrs Ago",
                      style: TextStyle(color: kTextColor, fontSize: 12),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
      Row(
        children: [
          Container(
            width: 70,
            height: 40,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                image:
                    const DecorationImage(image: AssetImage("assets/hld.png"))),
          ),
        ],
      ),
    ],
  );
}
