import 'package:flutter/material.dart';
import 'package:game_on/groups_message/invite.dart';
import 'package:game_on/screens/navbar.dart';
import 'package:game_on/screens/timeline.dart';

import 'package:google_fonts/google_fonts.dart';

import '../utils/app_colors.dart';

class Groupss extends StatefulWidget {
  const Groupss({super.key});
  static String id = "Groupss";

  @override
  State<Groupss> createState() => _GroupssState();
}

class _GroupssState extends State<Groupss> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      floatingActionButton: FloatingActionButton(
          backgroundColor: kPrimaryColor,
          child: const Icon(Icons.add),
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => const Invite()));
          }),
      appBar: AppBar(
        elevation: 0,
        title: Center(
          child: Text(
            "Groups",
            style:
                GoogleFonts.poppins(textStyle: kHeadingtext, color: kTextColor),
          ),
        ),
        backgroundColor: kBackgroundColor,
      ),
      backgroundColor: kBackgroundColor,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25.0),
        child: ListView(
          children: [
            ListTile(
              contentPadding: const EdgeInsets.all(0),
              leading: Container(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    image: const DecorationImage(
                        image: AssetImage("assets/messi.png"))),
              ),
              title: Text(
                "Dream League Soccer",
                style: GoogleFonts.poppins(
                    textStyle: ksemiboldingtext, color: kTextColor),
              ),
              subtitle: Row(
                children: [
                  Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        image: const DecorationImage(
                            image: AssetImage("assets/create1.png"))),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Droid Villaz",
                          style: GoogleFonts.poppins(
                              textStyle: ksemiboldingtext, color: kTextColor),
                        ),
                        Text(
                          "Who wants to join...",
                          style: GoogleFonts.poppins(
                              textStyle: ksemiboldingtext, color: kTextColor),
                        )
                      ],
                    ),
                  )
                ],
              ),
              trailing: const Column(
                children: [
                  Text(
                    "3hrs Ago",
                    style: TextStyle(color: kTextColor),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text("3"),
                ],
              ),
            ),
            const SizedBox(
              height: 13,
            ),
            const Divider(
              thickness: 1,
              color: Color(0xff535353),
              height: 1,
            ),
            const SizedBox(
              height: 20,
            ),
            ListTile(
              contentPadding: const EdgeInsets.all(0),
              leading: Container(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    image: const DecorationImage(
                        image: AssetImage("assets/call1.png"))),
              ),
              title: Text(
                "Call of Duty",
                style: GoogleFonts.poppins(
                    textStyle: ksemiboldingtext, color: kTextColor),
              ),
              subtitle: Row(
                children: [
                  Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        image: const DecorationImage(
                            image: AssetImage("assets/boy1.png"))),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Droid Villaz",
                          style: GoogleFonts.poppins(
                              textStyle: ksemiboldingtext, color: kTextColor),
                        ),
                        Text(
                          "Who wants to join...",
                          style: GoogleFonts.poppins(
                              textStyle: ksemiboldingtext, color: kTextColor),
                        )
                      ],
                    ),
                  )
                ],
              ),
              trailing: const Column(
                children: [
                  Text(
                    "6hrs Ago",
                    style: TextStyle(color: kTextColor),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    "7",
                    style: TextStyle(color: kTextColor),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 13,
            ),
            const Divider(
              thickness: 1,
              color: Color(0xff535353),
              height: 1,
            ),
            const SizedBox(
              height: 13,
            ),
            ListTile(
              contentPadding: const EdgeInsets.all(0),
              leading: Container(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    image: const DecorationImage(
                        image: AssetImage("assets/cr7.png"))),
              ),
              title: Text(
                "Fc Mobile Game",
                style: GoogleFonts.poppins(
                    textStyle: ksemiboldingtext, color: kTextColor),
              ),
              subtitle: Row(
                children: [
                  Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        image: const DecorationImage(
                            image: AssetImage("assets/create1.png"))),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Droid Villaz",
                          style: GoogleFonts.poppins(
                              textStyle: ksemiboldingtext, color: kTextColor),
                        ),
                        Text(
                          "Who wants to join...",
                          style: GoogleFonts.poppins(
                              textStyle: ksemiboldingtext, color: kTextColor),
                        )
                      ],
                    ),
                  )
                ],
              ),
              trailing: const Column(
                children: [
                  Text(
                    "5hrs Ago",
                    style: TextStyle(color: kTextColor),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    "2",
                    style: TextStyle(color: kTextColor),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 13,
            ),
            const Divider(
              thickness: 1,
              color: Color(0xff535353),
              height: 1,
            ),
          ],
        ),
      ),
    ));
  }
}
