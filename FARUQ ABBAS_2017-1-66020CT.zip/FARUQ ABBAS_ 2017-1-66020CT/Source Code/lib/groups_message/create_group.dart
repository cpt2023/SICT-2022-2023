import 'package:flutter/material.dart';
import 'package:game_on/groups_message/groupChat.dart';
import 'package:google_fonts/google_fonts.dart';

import '../utils/app_colors.dart';

class CraeteGroup extends StatelessWidget {
  const CraeteGroup({super.key});
  static String id = "CreateGroup";

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        backgroundColor: kBackgroundColor,
        title: Text(
          "Create group",
          style:
              GoogleFonts.poppins(textStyle: kHeadingtext, color: Colors.white),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25.0),
        child: Column(
          children: [
            Row(
              children: [
                Image.asset("assets/camera.png"),
                const SizedBox(
                  width: 10,
                ),
                Expanded(
                  child: TextFormField(
                    style: TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      fillColor: Color.fromARGB(255, 28, 28, 48),
                      filled: true,
                      labelText: "Group name",
                      labelStyle: const TextStyle(color: Colors.white),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: const BorderSide(color: ksidebarcolor),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: const BorderSide(color: kPrimaryColor),
                      ),
                    ),
                    
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 76,
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => const GroupChat()));
              },
              child: Container(
                width: 378,
                height: 50,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: kPrimaryColor,
                ),
                child: Center(
                    child: Text(
                  "Next",
                  style: GoogleFonts.poppins(textStyle: kbtntext),
                )),
              ),
            )
          ],
        ),
      ),
    ));
  }
}
//  style: const TextStyle(color: kTextColor),
//                   decoration: InputDecoration(
//                     fillColor: Color.fromARGB(255, 28, 28, 48),
//                     filled: true,
//                     labelText: "Enter your username",
//                     labelStyle: const TextStyle(color: kTextColor),
//                     enabledBorder: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(10),
//                       borderSide: const BorderSide(color: ksidebarcolor),
//                     ),
//                     focusedBorder: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(10),
//                       borderSide: const BorderSide(color: kPrimaryColor),
//                     ),
//                   ),