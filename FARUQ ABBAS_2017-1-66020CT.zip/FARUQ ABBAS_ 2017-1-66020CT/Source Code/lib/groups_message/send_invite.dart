import 'package:flutter/material.dart';

import '../utils/app_colors.dart';
import 'invite.dart';

class SendInvite extends StatefulWidget {
  const SendInvite({super.key});
  static String id = "SendInvite";

  @override
  State<SendInvite> createState() => _SendInviteState();
}

class _SendInviteState extends State<SendInvite> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: DefaultTabController(
        length: 2,
        child: Scaffold(
          backgroundColor: kPrimaryColor,
          appBar: AppBar(
            backgroundColor: kBackgroundColor,
            title: const Center(child: Text("Send Invite")),
            bottom: const TabBar(tabs: [
              Tab(
                text: "Followers",
              ),
              Tab(
                text: "Following",
              ),
            ]),
          ),
          body: const TabBarView(children: [
            Text("No followers yet"),
            Invite(),
          ]),
        ),
      ),
    );
  }
}
