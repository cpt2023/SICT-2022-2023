import 'package:flutter/material.dart';
import 'package:game_on/createpost.dart/createPost.dart';
import 'package:game_on/groups_message/create_group.dart';
import 'package:game_on/groups_message/groups.dart';

import 'package:google_fonts/google_fonts.dart';

import '../utils/app_colors.dart';
import 'send_invite.dart';

class Invite extends StatefulWidget {
  const Invite({super.key});
  static String id = "Invite";

  @override
  State<Invite> createState() => _InviteState();
}

class _InviteState extends State<Invite> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kBackgroundColor,
        title: Center(child: Text('Invite')),
      ),
      backgroundColor: kBackgroundColor,
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: 10,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: const CircleAvatar(
                    backgroundImage: AssetImage("assets/create1.png"),
                  ),
                  title: Text(
                    "David",
                    style: GoogleFonts.poppins(
                        textStyle: ksemiboldingtext, color: kTextColor),
                  ),
                  subtitle: Text(
                    "Umar Faruq 2k followers",
                    style: GoogleFonts.poppins(
                        textStyle: ksemiboldingtext, color: kTextColor),
                  ),
                  trailing: Container(
                    width: 94,
                    height: 33,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: kPrimaryColor,
                    ),
                    child: Center(
                        child: Text(
                      "Invite",
                      style: GoogleFonts.poppins(
                          textStyle: kbtntext, color: kTextColor),
                    )),
                  ),
                );
              },
            ),
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const CraeteGroup()));
            },
            child: Container(
              width: 378,
              height: 50,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: kPrimaryColor,
              ),
              child: Center(
                  child: Text(
                "Next",
                style: GoogleFonts.poppins(textStyle: kbtntext),
              )),
            ),
          )
        ],
      ),
    );
  }
}
