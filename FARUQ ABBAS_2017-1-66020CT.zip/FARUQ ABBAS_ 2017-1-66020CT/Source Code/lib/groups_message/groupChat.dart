import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../utils/app_colors.dart';

class GroupChat extends StatefulWidget {
  const GroupChat({super.key});
  static String id = "GroupChat";

  @override
  State<GroupChat> createState() => _GroupChatState();
}

class _GroupChatState extends State<GroupChat> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: kBackgroundColor,
          title: ListTile(
              contentPadding: const EdgeInsets.all(0),
              leading: Container(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    image: const DecorationImage(
                        image: AssetImage("assets/call1.png"))),
              ),
              title: Text(
                "Call of Duty war Zone",
                style: GoogleFonts.poppins(
                    textStyle: ksemiboldingtext, color: Colors.white),
              ),
              subtitle: Text(
                "24M Members300k Online",
                style: GoogleFonts.poppins(
                    textStyle: ksemiboldingtext, color: Colors.white),
              ),
              trailing: GestureDetector(
                  onTap: () {
                    showModalBottomSheet(
                        isScrollControlled: true,
                        backgroundColor: const Color.fromARGB(255, 1, 1, 32),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10))),
                        context: context,
                        builder: (context) {
                          return SizedBox(
                            height: 300,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 25.0, vertical: 25.0),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      showModalBottomSheet(
                                          isScrollControlled: true,
                                          backgroundColor: const Color.fromARGB(
                                              255, 1, 1, 32),
                                          shape: const RoundedRectangleBorder(
                                              borderRadius: BorderRadius.only(
                                                  topLeft: Radius.circular(10),
                                                  topRight:
                                                      Radius.circular(10))),
                                          context: context,
                                          builder: (context) {
                                            return Container(
                                              height: 200,
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 25.0,
                                                      vertical: 25.0),
                                              child: Column(
                                                children: [
                                                  Image.asset(
                                                      "assets/bigclear.png")
                                                ],
                                              ),
                                            );
                                          });
                                    },
                                    child: Row(
                                      children: [
                                        Image.asset("assets/clear.png"),
                                        const SizedBox(
                                          width: 15,
                                        ),
                                        Text(
                                          "Clear Chat",
                                          style: GoogleFonts.poppins(
                                              textStyle: ksemiboldingtext,
                                              color: Colors.white),
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  const Divider(
                                    thickness: 1,
                                    color: Color(0xff535353),
                                    height: 1,
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      showModalBottomSheet(
                                          isScrollControlled: true,
                                          backgroundColor: const Color.fromARGB(
                                              255, 1, 1, 32),
                                          shape: const RoundedRectangleBorder(
                                              borderRadius: BorderRadius.only(
                                                  topLeft: Radius.circular(10),
                                                  topRight:
                                                      Radius.circular(10))),
                                          context: context,
                                          builder: (context) {
                                            return Container(
                                              height: 200,
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 25.0,
                                                      vertical: 25.0),
                                              child: Column(
                                                children: [
                                                  Image.asset(
                                                      "assets/bigmute.png")
                                                ],
                                              ),
                                            );
                                          });
                                    },
                                    child: Row(
                                      children: [
                                        Image.asset("assets/mute.png"),
                                        const SizedBox(
                                          width: 15,
                                        ),
                                        Text(
                                          "Mute",
                                          style: GoogleFonts.poppins(
                                              textStyle: ksemiboldingtext,
                                              color: Colors.white),
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  const Divider(
                                    thickness: 1,
                                    color: Color(0xff535353),
                                    height: 1,
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      showModalBottomSheet(
                                          isScrollControlled: true,
                                          backgroundColor: kBackgroundColor,
                                          shape: const RoundedRectangleBorder(
                                              borderRadius: BorderRadius.only(
                                                  topLeft: Radius.circular(10),
                                                  topRight:
                                                      Radius.circular(10))),
                                          context: context,
                                          builder: (context) {
                                            return SizedBox(
                                              height: 212,
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 25.0,
                                                        vertical: 25.0),
                                                child: Column(
                                                  children: [
                                                    GestureDetector(
                                                      onTap: () {
                                                        showModalBottomSheet(
                                                            isScrollControlled:
                                                                true,
                                                            backgroundColor:
                                                                kBackgroundColor,
                                                            shape: const RoundedRectangleBorder(
                                                                borderRadius: BorderRadius.only(
                                                                    topLeft: Radius
                                                                        .circular(
                                                                            10),
                                                                    topRight: Radius
                                                                        .circular(
                                                                            10))),
                                                            context: context,
                                                            builder: (context) {
                                                              return SizedBox(
                                                                height: 230,
                                                                child: Padding(
                                                                  padding: const EdgeInsets
                                                                      .symmetric(
                                                                      horizontal:
                                                                          25.0,
                                                                      vertical:
                                                                          25.0),
                                                                  child: Column(
                                                                    children: [
                                                                      Image.asset(
                                                                          "assets/removed.png"),
                                                                      const SizedBox(
                                                                        height:
                                                                            22,
                                                                      ),
                                                                      Text(
                                                                        "User removed",
                                                                        style: GoogleFonts.poppins(
                                                                            textStyle:
                                                                                ksemiboldingtext),
                                                                      )
                                                                    ],
                                                                  ),
                                                                ),
                                                              );
                                                            });
                                                      },
                                                      child: Row(
                                                        children: [
                                                          Image.asset(
                                                              "assets/smallremove.png"),
                                                          const SizedBox(
                                                            width: 15.0,
                                                          ),
                                                          Text(
                                                            "Remove user",
                                                            style: GoogleFonts
                                                                .poppins(
                                                                    textStyle:
                                                                        ksemiboldingtext),
                                                          )
                                                        ],
                                                      ),
                                                    ),
                                                    const SizedBox(
                                                      height: 20,
                                                    ),
                                                    const Divider(
                                                      height: 1,
                                                      thickness: 1,
                                                      color: Color(0xff535353),
                                                    ),
                                                    const SizedBox(
                                                      height: 20,
                                                    ),
                                                    Row(
                                                      children: [
                                                        Image.asset(
                                                            "assets/profile.png"),
                                                        const SizedBox(
                                                          width: 15.0,
                                                        ),
                                                        Text(
                                                          "View profile",
                                                          style: GoogleFonts
                                                              .poppins(
                                                                  textStyle:
                                                                      ksemiboldingtext),
                                                        )
                                                      ],
                                                    )
                                                  ],
                                                ),
                                              ),
                                            );
                                          });
                                    },
                                    child: Row(
                                      children: [
                                        Image.asset("assets/mute2.png"),
                                        const SizedBox(
                                          width: 15,
                                        ),
                                        Text(
                                          "Report",
                                          style: GoogleFonts.poppins(
                                              textStyle: ksemiboldingtext,
                                              color: Colors.white),
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  const Divider(
                                    thickness: 1,
                                    color: Color(0xff535353),
                                    height: 1,
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      showModalBottomSheet(
                                          isScrollControlled: true,
                                          backgroundColor: const Color.fromARGB(
                                              223, 3, 1, 27),
                                          shape: const RoundedRectangleBorder(
                                              borderRadius: BorderRadius.only(
                                                  topLeft: Radius.circular(10),
                                                  topRight:
                                                      Radius.circular(10))),
                                          context: context,
                                          builder: (context) {
                                            return Container(
                                              height: 268,
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 25.0,
                                                      vertical: 25.0),
                                              child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Image.asset(
                                                          "assets/smallbook.png"),
                                                      const SizedBox(
                                                        width: 15,
                                                      ),
                                                      // work on this page later
                                                      Text(
                                                        "Exit group",
                                                        style: GoogleFonts.poppins(
                                                            textStyle:
                                                                ksemiboldingtext,
                                                            color:
                                                                Colors.white),
                                                        textAlign:
                                                            TextAlign.center,
                                                      ),
                                                    ],
                                                  ),
                                                  const SizedBox(
                                                    height: 19,
                                                  ),
                                                  const Divider(
                                                    height: 1,
                                                    thickness: 1,
                                                    color: Color(0xff535353),
                                                  ),
                                                  const SizedBox(
                                                    height: 37,
                                                  ),
                                                  Text(
                                                    "You wont be able to get notifications from this"
                                                    "group and will no longer be a member",
                                                    style: GoogleFonts.poppins(
                                                        textStyle:
                                                            ksemiboldingtext,
                                                        color: Colors.white),
                                                    textAlign: TextAlign.center,
                                                  ),
                                                  const SizedBox(
                                                    height: 10,
                                                  ),
                                                  Expanded(
                                                    child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                        Flexible(
                                                          child:
                                                              GestureDetector(
                                                            onTap: () =>
                                                                Navigator.pop(
                                                                    context),
                                                            child: Container(
                                                              width: 179,
                                                              height: 50,
                                                              decoration:
                                                                  BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            5),
                                                                color: const Color(
                                                                    0xff161626),
                                                              ),
                                                              child: Center(
                                                                  child: Text(
                                                                "Cancel",
                                                                style: GoogleFonts
                                                                    .poppins(
                                                                        textStyle:
                                                                            kbtntext),
                                                              )),
                                                            ),
                                                          ),
                                                        ),
                                                        const SizedBox(
                                                          width: 20,
                                                        ),
                                                        Flexible(
                                                          child:
                                                              GestureDetector(
                                                            onTap: () {
                                                              showModalBottomSheet(
                                                                  isScrollControlled:
                                                                      true,
                                                                  backgroundColor:
                                                                      kBackgroundColor,
                                                                  shape: const RoundedRectangleBorder(
                                                                      borderRadius: BorderRadius.only(
                                                                          topLeft: Radius.circular(
                                                                              10),
                                                                          topRight: Radius.circular(
                                                                              10))),
                                                                  context:
                                                                      context,
                                                                  builder:
                                                                      (context) {
                                                                    return SizedBox(
                                                                      height:
                                                                          230,
                                                                      child:
                                                                          Padding(
                                                                        padding: const EdgeInsets
                                                                            .symmetric(
                                                                            horizontal:
                                                                                25.0,
                                                                            vertical:
                                                                                25.0),
                                                                        child:
                                                                            Column(
                                                                          children: [
                                                                            Image.asset("assets/book.png"),
                                                                            const SizedBox(
                                                                              height: 22,
                                                                            ),
                                                                            Text(
                                                                              "YOu are no longer a member of Call of Duty war zone",
                                                                              style: GoogleFonts.poppins(textStyle: ksemiboldingtext),
                                                                            )
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    );
                                                                  });
                                                            },
                                                            child: Container(
                                                              width: 179,
                                                              height: 50,
                                                              decoration:
                                                                  BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            5),
                                                                color:
                                                                    kPrimaryColor,
                                                              ),
                                                              child: Center(
                                                                  child: Text(
                                                                "Continue",
                                                                style: GoogleFonts
                                                                    .poppins(
                                                                        textStyle:
                                                                            kbtntext),
                                                              )),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  )
                                                ],
                                              ),
                                            );
                                          });
                                    },
                                    child: Row(
                                      children: [
                                        Image.asset("assets/exit.png"),
                                        const SizedBox(
                                          width: 15,
                                        ),
                                        Text(
                                          "Exit",
                                          style: GoogleFonts.poppins(
                                              textStyle: ksemiboldingtext,
                                              color: Colors.white),
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  const Divider(
                                    thickness: 1,
                                    color: Color(0xff535353),
                                    height: 1,
                                  ),
                                ],
                              ),
                            ),
                          );
                        });
                  },
                  child: Image.asset("assets/dot.png"))),
        ),
        backgroundColor: kBackgroundColor,
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 25.0),
            child: Column(
              children: [
                Image.asset('assets/grpmes2.png'),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        // controller: _messageController,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return "Please choose a Username";
                          } else {
                            return null;
                          }
                        },
                        style: const TextStyle(color: kTextColor),
                        decoration: InputDecoration(
                          fillColor: kfillColor,
                          filled: true,
                          labelText: "",
                          labelStyle: const TextStyle(color: kTextColor),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: ksidebarcolor),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: kPrimaryColor),
                          ),
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: const Icon(
                        Icons.arrow_upward,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
