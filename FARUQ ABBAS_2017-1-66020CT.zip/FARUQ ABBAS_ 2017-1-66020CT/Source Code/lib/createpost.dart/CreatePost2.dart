import 'package:flutter/material.dart';
import 'package:game_on/createpost.dart/CreatePost3.dart';

import 'package:google_fonts/google_fonts.dart';

import '../utils/app_colors.dart';

class CreatePost2 extends StatefulWidget {
  const CreatePost2({super.key});
  static String id = "CreatePost2";
  @override
  State<CreatePost2> createState() => _CreatePost2State();
}

class _CreatePost2State extends State<CreatePost2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kBackgroundColor,
        title: Row(
          children: [
            // const Icon(Icons.arrow_back),
            const SizedBox(
              width: 100,
            ),
            Center(
                child: Text(
              "Adjust",
              style: GoogleFonts.poppins(textStyle: kHeadingtext),
            )),
          ],
        ),
      ),
      backgroundColor: kBackgroundColor,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25.0),
        child: Column(
          children: [
            Container(
              width: 378,
              height: 210,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  image: const DecorationImage(
                      image: AssetImage("assets/halland2.png"))),
            ),
            const SizedBox(
              height: 29,
            ),
            Image.asset("assets/crop.png"),
            const SizedBox(height: 36),
            GestureDetector(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const CreatePost3()));
              },
              child: Container(
                width: 378,
                height: 50,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: kPrimaryColor,
                ),
                child: Center(
                    child: Text(
                  "Next",
                  style: GoogleFonts.poppins(textStyle: kbtntext),
                )),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
