import 'package:flutter/material.dart';
import 'package:game_on/createpost.dart/CreatePost2.dart';
import 'package:google_fonts/google_fonts.dart';

import '../utils/app_colors.dart';

class CreatePost extends StatefulWidget {
  const CreatePost({super.key});
  static String id = "CreatePost";

  @override
  State<CreatePost> createState() => _CreatePostState();
}

class _CreatePostState extends State<CreatePost> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: kBackgroundColor,
        appBar: AppBar(
          backgroundColor: kBackgroundColor,
          title: Center(
              child: Text(
            "Create Post",
            style: GoogleFonts.poppins(textStyle: kHeadingtext),
          )),
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ListTile(
                contentPadding: const EdgeInsets.all(0.0),
                leading: const CircleAvatar(
                  //radius: 50,
                  backgroundImage: AssetImage("assets/boy1.png"),
                ),
                title: Text("DroidVillaz",
                    style: GoogleFonts.poppins(
                        textStyle: ksemiboldingtext, color: Colors.white)),
                subtitle: Text("Umar Faruq",
                    style: GoogleFonts.poppins(
                        textStyle: kregulartext, color: Colors.white)),
              ),
              const SizedBox(
                height: 21,
              ),
              Container(
                width: 378,
                height: 210,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    image: const DecorationImage(
                        image: AssetImage("assets/halland.png"))),
              ),
              const SizedBox(
                height: 13,
              ),
              const Divider(
                thickness: 1,
                color: Color(0xff535353),
                height: 1,
              ),
              const SizedBox(
                height: 20,
              ),
              Row(
                children: [
                  Text("Recent",
                      style: GoogleFonts.poppins(
                          textStyle: ksemiboldingtext, color: Colors.white)),
                  const SizedBox(
                    width: 9,
                  ),
                  Image.asset("assets/arrowdown.png")
                ],
              ),
              const SizedBox(
                height: 21,
              ),
              Expanded(
                child: GridView.count(
                  shrinkWrap: true,
                  crossAxisCount: 3,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 5.0, left: 5.0),
                      child: Container(
                        height: 120,
                        width: 120,
                        decoration: const BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage("assets/field.png"))),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 5.0, left: 5.0),
                      child: Container(
                        height: 120,
                        width: 120,
                        decoration: const BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage("assets/messi.png"))),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 5.0),
                      child: Container(
                        height: 120,
                        width: 120,
                        decoration: const BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage("assets/cr7.png"))),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 5.0, left: 5.0),
                      child: Container(
                        height: 120,
                        width: 120,
                        decoration: const BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage("assets/messi.png"))),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 5.0, left: 5.0),
                      child: Container(
                        height: 120,
                        width: 120,
                        decoration: const BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage("assets/cr7.png"))),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 5.0, left: 5.0),
                      child: Container(
                        height: 120,
                        width: 120,
                        decoration: const BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage("assets/call1.png"))),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 5.0, left: 5.0),
                      child: Container(
                        height: 120,
                        width: 120,
                        decoration: const BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage("assets/boy1.png"))),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 5.0, left: 5.0),
                      child: Container(
                        height: 120,
                        width: 120,
                        decoration: const BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage("assets/messi.png"))),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 5.0, left: 5.0),
                      child: Container(
                        height: 120,
                        width: 120,
                        decoration: const BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage("assets/field.png"))),
                      ),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const CreatePost2()));
                },
                child: Container(
                  width: 378,
                  height: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: kPrimaryColor,
                  ),
                  child: Center(
                      child: Text(
                    "Next",
                    style: GoogleFonts.poppins(textStyle: kbtntext),
                  )),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
