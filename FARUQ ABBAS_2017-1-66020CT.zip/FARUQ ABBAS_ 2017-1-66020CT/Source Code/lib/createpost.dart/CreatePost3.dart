import 'package:flutter/material.dart';
import 'package:game_on/screens/navbar.dart';
import 'package:game_on/screens/timeline.dart';

import 'package:google_fonts/google_fonts.dart';

import '../utils/app_colors.dart';

class CreatePost3 extends StatefulWidget {
  const CreatePost3({super.key});
  static String id = "CreatePost3";

  @override
  State<CreatePost3> createState() => _CreatePost3State();
}

class _CreatePost3State extends State<CreatePost3> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kBackgroundColor,
        title: Row(
          children: [
            // const Icon(Icons.arrow_back),
            const SizedBox(
              width: 100,
            ),
            Center(
                child: Text(
              "Create post",
              style: GoogleFonts.poppins(textStyle: kHeadingtext),
            )),
          ],
        ),
      ),
      backgroundColor: kBackgroundColor,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25.0),
        child: Column(
          children: [
            ListTile(
              contentPadding: const EdgeInsets.all(0.0),
              leading: const CircleAvatar(
                //radius: 50,
                backgroundImage: AssetImage("assets/boy1.png"),
              ),
              title: Text("DroidVillaz",
                  style: GoogleFonts.poppins(
                      textStyle: ksemiboldingtext, color: Colors.white)),
              subtitle: Text("Umar Faruq",
                  style: GoogleFonts.poppins(
                    textStyle: kregulartext,
                  )),
            ),
            const SizedBox(
              height: 21,
            ),
            Container(
              width: 378,
              height: 210,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  image: const DecorationImage(
                      image: AssetImage("assets/halland.png"))),
            ),
            const SizedBox(
              height: 28,
            ),
            Flexible(
              child: Container(
                height: 127,
                width: 378,
                decoration: BoxDecoration(
                    color: const Color(0xff161626),
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(color: const Color(0xff535353))),
                child: TextFormField(
                  decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: "what is hapening?",
                      hintStyle: TextStyle(color: Colors.white),
                      contentPadding: EdgeInsets.symmetric(horizontal: 15)),
                ),
              ),
            ),
            const SizedBox(
              height: 29,
            ),
            GestureDetector(
              onTap: () {
                showModalBottomSheet(
                    backgroundColor: kBackgroundColor,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(5),
                            topRight: Radius.circular(5))),
                    context: context,
                    builder: (context) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 25.0),
                        child: GestureDetector(
                          onTap: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => NavBar()));
                          },
                          child: Row(
                            children: [
                              Image.asset("assets/verify.png"),
                              const SizedBox(
                                width: 10,
                              ),
                              Text("Posted to feeds",
                                  style: GoogleFonts.poppins(
                                      textStyle: ksemiboldingtext,
                                      color: Colors.white)),
                              const SizedBox(
                                width: 100,
                              ),
                              Container(
                                height: 56,
                                width: 106,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    image: const DecorationImage(
                                        image:
                                            AssetImage("assets/halland.png"))),
                              )
                            ],
                          ),
                        ),
                      );
                    });
              },
              child: Container(
                width: 378,
                height: 50,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: kPrimaryColor,
                ),
                child: Center(
                    child: Text(
                  "Post",
                  style: GoogleFonts.poppins(textStyle: kbtntext),
                )),
              ),
            )
          ],
        ),
      ),
    );
  }
}
