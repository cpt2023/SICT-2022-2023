import 'package:cloud_firestore/cloud_firestore.dart';

import '../../models/user_model.dart';

class FirebaseUserService {
  final CollectionReference usersCollection =
      FirebaseFirestore.instance.collection('Users');


  Future<bool> usernameCheck(String username) async {
    final result = await FirebaseFirestore.instance
        .collection('Users')
        .where('userName', isEqualTo: username)
        .get();

    return result.docs.isEmpty;
  }

  Future<User?> createUser(
    String email,
    String username,
    String firstName,
    String lastName,
    String gender,
  ) async {
    try {
      final usersCollection = FirebaseFirestore.instance.collection('Users');
      final userDocumentRef = await usersCollection.add({
        'email': email,
        'username': username,
        'firstName': firstName,
        'lastName': lastName,
        'gender': gender,        
      });

      final userDocument = await userDocumentRef.get();
      if (userDocument.exists) {
        final userData = userDocument.data() as Map<String, dynamic>;
        final user = User.fromJson(userData);
        return user;
      } else {
        return null;
      }
    } catch (e) {
      print('Error creating user: $e');
      return null;
    }
  }
   Future<User?> getUserByEmail(String email) async {
    try {
      QuerySnapshot querySnapshot = await usersCollection
          .where('email', isEqualTo: email)
          .get();

      if (querySnapshot.docs.isNotEmpty) {
        final userData = querySnapshot.docs.first.data() as Map<String, dynamic>;
        final user = User.fromJson(userData);
        return user;
      } else {
        return null;
      }
    } catch (e) {
      print('Error getting user by email: $e');
      return null;
    }
  }
}


// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// class UserProfileWidget extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     final userDataProvider = context.watch<UserDataProvider>();

//     return Column(
//       children: [
//         Text('Username: ${userDataProvider.username}'),
//         Text('Email: ${userDataProvider.email}'),
//       ],
//     );
//   }
// }
