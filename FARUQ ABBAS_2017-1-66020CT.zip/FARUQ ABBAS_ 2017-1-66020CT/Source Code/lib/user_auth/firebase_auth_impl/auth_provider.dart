import 'auth_user.dart';

abstract class AuthProvider {
  Future<void> initializer();
  AuthUser? get currentUser;

  Future<AuthUser> logIn({
    required String emailController,
    required String passwordController,
  });

  Future<AuthUser> createUser({
    // required String uid,
    required String emailController,
    required String passwordController,
    required String firstNameController,
    required String lastNameController,
    required String usernameController,
    required String genderController,
  });
  Future<String> forgetPassword({required String emailController});

  Future<void> logOut();
  Future<void> sendEmailVerification();
}