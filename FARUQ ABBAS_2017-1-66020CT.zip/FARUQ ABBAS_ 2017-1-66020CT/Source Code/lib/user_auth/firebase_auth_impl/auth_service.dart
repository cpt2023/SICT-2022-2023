import 'auth_provider.dart';
import 'auth_user.dart';
import 'firebase_auth_provider.dart';

class AuthService implements AuthProvider {
  final AuthProvider provider;
  const AuthService(this.provider);

  factory AuthService.firebase() => AuthService(
        FirebaseAuthProvider(),
      );

  @override
  Future<AuthUser> createUser({
    // required String uid,
    required String emailController,
    required String passwordController,
    required String firstNameController,
    required String lastNameController,
    required String usernameController,
    required String genderController,
  }) =>
      provider.createUser(
        // uid: uid,
        emailController: emailController,
        passwordController: passwordController,
        firstNameController: firstNameController,
        lastNameController: lastNameController,
        usernameController: usernameController,
        genderController: genderController,
      );

  @override
  AuthUser? get currentUser => provider.currentUser;

  @override
  Future<AuthUser> logIn({
    required String emailController,
    required String passwordController,
  }) =>
      provider.logIn(
        emailController: emailController,
        passwordController: passwordController,
      );

  @override
  Future<void> logOut() => provider.logOut();

  @override
  Future<void> sendEmailVerification() => provider.sendEmailVerification();

  @override
  Future<void> initializer() => provider.initializer();

  @override
  Future<String> forgetPassword({
    required String emailController,
  }) =>
      provider.forgetPassword(
        emailController: emailController,
      );
}
