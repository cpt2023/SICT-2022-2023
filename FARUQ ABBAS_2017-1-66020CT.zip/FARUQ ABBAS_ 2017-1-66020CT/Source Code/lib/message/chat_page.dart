import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../chat/chat_service.dart';
import '../components/chat_bubble.dart';
import '../utils/app_colors.dart';

class ChatPage extends StatefulWidget {
  final String firstName;
  final String lastName;
  final String receiverUserEmail;
  final String receiveUserId;
  const ChatPage(
      {super.key,
      required this.receiverUserEmail,
      required this.receiveUserId,
      required this.firstName,
      required this.lastName});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  String fullName = '';

  @override
  void initState() {
    super.initState();
    fullName = '${widget.firstName} ${widget.lastName}';
  }

  final TextEditingController _messageController = TextEditingController();
  final ChatService _chatService = ChatService();
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  void sendMessage() async {
    if (_messageController.text.isNotEmpty) {
      await _chatService.sendMessage(
          widget.receiveUserId, _messageController.text.trim());

      _messageController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kBackgroundColor,
        title: Text(fullName),
      ),
      body: Container(
        color: kBackgroundColor,
        child: Column(
          
          children: [
            Expanded(child: _buildMessageList()),
            _buildMessageInput(),
      
            const SizedBox(height: 25,)
          ],
        ),
      ),
    );
  }

  Widget _buildMessageList() {
    return StreamBuilder(
        stream: _chatService.getMessages(
            widget.receiveUserId, _firebaseAuth.currentUser!.uid),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Error$snapshot.error'),
            );
          }
         
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child:  CircularProgressIndicator());
          }

          return ListView(
            children: snapshot.data!.docs
                .map((document) => _buildMessageItem(document))
                .toList(),
          );
        });
  }

  Widget _buildMessageItem(DocumentSnapshot document) {
    Map<String, dynamic> data = document.data() as Map<String, dynamic>;

    var alignment = (data['senderId'] == _firebaseAuth.currentUser!.uid)
        ? Alignment.centerRight
        : Alignment.centerLeft;

    return Container(
      alignment: alignment,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: (
            data['senderId'] == _firebaseAuth.currentUser!.uid)
                ? CrossAxisAlignment.end
                : CrossAxisAlignment.start,
          mainAxisAlignment: (
            data['senderId'] == _firebaseAuth.currentUser!.uid)
                ? MainAxisAlignment.end
                : MainAxisAlignment.start,
          children: [
            // Text(data['senderEmail']),
            // const SizedBox(height: 5,),
            ChatBubble(message: data['message'])
          ],
        ),
      ),
    );
  }

  Widget _buildMessageInput() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 25.0),
      child: Row(
        children: [
          Expanded(
            child: TextFormField(
              controller: _messageController,
              validator: (value) {
                if (value!.isEmpty) {
                  return "Please choose a Username";
                } else {
                  return null;
                }
              },
              style: const TextStyle(color: kTextColor),
              decoration: InputDecoration(
                fillColor: kTabBarColor,
                filled: true,
                labelText: "Enter message",
                labelStyle: const TextStyle(color: kTextColor),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: kTextColor),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: kPrimaryColor),
                ),
              ),
            ),
          ),
          IconButton(
            onPressed: sendMessage,
            icon: const Icon(
              Icons.arrow_upward,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}
