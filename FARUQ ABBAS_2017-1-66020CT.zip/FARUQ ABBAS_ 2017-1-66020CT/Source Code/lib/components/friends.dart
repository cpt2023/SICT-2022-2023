import 'package:flutter/material.dart';

import '../utils/app_colors.dart';

class Friends extends StatefulWidget {
  const Friends({super.key});

  @override
  State<Friends> createState() => _FriendsState();
}

class _FriendsState extends State<Friends> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListTile(
          leading: const CircleAvatar(
            radius: 20,
            child: Image(
              image: AssetImage("assets/cap.png"),
            ),
          ),
          title: const Text(
            "Call of duty",
            style: TextStyle(color: kTextColor, fontSize: 18),
          ),
          subtitle: const Text(
            "Call of duty followers",
            style: TextStyle(color: kTextColor, fontSize: 14),
          ),
          trailing: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kPrimaryColor),
            onPressed: () {},
            child: const Text(
              "Follow",
              style: TextStyle(
                color: kTextColor,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
