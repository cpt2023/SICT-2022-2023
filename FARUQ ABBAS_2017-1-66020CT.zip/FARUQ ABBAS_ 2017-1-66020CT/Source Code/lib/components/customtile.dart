import 'package:flutter/material.dart';

import '../utils/app_colors.dart';

class CustomTile extends StatelessWidget {
  const CustomTile({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    return Container(
      color: kBackgroundColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ListTile(
            leading: const CircleAvatar(
              radius: 20,
              child: Image(
                image: AssetImage("assets/user1.png"),
              ),
            ),
            title: const Text(
              "DroidVillaz",
              style: TextStyle(color: kTextColor),
            ),
            subtitle: const Text(
              "Just now",
              style: TextStyle(color: kTextColor),
            ),
            trailing: IconButton(
              onPressed: () {
                showModalBottomSheet(
                    isScrollControlled: true,
                    backgroundColor: kBackgroundColor,
                    context: context,
                    builder: (context) {
                      return Container(
                        width: MediaQuery.of(context).size.width,
                        height: height / 1.3,
                        decoration: const BoxDecoration(
                          color: kBackgroundColor,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20),
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(kDefaultPadding),
                          child: Column(
                            children: [
                              Center(
                                child: Container(
                                  height: 5,
                                  width: 100,
                                  color: kTabBarColor,
                                ),
                              ),

                              //  Save post
                              InkWell(
                                onTap: () {
                                  showModalBottomSheet(
                                      isScrollControlled: true,
                                      context: context,
                                      builder: (context) {
                                        return Container(
                                          width:
                                              MediaQuery.of(context).size.width,
                                          height: height / 3.5,
                                          decoration: const BoxDecoration(
                                              color: kBackgroundColor,
                                              borderRadius: BorderRadius.only(
                                                topLeft: Radius.circular(20),
                                                topRight: Radius.circular(20),
                                              )),
                                          child: Padding(
                                            padding: const EdgeInsets.all(15),
                                            child: Column(
                                              children: [
                                                Center(
                                                  child: Container(
                                                    color: kTabBarColor,
                                                    width: 100,
                                                    height: 5,
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 20,
                                                ),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    ClipRRect(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              15),
                                                      child: const Image(
                                                        image: AssetImage(
                                                            "assets/hld.png"),
                                                        fit: BoxFit.cover,
                                                      ),
                                                    ),
                                                    const Row(
                                                      children: [
                                                        Icon(
                                                          Icons.bookmark,
                                                          color: kTextColor,
                                                        ),
                                                        SizedBox(
                                                          width: 4,
                                                        ),
                                                        Text(
                                                          "Post saveed",
                                                          style: TextStyle(
                                                              color:
                                                                  kTextColor),
                                                        ),
                                                      ],
                                                    )
                                                  ],
                                                )
                                              ],
                                            ),
                                          ),
                                        );
                                      });
                                },
                                // the first one
                                child: const ListTile(
                                  leading: Icon(
                                    Icons.bookmark_border_outlined,
                                    color: kTextColor,
                                  ),
                                  title: Text(
                                    "Save post",
                                    style: TextStyle(color: kTextColor),
                                  ),
                                ),
                              ),
                              const Padding(
                                padding: EdgeInsets.only(left: 50),
                                child: Divider(
                                  color: kTabBarColor,
                                  thickness: 1,
                                ),
                              ),

                              // copy post URL
                              InkWell(
                                onTap: () {
                                  showModalBottomSheet(
                                      context: context,
                                      builder: (context) {
                                        return Container(
                                          height: height / 2.5,
                                          width:
                                              MediaQuery.of(context).size.width,
                                          decoration: const BoxDecoration(
                                            color: kBackgroundColor,
                                            borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(20),
                                              topRight: Radius.circular(20),
                                            ),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.all(
                                                kDefaultPadding),
                                            child: Column(
                                              children: [
                                                Center(
                                                  child: Container(
                                                    color: kTabBarColor,
                                                    width: 100,
                                                    height: 5,
                                                  ),
                                                ),
                                                InkWell(
                                                  onTap: () {
                                                    buildPost(context, height);
                                                  },
                                                  child: const ListTile(
                                                    leading: Icon(
                                                      Icons.note_add_sharp,
                                                      color: kTextColor,
                                                    ),
                                                    title: Text(
                                                      "Create post",
                                                      style: TextStyle(
                                                          color: kTextColor),
                                                    ),
                                                  ),
                                                ),
                                                const Padding(
                                                  padding:
                                                      EdgeInsets.only(left: 40),
                                                  child: Divider(
                                                    color: kTextColor,
                                                    thickness: 1,
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                InkWell(
                                                  onTap: () {},
                                                  child: const ListTile(
                                                    leading: Icon(
                                                      Icons.sensors,
                                                      color: kTextColor,
                                                    ),
                                                    title: Text(
                                                      "Go live",
                                                      style: TextStyle(
                                                          color: kTextColor),
                                                    ),
                                                  ),
                                                ),
                                                const Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 40),
                                                    child: Divider(
                                                      color: kTextColor,
                                                      thickness: 1,
                                                    ))
                                              ],
                                            ),
                                          ),
                                        );
                                      });
                                },
                                child: ListTile(
                                  leading: Image.asset('assets/link.png'),
                                  title: Text(
                                    "Copy post URL",
                                    style: TextStyle(color: kTextColor),
                                  ),
                                ),
                              ),
                              const Padding(
                                padding: EdgeInsets.only(left: 50),
                                child: Divider(
                                  color: kTabBarColor,
                                  thickness: 1,
                                ),
                              ),

                              // mute
                              InkWell(
                                onTap: () {
                                  showModalBottomSheet(
                                      context: context,
                                      builder: (context) {
                                        return Container(
                                          width:
                                              MediaQuery.of(context).size.width,
                                          height: height / 1.6,
                                          decoration: const BoxDecoration(
                                            borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(20),
                                              topRight: Radius.circular(20),
                                            ),
                                            color: kBackgroundColor,
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.all(15),
                                            child: Column(
                                              children: [
                                                Center(
                                                  child: Container(
                                                    height: 5,
                                                    width: 100,
                                                    color: kTabBarColor,
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 70,
                                                ),
                                                Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Center(
                                                      child: Image.asset(
                                                        "assets/cancel.png",
                                                      ),
                                                    ),
                                                    const SizedBox(
                                                      height: 10,
                                                    ),
                                                    const Text(
                                                      "Account Muted",
                                                      style: TextStyle(
                                                          color: kTextColor,
                                                          fontWeight:
                                                              FontWeight.bold),
                                                    ),
                                                    const SizedBox(
                                                      height: 10,
                                                    ),
                                                    const Text(
                                                      "Posts this account will be restricted from your",
                                                      style: TextStyle(
                                                          color: kTextColor),
                                                    ),
                                                    const SizedBox(
                                                      height: 10,
                                                    ),
                                                    const Text(
                                                      "news feed",
                                                      style: TextStyle(
                                                          color: kTextColor,
                                                          fontWeight:
                                                              FontWeight.bold),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        );
                                      });
                                },
                                child: ListTile(
                                  leading: Image.asset('assets/mute.png'),
                                  title: Text(
                                    "Mute",
                                    style: TextStyle(color: kTextColor),
                                  ),
                                ),
                              ),
                              const Padding(
                                padding: EdgeInsets.only(left: 50),
                                child: Divider(
                                  color: kTabBarColor,
                                  thickness: 1,
                                ),
                              ),

                              // unfollow
                              InkWell(
                                onTap: () {
                                  showModalBottomSheet(
                                      context: context,
                                      builder: (context) {
                                        return Container(
                                          height: height / 3.5,
                                          decoration: const BoxDecoration(
                                            color: kBackgroundColor,
                                            borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(20),
                                              topRight: Radius.circular(20),
                                            ),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.all(
                                                kDefaultPadding),
                                            child: Column(
                                              children: [
                                                Center(
                                                  child: Container(
                                                    width: 100,
                                                    height: 5,
                                                    color: kTabBarColor,
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 20,
                                                ),
                                                const Padding(
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 40),
                                                  child: Row(
                                                    children: [
                                                      Icon(
                                                        Icons
                                                            .person_outline_rounded,
                                                        size: 25,
                                                        color: kTextColor,
                                                      ),
                                                      SizedBox(
                                                        width: 4,
                                                      ),
                                                      Text(
                                                        "You have unfollowed Droid Villaz",
                                                        style: TextStyle(
                                                            color: kTextColor),
                                                      ),
                                                    ],
                                                  ),
                                                )
                                              ],
                                            ),
                                          ),
                                        );
                                      });
                                },
                                child: ListTile(
                                  leading: Image.asset('assets/unfollow.png'),
                                  title: Text(
                                    "Unfollow",
                                    style: TextStyle(color: kTextColor),
                                  ),
                                ),
                              ),
                              const Padding(
                                padding: EdgeInsets.only(left: 50),
                                child: Divider(
                                  color: kTabBarColor,
                                  thickness: 1,
                                ),
                              ),

                              // Repost
                              InkWell(
                                onTap: () {
                                  showModalBottomSheet(
                                      context: context,
                                      builder: (context) {
                                        return Container(
                                          width:
                                              MediaQuery.of(context).size.width,
                                          height: height / 1.2,
                                          decoration: const BoxDecoration(
                                            color: kBackgroundColor,
                                            borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(20),
                                              topRight: Radius.circular(20),
                                            ),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.all(
                                                kDefaultPadding),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Center(
                                                  child: Container(
                                                    width: 100,
                                                    height: 5,
                                                    color: kTabBarColor,
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 20,
                                                ),
                                                const Center(
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Icon(
                                                        Icons.message_outlined,
                                                        color: kTextColor,
                                                      ),
                                                      SizedBox(
                                                        width: 4,
                                                      ),
                                                      Text(
                                                        "Report post",
                                                        style: TextStyle(
                                                            color: kTextColor),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                TextButton(
                                                  onPressed: () {},
                                                  child: const Text(
                                                    "Why are you reporting this post",
                                                    style: TextStyle(
                                                        color: kTextColor),
                                                  ),
                                                ),
                                                const Divider(
                                                  color: kTabBarColor,
                                                  thickness: 1,
                                                ),
                                                TextButton(
                                                  onPressed: () {
                                                    buildWhy(context, height);
                                                  },
                                                  child: const Text(
                                                    "I don't just like it",
                                                    style: TextStyle(
                                                        color: kTextColor),
                                                  ),
                                                ),
                                                const Divider(
                                                  color: kTabBarColor,
                                                  thickness: 1,
                                                ),
                                                TextButton(
                                                  onPressed: () {
                                                    buildWhy(context, height);
                                                  },
                                                  child: const Text(
                                                    "Nudity or Explicity Content",
                                                    style: TextStyle(
                                                        color: kTextColor),
                                                  ),
                                                ),
                                                const Divider(
                                                  color: kTabBarColor,
                                                  thickness: 1,
                                                ),
                                                TextButton(
                                                  onPressed: () {
                                                    buildWhy(context, height);
                                                  },
                                                  child: const Text(
                                                    "Fake information",
                                                    style: TextStyle(
                                                        color: kTextColor),
                                                  ),
                                                ),
                                                const Divider(
                                                  color: kTabBarColor,
                                                  thickness: 1,
                                                ),
                                                TextButton(
                                                  onPressed: () {
                                                    buildWhy(context, height);
                                                  },
                                                  child: const Text(
                                                    "Scam",
                                                    style: TextStyle(
                                                        color: kTextColor),
                                                  ),
                                                ),
                                                const Divider(
                                                  color: kTabBarColor,
                                                  thickness: 1,
                                                ),
                                              ],
                                            ),
                                          ),
                                        );
                                      });
                                },
                                child: ListTile(
                                  leading: Image.asset('assets/mute2.png'),
                                  title: Text(
                                    "Report",
                                    style: TextStyle(color: kTextColor),
                                  ),
                                ),
                              ),
                              const Padding(
                                padding: EdgeInsets.only(left: 50),
                                child: Divider(
                                  color: kTabBarColor,
                                  thickness: 1,
                                ),
                              ),

                              // Block
                              InkWell(
                                onTap: () {
                                  showModalBottomSheet(
                                      isScrollControlled: true,
                                      context: context,
                                      builder: (context) {
                                        return Container(
                                          width:
                                              MediaQuery.of(context).size.width,
                                          height: height / 1.9,
                                          decoration: const BoxDecoration(
                                            color: kBackgroundColor,
                                            borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(20),
                                              topRight: Radius.circular(20),
                                            ),
                                          ),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Center(
                                                child: Container(
                                                  color: kTabBarColor,
                                                  width: 100,
                                                  height: 5,
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 20,
                                              ),
                                              const Center(
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Icon(
                                                      Icons.block_outlined,
                                                      color: Colors.red,
                                                    ),
                                                    SizedBox(
                                                      width: 4,
                                                    ),
                                                    Text(
                                                      "Blocked account ",
                                                      style: TextStyle(
                                                          color: kTextColor),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              const Divider(
                                                color: kTabBarColor,
                                                thickness: 1,
                                              ),
                                              const SizedBox(
                                                height: 15,
                                              ),
                                              Padding(
                                                padding: const EdgeInsets.all(
                                                    kDefaultPadding),
                                                child: Column(
                                                  children: [
                                                    const Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          "You won't be able to see post or message blocked",
                                                          style: TextStyle(
                                                              color:
                                                                  kTextColor),
                                                        ),
                                                        SizedBox(
                                                          height: 8,
                                                        ),
                                                        Text(
                                                          "but you can still see post and message",
                                                          style: TextStyle(
                                                              color:
                                                                  kTextColor),
                                                        ),
                                                        SizedBox(
                                                          height: 8,
                                                        ),
                                                        Text(
                                                          "of other in the group",
                                                          style: TextStyle(
                                                              color:
                                                                  kTextColor),
                                                        )
                                                      ],
                                                    ),
                                                    const SizedBox(
                                                      height: 60,
                                                    ),
                                                    Row(
                                                      children: [
                                                        Expanded(
                                                          child: ElevatedButton(
                                                            style: ElevatedButton
                                                                .styleFrom(
                                                                    backgroundColor:
                                                                        kTabBarColor),
                                                            onPressed: () {},
                                                            child: const Text(
                                                              "Cancel",
                                                              style: TextStyle(
                                                                color:
                                                                    kTextColor,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        const SizedBox(
                                                          width: 10,
                                                        ),
                                                        Expanded(
                                                          child: ElevatedButton(
                                                            style: ElevatedButton
                                                                .styleFrom(
                                                                    backgroundColor:
                                                                        kPrimaryColor),
                                                            onPressed: () {
                                                              showModalBottomSheet(
                                                                  context:
                                                                      context,
                                                                  builder:
                                                                      (context) {
                                                                    return Container(
                                                                      width: MediaQuery.of(
                                                                              context)
                                                                          .size
                                                                          .width,
                                                                      height:
                                                                          height /
                                                                              1.9,
                                                                      decoration: const BoxDecoration(
                                                                          borderRadius: BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(20),
                                                                            topRight:
                                                                                Radius.circular(20),
                                                                          ),
                                                                          color: kBackgroundColor),
                                                                      child:
                                                                          Column(
                                                                        children: [
                                                                          const SizedBox(
                                                                            height:
                                                                                10,
                                                                          ),
                                                                          Center(
                                                                            child:
                                                                                Container(
                                                                              width: 100,
                                                                              height: 5,
                                                                              color: kTabBarColor,
                                                                            ),
                                                                          ),
                                                                          const SizedBox(
                                                                            height:
                                                                                40,
                                                                          ),
                                                                          const Column(
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.center,
                                                                            children: [
                                                                              Icon(
                                                                                Icons.block_outlined,
                                                                                color: Colors.red,
                                                                                size: 100,
                                                                              ),
                                                                              SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              Text(
                                                                                "Account blocked",
                                                                                style: TextStyle(color: Colors.red),
                                                                              ),
                                                                              SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              Text(
                                                                                "This account is now blocked and no longer access ",
                                                                                style: TextStyle(color: kTextColor),
                                                                              ),
                                                                              SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              Text(
                                                                                "to you directly ",
                                                                                style: TextStyle(color: kTextColor),
                                                                              ),
                                                                            ],
                                                                          )
                                                                        ],
                                                                      ),
                                                                    );
                                                                  });
                                                            },
                                                            child: const Text(
                                                              "Continue",
                                                              style: TextStyle(
                                                                color:
                                                                    kTextColor,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    )
                                                  ],
                                                ),
                                              )
                                            ],
                                          ),
                                        );
                                      });
                                },
                                child: const ListTile(
                                  leading: Icon(
                                    Icons.block_outlined,
                                    color: Colors.red,
                                  ),
                                  title: Text(
                                    "Block",
                                    style: TextStyle(color: kTextColor),
                                  ),
                                ),
                              ),
                              const Padding(
                                padding: EdgeInsets.only(left: 50),
                                child: Divider(
                                  color: kTabBarColor,
                                  thickness: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    });
              },
              icon: const Icon(
                Icons.more_vert_outlined,
                color: kTextColor,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<dynamic> buildPost(BuildContext context, double height) {
    return showModalBottomSheet(
        context: context,
        builder: (context) {
          return Container(
            height: height,
            width: MediaQuery.of(context).size.width,
            decoration: const BoxDecoration(
              color: kBackgroundColor,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              children: [
                const SizedBox(
                  height: 10,
                ),
                Center(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: 100,
                        height: 5,
                        color: kTabBarColor,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.message_outlined,
                            color: kTextColor,
                          ),
                          SizedBox(
                            width: 4,
                          ),
                          Text(
                            "Comments",
                            style: TextStyle(color: kTextColor),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const Divider(
                  color: kTabBarColor,
                  thickness: 1,
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width,
                  height: 150,
                  child: ListView.builder(
                    itemCount: 1,
                    itemBuilder: (BuildContext context, int index) {
                      return Padding(
                        padding: const EdgeInsets.all(kDefaultPadding),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            buildLiman(),
                            const Padding(
                              padding: EdgeInsets.only(left: 40),
                              child: Divider(
                                color: kTabBarColor,
                                thickness: 1,
                              ),
                            ),
                            buildRobey(),
                            const Padding(
                              padding: EdgeInsets.only(left: 40),
                              child: Divider(
                                color: kTabBarColor,
                                thickness: 1,
                              ),
                            ),
                            buildLiman(),
                            Center(
                              child: TextButton(
                                  onPressed: () {},
                                  child: const Text(
                                    "View replies",
                                    style: TextStyle(color: kTextColor),
                                  )),
                            ),
                            const Padding(
                              padding: EdgeInsets.only(left: 40),
                              child: Divider(
                                color: kTabBarColor,
                                thickness: 1,
                              ),
                            ),
                            buildLiman(),
                            Center(
                              child: TextButton(
                                  onPressed: () {},
                                  child: const Text(
                                    "View replies",
                                    style: TextStyle(color: kTextColor),
                                  )),
                            ),
                            const Padding(
                              padding: EdgeInsets.only(left: 40),
                              child: Divider(
                                color: kTabBarColor,
                                thickness: 1,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    const SizedBox(
                      width: 20,
                    ),
                    Expanded(
                      child: TextFormField(
                        style: const TextStyle(color: kTextColor),
                        decoration: const InputDecoration(
                          focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: kPrimaryColor)),
                          hintText: "Add comment",
                          hintStyle: TextStyle(color: kTextColor),
                          fillColor: kTabBarColor,
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: kTabBarColor),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.symmetric(horizontal: 10),
                      decoration: BoxDecoration(
                          color: kPrimaryColor,
                          borderRadius: BorderRadius.circular(4)),
                      width: 50,
                      height: 50,
                      child: IconButton(
                        onPressed: () {},
                        icon: const Icon(
                          Icons.send,
                          color: kTextColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        });
  }

  Row buildLiman() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            const CircleAvatar(
              radius: 15,
              backgroundImage: AssetImage("assets/guy.png"),
            ),
            const SizedBox(
              width: 4,
            ),
            Container(
              alignment: Alignment.center,
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Liman",
                    style: TextStyle(color: kTextColor, fontSize: 10),
                  ),
                  Row(
                    children: [
                      Text(
                        "This guy is on God mode he is on fire",
                        style: TextStyle(color: kTextColor, fontSize: 8),
                      ),
                      SizedBox(
                        width: 4,
                      ),
                      SizedBox(
                        height: 20,
                        child: Image(image: AssetImage("assets/fire.png")),
                      ),
                      SizedBox(
                        width: 2,
                      ),
                      SizedBox(
                        height: 20,
                        child: Image(image: AssetImage("assets/fire.png")),
                      )
                    ],
                  ),
                  Text(
                    "Reply",
                    style: TextStyle(color: kTextColor, fontSize: 10),
                  ),
                ],
              ),
            ),
          ],
        ),
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Just now",
              style: TextStyle(color: kTextColor, fontSize: 10),
            ),
            SizedBox(
              height: 4,
            ),
            Row(
              children: [
                Icon(
                  Icons.thumb_up_alt_rounded,
                  size: 15,
                  color: kPrimaryColor,
                ),
                SizedBox(
                  width: 2,
                ),
                Text(
                  "2.4k",
                  style: TextStyle(color: kTextColor, fontSize: 10),
                ),
              ],
            )
          ],
        ),
      ],
    );
  }

  buildRobey() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            const CircleAvatar(
              radius: 15,
              backgroundImage: AssetImage("assets/yellow.png"),
            ),
            const SizedBox(
              width: 4,
            ),
            Container(
              alignment: Alignment.center,
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Robby",
                    style: TextStyle(color: kTextColor, fontSize: 10),
                  ),
                  Row(
                    children: [
                      Text(
                        "This guy is on God mode he is on fire",
                        style: TextStyle(color: kTextColor, fontSize: 8),
                      ),
                      SizedBox(
                        width: 4,
                      ),
                      SizedBox(
                        height: 20,
                        child: Image(image: AssetImage("assets/fire.png")),
                      ),
                      SizedBox(
                        width: 2,
                      ),
                      SizedBox(
                        height: 20,
                        child: Image(image: AssetImage("assets/fire.png")),
                      )
                    ],
                  ),
                  Text(
                    "Reply",
                    style: TextStyle(color: kTextColor, fontSize: 10),
                  ),
                ],
              ),
            ),
          ],
        ),
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Just now",
              style: TextStyle(color: kTextColor, fontSize: 10),
            ),
            SizedBox(
              height: 4,
            ),
            Row(
              children: [
                Icon(
                  Icons.thumb_up_alt_rounded,
                  size: 15,
                  color: kPrimaryColor,
                ),
                SizedBox(
                  width: 2,
                ),
                Text(
                  "2.4k",
                  style: TextStyle(color: kTextColor, fontSize: 10),
                ),
              ],
            )
          ],
        ),
      ],
    );
  }

  Future<dynamic> buildWhy(BuildContext context, double height) {
    return showModalBottomSheet(
        context: context,
        builder: (context) {
          return Container(
            height: height / 2,
            width: MediaQuery.of(context).size.width,
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
              color: kBackgroundColor,
            ),
            child: Padding(
              padding: const EdgeInsets.all(kDefaultPadding),
              child: Column(
                children: [
                  Center(
                    child: Container(
                      width: 100,
                      height: 5,
                      color: kTabBarColor,
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  const Center(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Image(
                          image: AssetImage("assets/good.png"),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Text(
                          "Thanks for letting us know",
                          style: TextStyle(
                              color: Colors.green, fontWeight: FontWeight.w300),
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        Text(
                          "This pos will be reviewed to confirm violation of ",
                          style: TextStyle(
                            color: kTextColor,
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Text(
                          "cummunity standard",
                          style: TextStyle(
                            color: kTextColor,
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          );
        });
  }
}
