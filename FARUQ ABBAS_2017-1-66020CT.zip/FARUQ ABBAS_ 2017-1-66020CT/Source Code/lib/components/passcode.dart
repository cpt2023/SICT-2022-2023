import 'package:flutter/material.dart';
import 'package:pin_plus_keyboard/package/controllers/pin_input_controller.dart';
import 'package:pin_plus_keyboard/package/pin_plus_keyboard_package.dart';

import '../utils/app_colors.dart';

class PassCode extends StatefulWidget {
  const PassCode({super.key});

  @override
  State<PassCode> createState() => _PassCodeState();
}

class _PassCodeState extends State<PassCode> {
  PinInputController pinInputController = PinInputController(length: 4);
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: SizedBox(
        width: size.width,
        height: 100,
        child: Column(
          children: [
            PinPlusKeyBoardPackage(
              spacing: size.height * 0.06,
              pinInputController: pinInputController,
              onSubmit: () {},
              keyboardFontFamily: "",
              keyboardButtonShape: KeyboardButtonShape.circular,
              inputShape: InputShape.circular,
              inputHasBorder: false,
              inputFillColor: kTabBarColor,
              btnTextColor: kPrimaryColor,
              keyboardMaxWidth: 70,
            ),
          ],
        ),
      ),
    );
  }
}
