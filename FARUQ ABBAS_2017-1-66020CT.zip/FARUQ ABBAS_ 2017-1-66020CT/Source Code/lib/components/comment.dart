import 'package:flutter/material.dart';

import '../utils/app_colors.dart';

class CommentTile extends StatelessWidget {
  final Color color;
  final IconData icon;

  const CommentTile({super.key, required this.color, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Row(
      
      children: [
        Icon(
          icon,
          color: color,
        ),
        const SizedBox(
          width: 4,
        ),
        const Text(
          "2.4k",
          style: TextStyle(color: kTextColor),
        ),
        const SizedBox(
          width: 40,
        ),
        Image.asset('assets/mes.png'),
        const SizedBox(
          width: 4,
        ),
        const Text(
          "2.4k",
          style: TextStyle(color: kTextColor),
        ),
      ],
    );
  }
}
