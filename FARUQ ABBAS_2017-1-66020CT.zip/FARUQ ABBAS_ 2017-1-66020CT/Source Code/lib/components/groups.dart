import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../groups_message/groups.dart';
import '../utils/app_colors.dart';

class Groups extends StatefulWidget {
  const Groups({super.key});

  @override
  State<Groups> createState() => _GroupsState();
}

class _GroupsState extends State<Groups> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListTile(
          leading: const CircleAvatar(
            radius: 20,
            child: Image(
              image: AssetImage("assets/cap.png"),
            ),
          ),
          title: Text(
            "Call of duty",
            style: GoogleFonts.poppins(textStyle: kbtn2text, color: kTextColor),
          ),
          subtitle: Text(
            "Call of duty followers",
            style: GoogleFonts.poppins(textStyle: kbtn2text, color: kTextColor),
          ),
          trailing: IconButton(
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const Groupss()));
            },
            icon: const Icon(
              Icons.cancel,
              color: kTabBarColor,
            ),
          ),
        ),
      ],
    );
  }
}
