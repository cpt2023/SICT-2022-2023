import 'package:flutter/cupertino.dart';

class StepperTile extends StatelessWidget {
  const StepperTile({
    super.key,
    required this.color,
  });
  final Color? color;
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        height: 4,
        color: color,
      ),
    );
  }
}
