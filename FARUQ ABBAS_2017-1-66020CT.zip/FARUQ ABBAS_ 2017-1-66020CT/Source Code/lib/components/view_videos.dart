import 'package:flutter/material.dart';

import '../utils/app_colors.dart';

class ViewVideos extends StatefulWidget {
  const ViewVideos({super.key});

  @override
  State<ViewVideos> createState() => _ViewVideosState();
}

class _ViewVideosState extends State<ViewVideos> {
  List<String> names = [
    "Robby",
    "Candy",
    "Money",
    "Sniper",
    "Shooter",
    "Trunk",
    "Duty",
    "Sniper",
    "Duty",
    "Sniper",
  ];
  List<String> subs = [
    "Call of duty: Sake vs Squad",
    "Call of duty: Battle Royal",
    "Call of duty: Sake vs Squad",
    "Call of duty: Battle Royal",
    "Call of duty: Sake vs Squad",
    "Call of duty: Battle Royal",
    "Call of duty: Sake vs Squad",
    "Call of duty: Battle Royal",
    "Call of duty: Sake vs Squad",
    "Call of duty: Battle Royal",
  ];
  List<String> titles = [
    "Call of duty: Sake vs Squad",
    "Call of duty: Battle Royal",
    "Call of duty: Sake vs Squad",
    "Call of duty: Battle Royal",
    "Call of duty: Sake vs Squad",
    "Call of duty: Battle Royal",
    "Call of duty: Sake vs Squad",
    "Call of duty: Battle Royal",
    "Call of duty: Sake vs Squad",
    "Call of duty: Battle Royal",
  ];
  List<String> images = [
    "assets/shooter.png",
    "assets/trunk.png",
    "assets/duty.png",
    "assets/sniper.png",
    "assets/shooter.png",
    "assets/trunk.png",
    "assets/duty.png",
    "assets/sniper.png",
    "assets/duty.png",
    "assets/sniper.png",
  ];
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          height: 150,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
            color: kBackgroundColor,
          ),
          child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: 10,
              itemBuilder: (BuildContext context, int index) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.symmetric(horizontal: 20),
                      height: 70,
                      width: 120,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          image: DecorationImage(
                              image: AssetImage(
                                images[index],
                              ),
                              fit: BoxFit.cover)),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 20, right: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            titles[index],
                            style: const TextStyle(
                              fontSize: 10,
                              color: kTextColor,
                            ),
                          ),
                          const SizedBox(
                            height: 4,
                          ),
                          Text(
                            names[index],
                            style: const TextStyle(
                              fontSize: 8,
                              color: kTextColor,
                            ),
                          ),
                          const SizedBox(
                            height: 4,
                          ),
                          Text(
                            subs[index],
                            style: const TextStyle(
                              fontSize: 8,
                              color: kTextColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              }),
        ),
      ],
    );
  }
}
