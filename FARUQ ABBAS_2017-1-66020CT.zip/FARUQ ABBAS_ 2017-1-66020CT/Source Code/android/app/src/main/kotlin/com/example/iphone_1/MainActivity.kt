package com.example.iphone_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
