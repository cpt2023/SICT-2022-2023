package com.example.game_on

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
