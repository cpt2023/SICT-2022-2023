# %%
#loading dataset
import pandas as pd
import numpy as np
#visualisation
import matplotlib.pyplot as plt
%matplotlib inline
import seaborn as sns
#EDA
from collections import Counter
import ydata_profiling as pp
# data preprocessing
from sklearn.preprocessing import StandardScaler
# data splitting
from sklearn.model_selection import train_test_split
# data modeling
from sklearn.metrics import confusion_matrix,accuracy_score,roc_curve,classification_report, precision_score, f1_score, recall_score
from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
#ensembling
from mlxtend.classifier import StackingCVClassifier

# %%
data = pd.read_csv('heart.csv')
data.head()


# %%
data

# %%
data.info()

# %%
data.isnull().sum()

# %%
data.describe()

# %%
# Plotting using seaborn
plt.figure(figsize=(12, 8))
sns.countplot(data, x='target')
plt.title('Distribution of Target Variable')
plt.show()

# Plotting histograms for numerical features
numerical_features = data.select_dtypes(include=['int64', 'float64']).columns
data[numerical_features].hist(bins=20, figsize=(15, 10))
plt.suptitle('Histograms of Numerical Features', y=1.02, fontsize=16)
plt.show()

# Plotting boxplots for numerical features
plt.figure(figsize=(15, 10))
for i, feature in enumerate(numerical_features, 1):
    plt.subplot(3, 5, i)
    sns.boxplot(x='target', y=feature, data=data)
    plt.title(f'Boxplot of {feature}')
plt.tight_layout()
plt.show()

# %% [markdown]
# ## **EDA**

# %%
pp.ProfileReport(data)

# %% [markdown]
# ## **Model prepration**

# %%
y = data["target"]
X = data.drop('target',axis=1)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state = 0)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

x_Data= pd.DataFrame(X_train)
x_Datas= pd.DataFrame(X_test)

print(x_Datas)
# size_train = X_train.size()[0]
# size_test = X_test.size()[0]
# respond
# print(X_train)
# print(size_test)
# print(size_train)

# %% [markdown]
# **Before applying algorithm we should check whether the data is equally splitted or not, because if data is not splitted equally it will cause for data imbalacing problem**

# %% [markdown]
# ## **ML Models**
# 
# Here I take different machine learning algorithm and try to find algorithm which predict accurately.
# 
# 1. Random Forest Classifier
# 5. K-Nearest Neighbour
# 7. Support Vector Machine

# %% [markdown]
# ## **Random Forest Classfiers**

# %%
m3 = 'Random Forest Classfier'
rf = RandomForestClassifier(n_estimators=20, random_state=2,max_depth=10)
rf.fit(X_train,y_train)
rf_predicted = rf.predict(X_test)
rf_conf_matrix = confusion_matrix(y_test, rf_predicted)
rf_acc_score = accuracy_score(y_test, rf_predicted)
print("confussion matrix")
print(rf_conf_matrix)
print("\n")
print("Accuracy of Random Forest:",rf_acc_score*100,'\n')
print(classification_report(y_test,rf_predicted))

# %% [markdown]
# ## **K-Nearest Neighbor**

# %%
m5 = 'K-NeighborsClassifier'
knn = KNeighborsClassifier(n_neighbors=10)
knn.fit(X_train, y_train)
knn_predicted = knn.predict(X_test)
knn_conf_matrix = confusion_matrix(y_test, knn_predicted)
knn_acc_score = accuracy_score(y_test, knn_predicted)
print("confussion matrix")
print(knn_conf_matrix)
print("\n")
print("Accuracy of K-NeighborsClassifier:",knn_acc_score*100,'\n')
print(classification_report(y_test,knn_predicted))

# %% [markdown]
# ## **Support Vector Classifiers**

# %%
m7 = 'Support Vector Classifier'
svc =  SVC(kernel='rbf', C=10)
svc.fit(X_train, y_train)
svc_predicted = svc.predict(X_test)
svc_conf_matrix = confusion_matrix(y_test, svc_predicted)
svc_acc_score = accuracy_score(y_test, svc_predicted)
print("confussion matrix")
print(svc_conf_matrix)
print("\n")
print("Accuracy of Support Vector Classifier:",svc_acc_score*100,'\n')
print(classification_report(y_test,svc_predicted))

# %% [markdown]
# **Evaluation**

# %%
svc_acc_score = accuracy_score(y_test, svc_predicted)
svc_f1_score= f1_score(y_test, svc_predicted)
svc_recall_score= recall_score(y_test, svc_predicted)
svc_pre_score = precision_score(y_test, svc_predicted)
print("Accuracy:",svc_acc_score*100,'\n')
print("Precision:",svc_pre_score*100,'\n')
print("Recall:",svc_recall_score*100,'\n')
print("F1 score:",svc_f1_score*100,'\n')


# %% [markdown]
# ## **Important Features**

# %%

# random forest
rf_false_positive_rate,rf_true_positive_rate,rf_threshold = roc_curve(y_test,rf_predicted) 
# knn                                                #  
knn_false_positive_rate,knn_true_positive_rate,knn_threshold = roc_curve(y_test,knn_predicted)
# svm
svc_false_positive_rate,svc_true_positive_rate,svc_threshold = roc_curve(y_test,svc_predicted)

# %%
sns.set_style('whitegrid')
plt.figure(figsize=(10,5))
plt.title('Reciver Operating Characterstic Curve')
plt.plot(rf_false_positive_rate,rf_true_positive_rate,label='Random Forest')
plt.plot(knn_false_positive_rate,knn_true_positive_rate,label='K-Nearest Neighbor')
plt.plot(svc_false_positive_rate,svc_true_positive_rate,label='Support Vector Classifier')
plt.plot([0,1],ls='--')
plt.plot([0,0],[1,0],c='.5')
plt.plot([1,1],c='.5')
plt.ylabel('True positive rate')
plt.xlabel('False positive rate')
plt.legend()
plt.show()

# %% [markdown]
# ## **Model Evaluation**

# %%
model_ev = pd.DataFrame({'Model': ['Random Forest',
                    'K-Nearest Neighbour','Support Vector Machine'], 'Accuracy': [rf_acc_score*100,knn_acc_score*100,svc_acc_score*100]})
model_ev

# %% [markdown]
# **Plot**

# %%
colors = ['red','green','blue']
plt.figure(figsize=(12,5))
plt.title("barplot Represent Accuracy of different models")
plt.xlabel("Accuracy %")
plt.ylabel("Algorithms")
plt.bar(model_ev['Model'],model_ev['Accuracy'],color = colors)
plt.show()

# %% [markdown]
# ## **Ensemple**

# %%
done to increase the accuracy of the model stack technique will be use

# %%
scv=StackingCVClassifier(classifiers=[knn,svc, rf,],meta_classifier= svc,random_state=42)
scv.fit(X_train,y_train)
scv_predicted = scv.predict(X_test)
scv_conf_matrix = confusion_matrix(y_test, scv_predicted)
scv_acc_score = accuracy_score(y_test, scv_predicted)
print("confussion matrix")
print(scv_conf_matrix)
print("\n")
print("Accuracy of StackingCVClassifier:",scv_acc_score*100,'\n')
print(classification_report(y_test,scv_predicted))

# %%
# Combining base classifier predictions for XGBoost input
xgb_input = list(zip( rf_predicted, knn_predicted, svc_predicted))
# Training the XGBoost classifier

# Creating an XGBoost classifier
xgb_classifier = XGBClassifier(n_estimators=50, random_state=42)

# Training the XGBoost classifier
xgb_classifier.fit(xgb_input, y_test)

# Making predictions
xgb_predicted = xgb_classifier.predict(xgb_input)

# Evaluating accuracy
accuracy_xgb = accuracy_score(y_test, xgb_preds)
print(f'Accuracy (XGBoost): {accuracy_xgb}')


# confussion matrix
xgb_conf_matrix = confusion_matrix(y_test, xgb_predicted)
xgb_acc_score = accuracy_score(y_test, xgb_predicted)
print("confussion matrix")
print(xgb_conf_matrix)
print("\n")
print("Accuracy of XG_Boost:",xgb_acc_score*100,'\n')
print(classification_report(y_test,xgb_predicted))


