	<!DOCTYPE html>
	<html lang="en">
	<!--begin::Head-->

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title><?= $website_title ?></title>
		<!--begin::Primary Meta Tags-->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="title" content="<?= $website_title ?>">
		<meta name="author" content="">
		<meta name="description" content="">
		<meta name="keywords" content="">
		<!--end::Primary Meta Tags-->
		<!--begin::Fonts-->
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,300;0,400;0,700;1,400&display=swap" rel="stylesheet">
		<!--end::Fonts-->
		<!--begin::Third Party Plugin(OverlayScrollbars)-->
		<link rel="stylesheet" href="<?= $server_name ?>/assets/vendor/overlayscrollbars/css/overlayscrollbars.min.css">
		<!--end::Third Party Plugin(OverlayScrollbars)-->
		<!--begin::Third Party Plugin(Font Awesome)-->
		<link rel="stylesheet" href="<?= $server_name ?>/assets/vendor/font-awesome/css/all.min.css" >		<!--end::Third Party Plugin(Font Awesome)-->
		<!--begin::Required Plugin(AdminLTE)-->
		<link rel="stylesheet" href="<?= $server_name ?>/assets/css/adminlte.css">
		<!--end::Required Plugin(AdminLTE)-->

	   <!-- apexcharts -->
	   <link rel="stylesheet" href="<?= $server_name ?>/assets/vendor/apexcharts/apexcharts.css">

	   <!-- jsvectormap -->
	   <link rel="stylesheet" href="<?= $server_name ?>/assets/vendor/jsvectormap/css/jsvectormap.min.css">

		<!-- data table -->
		<!-- datatables -->
		<link href="<?= $server_name ?>/assets/vendor/new_datatables/datatables.min.css" rel="stylesheet">
	</head>

	<?php 
	if ( !in_array( $page, $header_blacklist_arr ) )
	{      
	?>
	<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
	<!--begin::App Wrapper-->
	<div class="app-wrapper">
		<!--begin::Header-->
		<nav class="app-header navbar navbar-expand bg-body">
			<!--begin::Container-->
			<div class="container-fluid">
					<!--begin::Start Navbar Links-->
					<ul class="navbar-nav">
						<li class="nav-item">
							<a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
									<i class="fa-solid fa-bars"></i>
							</a>
						</li>
					</ul>
					<!--end::Start Navbar Links-->

					<!--begin::End Navbar Links-->
					<ul class="navbar-nav ms-auto">
						
						<!--begin::User Menu Dropdown-->
						<li class="nav-item dropdown user-menu">
							<a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
									<img src="<?= $server_name ?>/assets/img/avatar.png" class="user-image rounded-circle shadow" alt="User Image">
							</a>
							<ul class="dropdown-menu dropdown-menu-lg dropdown-menu-end">
									
									<!--begin::Menu Footer-->
									<li class="user-footer">
										<a href="logout" class="btn btn-default btn-flat float-end">Sign out</a>
									</li>
									<!--end::Menu Footer-->
							</ul>
						</li>
						<!--end::User Menu Dropdown-->
					</ul>
					<!--end::End Navbar Links-->
			</div>
			<!--end::Container-->
		</nav>
		<!--end::Header-->
		<!--begin::Sidebar-->
		<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
			<!--begin::Sidebar Brand-->
			<div class="sidebar-brand">
					<!--begin::Brand Link-->
					<a href="../index.html" class="brand-link">
						<!--begin::Brand Image-->
						<img src="<?= $server_name ?>/assets/img/AdminLTELogo.png" alt="Logo" class="brand-image opacity-75 shadow">
						<!--end::Brand Image-->
						<!--begin::Brand Text-->
						<span class="brand-text fw-light">Arms Inventory</span>
						<!--end::Brand Text-->
					</a>
					<!--end::Brand Link-->
			</div>
			<!--end::Sidebar Brand-->
			<!--begin::Sidebar Wrapper-->
			<div class="sidebar-wrapper">
					<nav class="mt-2">
						<!--begin::Sidebar Menu-->
						<ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">
							<li class="nav-item menu-open">
									<a href="dashboard" class="nav-link ">
										<i class="nav-icon fa-solid fa-gauge-high"></i>
										<p>
											Dashboard
										</p>
									</a>
							</li>
							<!-- <li class="nav-item menu-open">
									<a href="personels" class="nav-link active">
										<i class="nav-icon fa-solid fa-users"></i>
										<p>
											Personels
										</p>
									</a>
							</li> -->

							<li class="nav-item menu-open">
								<a href="arms" class="nav-link">
									<i class="nav-icon fa-solid fa-box"></i>
									<p>
										Arms
									</p>
								</a>
							</li>

							<li class="nav-item menu-open">
								<a href="ammunitions" class="nav-link">
									<i class="nav-icon fa-solid fa-briefcase"></i>
									<p>
										Ammunitions
									</p>
								</a>
							</li>

							<li class="nav-item menu-open">
								<a href="purchases" class="nav-link">
									<i class="nav-icon fa-solid fa-shopping-cart"></i>
									<p>
										Purchases
									</p>
								</a>
							</li>
							
							<li class="nav-item menu-open">
								<a href="reports" class="nav-link">
									<i class="nav-icon fa-solid fa-newspaper"></i>
									<p>
										Reports (Missing/Stolen)
									</p>
								</a>
							</li>

							<li class="nav-item menu-open">
								<a href="requests" class="nav-link">
									<i class="nav-icon fa fa-envelope"></i>
									<p>
										Requests
									</p>
								</a>
							</li>

						</ul>
						<!--end::Sidebar Menu-->
					</nav>
			</div>
			<!--end::Sidebar Wrapper-->
		</aside>
		<!--end::Sidebar-->
	<?php
	}
	?>