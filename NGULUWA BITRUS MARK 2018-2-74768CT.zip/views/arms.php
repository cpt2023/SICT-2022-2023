<!--begin::App Main-->
<main class="app-main">
    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-0">Arms</h3>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="dashboard">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">
                            Arms
                        </li>
                    </ol>
                </div>
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content Header-->
    <!--begin::App Content-->
    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                       <div class="card-body">
                          <div class="text-end mb-2 mt-2">
                             <button type="button" id="add_arms_btn" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addArmModal" title="Add Arm">
                             <label for="add_arms_btn" class=""><i class="bi bi-plus-lg"></i> <span class="d-none d-md-inline">Add Arms</span></label>
                             </button>
                          </div>
                          <div id="alert_msg"></div>

                          <?php
                             echo $web_app->showAlert( $msg, true );
              
                             if ( $arms_arr ) 
                             {
                          ?>
                          <div class="mt-2">
                             <?php
                                echo "<table class='table table-responsive table-striped' id='my_datatable' style='width: 100%'>
                                <thead>
                                   <tr>
                                      <th>S/N</th>
                                      <th>Make</th>
                                      <th>Company</th>
                                      <th>Country</th>
                                      <th>Title</th>
                                      <th>Stock</th>
                                      <th>Action</th>
                                   </tr>
                                </thead>
                                <tfoot>
                                   <tr>
                                      <th>S/N</th>
                                      <th>Make</th>
                                      <th>Company</th>
                                      <th>Country</th>
                                      <th>Stock</th>
                                      <th>Action</th>
                                   </tr>
                                </tfoot>
                                <tbody>";

                                $sn = 0;
                                $tr_content = '';

                                //looping through records
                                foreach ( $arms_arr as $arms_data ) 
                                {
                                    $id = $arms_data[ 'id' ];
                                   $brand_id = $arms_data[ 'brand_id' ];
                                   $brand_dt = $brand->getById( [ $brand_id ] );
                                   $country = $brand_dt['country'];
                                   $make = $brand_dt['make'];
                                   $company = $brand_dt['company'];
                                   $title = $arms_data[ 'title' ];
                                   $stock = $arms_data[ 'stock' ];
                                   $sn++;
                                   
                                   $tr_content .=  "<tr>
                                      <td class='fw-light'> $sn </td>
                                      <td class='fw-light'> $make </td>
                                      <td class='fw-light'> $company </td>
                                      <td class='fw-light'> $country </td>
                                      <td class='fw-light'> $title </td>                              
                                      <td class='fw-light'> $stock </td>
                                      <td class='fw-light'>
                                          <button class='btn btn-success mb-2 update_arms_btn' id='update_arms_btn$id' data-arms_id='$id' data-brand_id='$brand_id' data-title='$title' data-stock='$stock'  data-bs-toggle='modal' data-bs-target='#update_arms' title='Update'><label for='update_arms_btn$id' class=''><i class='fa fa-pencil'></i> <span class='d-none d-md-inline'>Update</span></label>
                                          </button>
                                      </td>
                                   </tr>";
                                }

                                echo $tr_content .= '</tbody></table>';
                          
                             ?>
                          </div>
                          <?php
                             }
                          ?>
                       </div>
                    </div>
                </div>
            </div>
   
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
</main>
<!--end::App Main-->

<!-- Start Add Arm Modal-->
<div class="modal fade" id="addArmModal" tabindex="-1">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <h3 class="modal-title"><strong>Add Arms</strong></h3>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body">
            <form action="" method="POST">
                <div class="row">
                    <div class="col-md-6 mb-2">
                        <label for="brand" class="fw-bold">Brand <span class="text-danger">*</span></label>
                        <div>
                            <select name="brand" id="brand" class="form-select">
                               <option>Select Brand</option>
                               <?= $brand->loadBrands( $brand_arr, $web_app->persistData( 'brand', false, $clear ) ) ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="title" class="fw-bold">Title <span class="text-danger">*</span></label>
                        <div>
                            <input type="text" name="title" id="title" class="form-control" required placeholder="Enter Title" value="<?= $web_app->persistData( 'title', false, $clear ) ?>">
                        </div>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="stock" class="fw-bold">Stock <span class="text-danger">*</span></label>
                        <div>
                            <input type="number" name="stock" id="stock" class="form-control" required placeholder="Enter Stock" value="<?= $web_app->persistData( 'stock', false, $clear ) ?>">
                        </div>
                    </div>

                    <div class="text-center mt-3">
                        <button name="add_btn" id="add_btn" class="btn btn-success">Add</button>
                    </div>
                </div>
            </form>
         </div>
      </div>
   </div>
</div>
<!-- End Add Arm Modal-->

<!-- Start Edit Arm Modal-->
<div class="modal fade" id="update_arms" tabindex="-1">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <h3 class="modal-title"><strong>Update Arms</strong></h3>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body">
            <form action="" method="POST">
               <input type="hidden" name="arms_id" id="arms_id">
                <div class="row">
                    <div class="col-md-6 mb-2">
                        <label for="e_brand" class="fw-bold">Brand <span class="text-danger">*</span></label>
                        <div>
                            <select name="e_brand" id="e_brand" class="form-select">
                               <option>Select Brand</option>
                               <?= $brand->loadBrands( $brand_arr ) ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="e_title" class="fw-bold">Title <span class="text-danger">*</span></label>
                        <div>
                            <input type="text" name="e_title" id="e_title" class="form-control" required placeholder="Enter Title">
                        </div>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="e_stock" class="fw-bold">Stock <span class="text-danger">*</span></label>
                        <div>
                            <input type="number" name="e_stock" id="e_stock" class="form-control" required placeholder="Enter Stock">
                        </div>
                    </div>
                    <div class="text-center mt-3">
                        <button name="edit_btn" id="edit_btn" class="btn btn-success">Update</button>
                    </div>
                </div>
            </form>            
         </div>
      </div>
   </div>
</div>
<!-- End Edit Arm Modal-->