<!--begin::App Main-->
<main class="app-main">
    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-0">Personels</h3>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="dashboard">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">
                            Personels
                        </li>
                    </ol>
                </div>
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content Header-->
    <!--begin::App Content-->
    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                       <div class="card-body">
                          <div class="text-end mb-2 mt-2">
                             <button type="button" id="add_personel_btn" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addPersonelModal" title="Add Personel">
                             <label for="add_personel_btn" class=""><i class="bi bi-plus-lg"></i> <span class="d-none d-md-inline">Add Personel</span></label>
                             </button>
                          </div>
                          <div id="alert_msg"></div>

                          <?php
                             echo $web_app->showAlert( $msg, true );
              
                             if ( $personel_arr ) 
                             {
                          ?>
                          <div class="mt-2">
                             <?php
                                echo "<table class='table table-responsive table-striped' id='my_datatable' style='width: 100%'>
                                <thead>
                                   <tr>
                                      <th>S/N</th>
                                      <th>Full Name</th>
                                      <th>Service Number</th>
                                      <th>Rank</th>
                                      <th>Action</th>
                                   </tr>
                                </thead>
                                <tfoot>
                                   <tr>
                                      <th>S/N</th>
                                      <th>Full Name</th>
                                      <th>Service Number</th>
                                      <th>Rank</th>
                                      <th>Action</th>
                                   </tr>
                                </tfoot>
                                <tbody>";

                                $sn = 0;
                                $tr_content = '';

                                //looping through records
                                foreach ( $personel_arr as $personel_data ) 
                                {
                                   $id = $personel_data[ 'id' ];
                                   $first_name = $personel_data[ 'first_name' ];
                                   $last_name = $personel_data[ 'last_name' ];
                                   $full_name = $web_app->fullName( $personel_data );                                   
                                   $service_no = $personel_data[ 'service_no' ];
                                   $rank = $personel_data[ 'rank' ];
                                   $sn++;
                                   
                                   $tr_content .=  "<tr>
                                      <td class='fw-light'> $sn </td>
                                      <td class='fw-light'> $full_name </td>
                                      <td class='fw-light'> $service_no </td>                              
                                      <td class='fw-light'> $rank </td>
                                      <td class='fw-light'>
                                          <button class='btn btn-success mb-2 update_personel_btn' id='update_personel_btn$id' data-personel_id='$id' data-first_name='$first_name' data-last_name='$last_name' data-service_no='$service_no' data-rank='$rank'  data-bs-toggle='modal' data-bs-target='#update_personel' title='Update'><label for='update_personel_btn$id' class=''><i class='fa fa-pencil'></i> <span class='d-none d-md-inline'>Update</span></label>
                                          </button>
                                      </td>
                                   </tr>";
                                }

                                echo $tr_content .= '</tbody></table>';
                          
                             ?>
                          </div>
                          <?php
                             }
                          ?>
                       </div>
                    </div>
                </div>
            </div>
   
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
</main>
<!--end::App Main-->

<!-- Start Add Personel Modal-->
<div class="modal fade" id="addPersonelModal" tabindex="-1">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <h3 class="modal-title"><strong>Add Personel</strong></h3>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body">
            <form action="" method="POST">
                <div class="row">
                    <div class="col-md-6 mb-2">
                        <label for="first_name" class="fw-bold">First Name <span class="text-danger">*</span></label>
                        <div>
                            <input type="text" name="first_name" id="first_name" class="form-control" autofocus required placeholder="Enter First Name" value="<?= $web_app->persistData( 'first_name', false, $clear ) ?>">
                        </div>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="last_name" class="fw-bold">Last Name <span class="text-danger">*</span></label>
                        <div>
                            <input type="text" name="last_name" id="last_name" class="form-control" required placeholder="Enter Last Name" value="<?= $web_app->persistData( 'last_name', false, $clear ) ?>">
                        </div>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="service_no" class="fw-bold">Service Number <span class="text-danger">*</span></label>
                        <div>
                            <input type="text" name="service_no" id="service_no" class="form-control" required placeholder="Enter Service Number" value="<?= $web_app->persistData( 'service_no', false, $clear ) ?>">
                        </div>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="rank" class="fw-bold">Rank <span class="text-danger">*</span></label>
                        <div>
                            <input type="text" name="rank" id="rank" class="form-control" required placeholder="Enter Rank" value="<?= $web_app->persistData( 'rank', false, $clear ) ?>">
                        </div>
                    </div>
                    <div class="text-center mt-3">
                        <button name="add_btn" id="add_btn" class="btn btn-success">Add</button>
                    </div>
                </div>
            </form>
         </div>
      </div>
   </div>
</div>
<!-- End Add Personel Modal-->

<!-- Start Edit Personel Modal-->
<div class="modal fade" id="update_personel" tabindex="-1">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <h3 class="modal-title"><strong>Update Personel</strong></h3>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body">
            <form action="" method="POST">
               <input type="hidden" name="personel_id" id="personel_id">
                <div class="row">
                    <div class="col-md-6 mb-2">
                        <label for="e_first_name" class="fw-bold">First Name <span class="text-danger">*</span></label>
                        <div>
                            <input type="text" name="e_first_name" id="e_first_name" class="form-control" autofocus required placeholder="Enter First Name">
                        </div>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="e_last_name" class="fw-bold">Last Name <span class="text-danger">*</span></label>
                        <div>
                            <input type="text" name="e_last_name" id="e_last_name" class="form-control" required placeholder="Enter Last Name">
                        </div>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="e_service_no" class="fw-bold">Service Number <span class="text-danger">*</span></label>
                        <div>
                            <input type="text" name="e_service_no" id="e_service_no" readonly class="form-control" required placeholder="Enter Service Number">
                        </div>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="e_rank" class="fw-bold">Rank <span class="text-danger">*</span></label>
                        <div>
                            <input type="text" name="e_rank" id="e_rank" class="form-control" required placeholder="Enter Rank">
                        </div>
                    </div>
                    <div class="text-center mt-3">
                        <button name="edit_btn" id="edit_btn" class="btn btn-success">Update</button>
                    </div>
                </div>
            </form>            
         </div>
      </div>
   </div>
</div>
<!-- End Edit Personel Modal-->