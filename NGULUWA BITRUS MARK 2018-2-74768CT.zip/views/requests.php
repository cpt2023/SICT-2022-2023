<!--begin::App Main-->
<main class="app-main">
    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-0">Requests</h3>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="dashboard">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">
                            Request
                        </li>
                    </ol>
                </div>
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content Header-->
    <!--begin::App Content-->
    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                       <div class="card-body">
                          <div class="text-end mb-2 mt-2">
                             <button type="button" id="add_request_btn" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addRequestModal" title="Add Request">
                             <label for="add_request_btn" class=""><i class="bi bi-plus-lg"></i> <span class="d-none d-md-inline">Add Request</span></label>
                             </button>
                          </div>
                          <div id="alert_msg"></div>

                          <?php
                             echo $web_app->showAlert( $msg, true );
              
                             if ( $request_arr ) 
                             {
                          ?>
                          <div class="mt-2">
                             <?php
                                echo "<table class='table table-responsive table-striped' id='my_datatable' style='width: 100%'>
                                <thead>
                                   <tr>
                                      <th>S/N</th>
                                      <th>Title</th>
                                      <th>Description</th>
                                      <th>Total</th>
                                      <th>Status</th>
                                      <th>Added By</th>
                                      <th>Action</th>
                                   </tr>
                                </thead>
                                <tfoot>
                                   <tr>
                                      <th>S/N</th>
                                      <th>Title</th>
                                      <th>Description</th>
                                      <th>Total</th>
                                      <th>Status</th>
                                      <th>Added By</th>
                                      <th>Action</th>
                                   </tr>
                                </tfoot>
                                <tbody>";

                                $sn = 0;
                                $tr_content = '';

                                //looping through records
                                foreach ( $request_arr as $request_data ) 
                                {
                                   $id = $request_data[ 'id' ];
                                   $total = $request_data[ 'total' ];
                                   $title = $request_data[ 'title' ];
                                   $description = $request_data[ 'description' ];
                                   $status = $request_data[ 'status' ];
                                   $status_x = $web_app->showStatusType( $status );
                                   $load_statuses = $web_app->loadStatuses( $status );
                                   $admin_id = $request_data[ 'admin_id' ];
                                   $admin_dt = $admin->getById( [ $admin_id ] );
                                   $full_name = $web_app->fullName( $admin_dt );

                                   $sn++;

                                   
                                   $tr_content .=  "<tr>
                                      <td class='fw-light'> $sn </td>
                                      <td class='fw-light'> $title </td>
                                      <td class='fw-light'> $description </td>
                                      <td class='fw-light'> $total </td>
                                      <td class='fw-light'> $status_x </td>
                                      <td class='fw-light'> $full_name </td>
                                      <td class='fw-light'>
                                          <button class='btn btn-success mb-2 update_request_btn' id='update_request_btn$id' data-request_id='$id' data-total='$total' data-title='$title' data-description='$description'  data-bs-toggle='modal' data-bs-target='#updateRequest' title='Update'><label for='update_request_btn$id' class=''><i class='fa fa-pencil'></i> <span class='d-none d-md-inline'>Update</span></label>
                                          </button>
                                          <select name='status' id='status' data-id='$id' class='form-select update_status'>
                                             <option value=''>Select Status</option>
                                             $load_statuses
                                          </select>
                                      </td>
                                   </tr>";
                                }

                                echo $tr_content .= '</tbody></table>';
                          
                             ?>
                          </div>
                          <?php
                             }
                          ?>
                       </div>
                    </div>
                </div>
            </div>
   
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
</main>
<!--end::App Main-->

<!-- Start Add Request Modal-->
<div class="modal fade" id="addRequestModal" tabindex="-1">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <h3 class="modal-title"><strong>Add Request</strong></h3>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body">
            <form action="" method="POST">
                <div class="row">
                    <div class="col-md-6 mb-2">
                        <label for="title" class="fw-bold">Title <span class="text-danger">*</span></label>
                        <div>
                            <input type="text" name="title" id="title" class="form-control" required placeholder="Enter Title" maxlength="500" value="<?= $web_app->persistData( 'title', false, $clear ) ?>">                        
                        </div>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="total" class="fw-bold">Total <span class="text-danger">*</span></label>
                        <div>
                            <input type="number" name="total" id="total" class="form-control" required placeholder="Enter Total" maxlength="500" value="<?= $web_app->persistData( 'total', false, $clear ) ?>">                        
                        </div>
                    </div>
                    <div class="mb-2">
                        <label for="description" class="fw-bold">Description <span class="text-danger">*</span></label>
                        <div>
                            <textarea name="description" id="description" required maxlength="1000" class="form-control" placeholder="Enter Description"><?= $web_app->persistData( 'Description', false, $clear ) ?></textarea> 
                        </div>
                    </div>

                    <div class="text-center mt-3">
                        <button name="add_btn" id="add_btn" class="btn btn-success">Add</button>
                    </div>
                </div>
            </form>
         </div>
      </div>
   </div>
</div>
<!-- End Add Request Modal-->

<!-- Start Edit Request Modal-->
<div class="modal fade" id="updateRequest" tabindex="-1">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <h3 class="modal-title"><strong>Update Request</strong></h3>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body">
            <form action="" method="POST">
               <input type="hidden" name="request_id" id="request_id">
                <div class="row">
                    <div class="col-md-6 mb-2">
                        <label for="edit_title" class="fw-bold">Title <span class="text-danger">*</span></label>
                        <div>
                            <input type="text" name="edit_title" id="edit_title" class="form-control" required placeholder="Enter Title">    
                        </div>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="edit_total" class="fw-bold">Total <span class="text-danger">*</span></label>
                        <div>
                            <input type="number" name="edit_total" id="edit_total" class="form-control" required placeholder="Enter Total" maxlength="500">                        
                        </div>
                    </div>
                    <div class="mb-2">
                        <label for="edit_description" class="fw-bold">Description <span class="text-danger">*</span></label>
                        <div>
                            <textarea name="edit_description" id="edit_description" required maxlength="1000" class="form-control" placeholder="Enter Description"></textarea> 
                        </div>
                    </div>

                    <div class="text-center mt-3">
                        <button name="edit_btn" id="edit_btn" class="btn btn-success">Edit</button>
                    </div>
                </div>
            </form>            
         </div>
      </div>
   </div>
</div>
<!-- End Edit Request Modal-->