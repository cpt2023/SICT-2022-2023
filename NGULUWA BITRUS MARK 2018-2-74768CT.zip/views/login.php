<body class="login-page bg-body-secondary">
    <div class="login-box">
        <div class="login-logo">
            <a><b>Login</b></a>
        </div>
        <!-- /.login-logo -->
        <div class="card">
            <div class="card-body login-card-body">
                <p class="login-box-msg">Sign in to start your session</p>
                <?= $web_app->showAlert( $msg ) ?>
                <form method="POST">
                    <div class="input-group mb-3">
                        <input type="text" name="service_no" id="service_no" required autofocus class="form-control" placeholder="Service Number" value="<?= $web_app->persistData( 'service_no', false, $clear ) ?>" >
                        <div class="input-group-text">
                            <span class="fa fa-user"></span>
                        </div>
                    </div>
                    <div class="input-group mb-3">
                        <input type="password" name="pword" id="pword" required  class="form-control" placeholder="Password">
                        <div class="input-group-text">
                            <span class="fa fa-lock"></span>
                        </div>
                    </div>
                    <!--begin::Row-->
                    <div class="row">
                        <!-- /.col -->
                        <div class="col-4">
                            <div class="d-grid gap-2">
                                <button type="submit" name="log_btn" id="log_btn" class="btn btn-primary">Sign In</button>
                            </div>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!--end::Row-->
                </form>
            </div>
            <!-- /.login-card-body -->
        </div>
    </div>
</body>