<?php 
	#   Author of the script
	#   Name: Ezra Adamu
	#   Email: ezra00100@gmail.com
	#   Date created: 21/12/2023
   #   Date modified: 21/12/2023 

	//auth
	include_once( 'admin_auth.php' );

	//App function
	include_once( 'models/Purchase.php' );

   //Creating Instance
   $purchase = new Purchase();

	$js_modules = [ 'purchase' ];

	if ( isset( $_POST['add_btn'] ) ) 
	{
		$total = $_POST['total'];
		$title = $_POST['title'];
		$pch_type = $_POST['pch_type'];
		$description = $_POST['description'];

		if( $total && $title && $pch_type && $description ) 
		{
			$dt_01 = [ $admin_id, $pch_type, $title, $description, $total ];

			$add_purchase = $purchase->addNew( $dt_01 );

			if ( $add_purchase ) 
			{
				$msg = $web_app->showAlertMsg( 'success', 'Purchase Added!' ); 
				$clear = true;	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Purchase Not Added!' ); 	
			}							
		} 
		else 
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}		
	}

	else if ( isset( $_POST['edit_btn'] ) ) 
	{
		$id = $_POST['purchase_id'];
		$total = $_POST['edit_total'];
		$title = $_POST['edit_title'];
		$pch_type = $_POST['edit_pch_type'];
		$description = $_POST['edit_description'];

		if( $id && $total && $title && $pch_type && $description ) 
		{
			$dt_01 = [ $admin_id, $pch_type, $title, $description, $total, $id ];

			$update_purchase = $purchase->updateById( $dt_01 );

			if ( $update_purchase ) 
			{
				$msg = $web_app->showAlertMsg( 'success', 'Purchase Updated!' ); 
				$clear = true;	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Purchase Not Updated!' ); 	
			}							
		} 
		else 
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}		
	}

	$purchase_arr = $purchase->getAll( [ ] );

	if ( !$purchase_arr ) 
	{
		$msg = $web_app->showAlertMsg( 'info', 'Sorry, No Purchase Record(s) Found.' );
	}
	//Purchases interface
	include_once( 'views/purchases.php' );
 ?>