<?php 
	#   Author of the script
	#   Name: Ezra Adamu
	#   Email: ezra00100@gmail.com
	#   Date created: 09/10/2023
   #   Date modified: 19/10/2023 

	//auth
	include_once( 'admin_auth.php' );

	include_once( 'models/Personel.php');
   include_once( 'models/Arm.php');
   include_once( 'models/Ammunition.php');

   //Creating Instance
   $personel = new Personel();
   $arm = new Arm();
   $ammunition = new Ammunition();

	$total_personel = $personel->getCount( [ ] ); 
	$total_arm = $arm->getStockCount( [ ] ); 
	$total_ammu = $ammunition->getStockCount( [ ] ); 


	//Dashboard interface
	include_once( 'views/dashboard.php' );
 ?>