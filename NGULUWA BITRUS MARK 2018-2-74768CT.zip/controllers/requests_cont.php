<?php 
	#   Author of the script
	#   Name: Ezra Adamu
	#   Email: ezra00100@gmail.com
	#   Date created: 13/12/2023
   #   Date modified: 10/01/2024  

	//auth
	include_once( 'admin_auth.php' );

	//App function
	include_once( 'models/Request.php' );

   //Creating Instance
   $request = new Request();

	$js_modules = [ 'request' ];

	if ( isset( $_POST['add_btn'] ) ) 
	{
		$total = $_POST['total'];
		$title = $_POST['title'];
		$description = $_POST['description'];

		if( $total && $title && $description ) 
		{
			$dt_01 = [ $admin_id, $title, $description, $total ];

			$add_request = $request->addNew( $dt_01 );

			if ( $add_request ) 
			{
				$msg = $web_app->showAlertMsg( 'success', 'Request Added!' ); 
				$clear = true;	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Request Not Added!' ); 	
			}							
		} 
		else 
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
		
	}
	else if ( isset( $_POST['edit_btn'] ) ) 
	{
		$id = $_POST['request_id'];
		$total = $_POST['edit_total'];
		$title = $_POST['edit_title'];
		$description = $_POST['edit_description'];

		if( $id && $total && $title && $description ) 
		{
			$dt_01 = [ $admin_id, $title, $description, $total, $id ];

			$update_request = $request->updateById( $dt_01 );

			if ( $update_request ) 
			{
				$msg = $web_app->showAlertMsg( 'success', 'Request Updated!' ); 
				$clear = true;	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Request Not Updated!' ); 	
			}							
		} 
		else 
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}		
	}
	else if ( isset( $_POST[ 'update_status' ] ) ) 
   {
      ob_clean();

		$request_id = $_POST['request_id'];
		$status = $_POST['status'];

		if ( $request_id && $status ) 
		{
			$update_status = $request->updateStatusById( [ $admin_id, $status, $request_id ] );
		}
		
		$msg = $update_status ? $web_app->showAlertMsg( 'success', 'Status Updated!' ) : $web_app->showAlertMsg( 'danger', 'Sorry, Status Not Updated!' );
		
      echo json_encode( [ 'msg' => $msg ] );

      ob_end_flush();
      exit();
   }




	$request_arr = $request->getAll( [ ] );

	if ( !$request_arr ) 
	{
		$msg = $web_app->showAlertMsg( 'info', 'Sorry, No Request Record(s) Found.' );
	}
	//Requests interface
	include_once( 'views/requests.php' );
 ?>