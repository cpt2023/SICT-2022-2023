<?php
	#   Author of the script
	#   Name: Ezra Adamu
	#   Email: ezra00100@gmail.com
	#   Date created: 20/07/2022
	#   Date modified: 22/09/2023

	include_once( 'models/Admin.php' );
	
	//Creating instances
	$admin = new Admin(); 

	if ( isset( $_POST[ 'log_btn' ] ) ) 
	{
		// Getting user values
		$service_no = $_POST[ 'service_no' ];
		$pword = $_POST[ 'pword' ]; 

		//Validating inputs
		if ( $service_no && $pword ) 
		{
			$dt_01 = [ $service_no ];
			$admin_dt = $admin->getLogin( $dt_01 );
			$pwordx = $admin_dt[ 'pword' ] ?? '';
			$role = $admin_dt[ 'role' ] ?? '';
			
			//Match admin password
			$match_pword = $admin->decPword( $pword, $pwordx );

			if ( $match_pword && $role == 'NSA' ) 
			{  
				$id = $admin_dt[ 'id' ];
				//set session and cookie
				$time_out = time() + APP_SESS_TIME;
				$_SESSION[ APP_SESS ] = $id;
				setcookie( APP_SESS, $id, $time_out );

				//redirect
				header( 'Location: ./dashboard', true, 301 );
				exit();
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Admin Does Not Exist!' ); 
			}

		}
		else 
		{  
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter Username And Password.' ); 	
		}
	}

	//Login Interface
	include_once('views/login.php');
?>