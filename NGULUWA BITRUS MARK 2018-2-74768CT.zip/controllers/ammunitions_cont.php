<?php 
	#   Author of the script
	#   Name: Ezra Adamu
	#   Email: ezra00100@gmail.com
	#   Date created: 09/10/2023
   #   Date modified: 19/10/2023 

	//auth
	include_once( 'admin_auth.php' );

	//App function
	include_once( 'models/Brand.php' );
	include_once( 'models/Personel.php');
   include_once( 'models/Ammunition.php');

   //Creating Instance
   $personel = new Personel();
   $ammunition = new Ammunition();
	$brand = new Brand();

	$js_modules = [ 'ammunition' ];

	if ( isset( $_POST['add_btn'] ) ) 
	{
		$ammunition_brand = $_POST['brand'];
		$title = $_POST['title'];
		$stock = $_POST['stock'];

		if( $ammunition_brand && $title && $stock ) 
		{
			$dt_01 = [ $ammunition_brand, $title, $stock ];

			$add_ammunition = $ammunition->addNew( $dt_01 );

			if ( $add_ammunition ) 
			{
				$msg = $web_app->showAlertMsg( 'success', 'Ammunitions Added!' ); 
				$clear = true;	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Ammunitions Not Added!' ); 	
			}							
		} 
		else 
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
		
	}

	else if ( isset( $_POST['edit_btn'] ) ) 
	{
		$id = $_POST['ammunitions_id'];
		$ammunition_brand = $_POST['e_brand'];
		$title = $_POST['e_title'];
		$stock = $_POST['e_stock'];

		if( $ammunition_brand && $title && $stock ) 
		{
			$dt_01 = [ $ammunition_brand, $title, $stock, $id ];

			$update_ammunition = $ammunition->updateById( $dt_01 );

			if ( $update_ammunition ) 
			{
				$msg = $web_app->showAlertMsg( 'success', 'Ammunitions Updated!' ); 
				$clear = true;	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Ammunitions Not Updated!' ); 	
			}							
		} 
		else 
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}		
	}



	$ammunitions_arr = $ammunition->getAll( [ ] );

	$brand_arr = $brand->getAll( [ ] );

	if ( !$ammunitions_arr ) 
	{
		$msg = $web_app->showAlertMsg( 'info', 'Sorry, No Ammunitions Record(s) Found.' );
	}
	//Ammunitions interface
	include_once( 'views/ammunitions.php' );
 ?>