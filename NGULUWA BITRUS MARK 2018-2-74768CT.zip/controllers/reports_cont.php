<?php 
	#   Author of the script
	#   Name: Ezra Adamu
	#   Email: ezra00100@gmail.com
	#   Date created: 12/12/2023
   #   Date modified: 10/01/2024  

	//auth
	include_once( 'admin_auth.php' );

	//App function
	include_once( 'models/Report.php' );
	include_once( 'models/Admin.php' );

   //Creating Instance
   $report = new Report();
   $admin = new Admin();

	$js_modules = [ 'report' ];

	if ( isset( $_POST['add_btn'] ) ) 
	{
		$rp_type = $_POST['rp_type'];
		$title = $_POST['title'];
		$description = $_POST['description'];

		if( $rp_type && $title && $description ) 
		{
			$dt_01 = [ $admin_id, $rp_type, $title, $description ];

			$add_report = $report->addNew( $dt_01 );

			if ( $add_report ) 
			{
				$msg = $web_app->showAlertMsg( 'success', 'Report Added!' ); 
				$clear = true;	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Report Not Added!' ); 	
			}							
		} 
		else 
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
		
	}

	else if ( isset( $_POST['edit_btn'] ) ) 
	{
		$id = $_POST['report_id'];
		$rp_type = $_POST['edit_rp_type'];
		$title = $_POST['edit_title'];
		$description = $_POST['edit_description'];

		if( $id && $rp_type && $title && $description ) 
		{
			$dt_01 = [ $admin_id, $rp_type, $title, $description, $id ];

			$update_report = $report->updateById( $dt_01 );

			if ( $update_report ) 
			{
				$msg = $web_app->showAlertMsg( 'success', 'Report Updated!' ); 
				$clear = true;	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Report Not Updated!' ); 	
			}							
		} 
		else 
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}		
	}



	$report_arr = $report->getAll( [ ] );

	if ( !$report_arr ) 
	{
		$msg = $web_app->showAlertMsg( 'info', 'Sorry, No Report Record(s) Found.' );
	}
	//Reports interface
	include_once( 'views/reports.php' );
 ?>