<?php 
	#   Author of the script
	#   Name: Ezra Adamu
	#   Email: ezra00100@gmail.com
	#   Date created: 09/10/2023
   #   Date modified: 19/10/2023 

	//auth
	include_once( 'admin_auth.php' );

	$js_modules = [ 'personel' ];

	if ( isset( $_POST['add_btn'] ) ) 
	{
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$service_no = $_POST['service_no'];
		$rank = $_POST['rank'];

		if( $first_name && $last_name && $service_no && $rank ) 
		{
			$get_service_no = $personel->getByServiceNumber( [ $service_no ] );

			if ( !$get_service_no ) 
			{
				$dt_01 = [ $service_no, $first_name, $last_name, $rank ];

				$add_personel = $personel->addNew( $dt_01 );

				if ( $add_personel ) 
				{
					$msg = $web_app->showAlertMsg( 'success', 'Personel Added!' ); 
					$clear = true;	
				} 
				else 
				{
					$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Personel Not Added!' ); 	
				}				
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Service Number Already Exist!' ); 	
			}			
		} 
		else 
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
		
	}

	else if ( isset( $_POST['edit_btn'] ) ) 
	{
		$id = $_POST['personel_id'];
		$first_name = $_POST['e_first_name'];
		$last_name = $_POST['e_last_name'];
		$service_no = $_POST['e_service_no'];
		$rank = $_POST['e_rank'];

		if( $first_name && $last_name && $service_no && $rank ) 
		{
			$dt_01 = [ $first_name, $last_name, $rank, $id ];

			$update_personel = $personel->updateById( $dt_01 );

			if ( $update_personel ) 
			{
				$msg = $web_app->showAlertMsg( 'success', 'Personel Updated!' ); 
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Personel Not Updated!' ); 	
			}							
		} 
		else 
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
		
	}



	$personel_arr = $personel->getAll( [ ] );

	if ( !$personel_arr ) 
	{
		$msg = $web_app->showAlertMsg( 'info', 'Sorry, No Personel Record(s) Found.' );
	}
	//Personels interface
	include_once( 'views/personels.php' );
 ?>