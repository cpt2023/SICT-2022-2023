<?php 
	#   Author of the script
	#   Name: Ezra Adamu
	#   Email: ezra00100@gmail.com
	#   Date created: 09/10/2023
   #   Date modified: 19/10/2023 

	//auth
	include_once( 'admin_auth.php' );

	//App function
	include_once( 'models/Brand.php' );
	include_once( 'models/Personel.php');
   include_once( 'models/Arm.php');

   //Creating Instance
   $personel = new Personel();
   $arm = new Arm();
	$brand = new Brand();

	$js_modules = [ 'arms' ];

	if ( isset( $_POST['add_btn'] ) ) 
	{
		$arm_brand = $_POST['brand'];
		$title = $_POST['title'];
		$stock = $_POST['stock'];

		if( $arm_brand && $title && $stock ) 
		{
			$dt_01 = [ $arm_brand, $title, $stock ];

			$add_arm = $arm->addNew( $dt_01 );

			if ( $add_arm ) 
			{
				$msg = $web_app->showAlertMsg( 'success', 'Arms Added!' ); 
				$clear = true;	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Arms Not Added!' ); 	
			}							
		} 
		else 
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
		
	}

	else if ( isset( $_POST['edit_btn'] ) ) 
	{
		$id = $_POST['arms_id'];
		$arm_brand = $_POST['e_brand'];
		$title = $_POST['e_title'];
		$stock = $_POST['e_stock'];

		if( $arm_brand && $title && $stock ) 
		{
			$dt_01 = [ $arm_brand, $title, $stock, $id ];

			$update_arm = $arm->updateById( $dt_01 );

			if ( $update_arm ) 
			{
				$msg = $web_app->showAlertMsg( 'success', 'Arms Updated!' ); 
				$clear = true;	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Arms Not Updated!' ); 	
			}							
		} 
		else 
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}		
	}



	$arms_arr = $arm->getAll( [ ] );

	$brand_arr = $brand->getAll( [ ] );

	if ( !$arms_arr ) 
	{
		$msg = $web_app->showAlertMsg( 'info', 'Sorry, No Arms Record(s) Found.' );
	}
	//Arms interface
	include_once( 'views/arms.php' );
 ?>