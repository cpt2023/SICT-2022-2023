-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 31, 2024 at 12:44 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arms_inventory_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `service_no` varchar(150) DEFAULT NULL,
  `role` enum('NSA','Defence Minister','Army','Navy','Airforce','Police','Immigration','Customs','Civil Defense','Prison Warders') DEFAULT NULL,
  `pword` varchar(200) DEFAULT NULL,
  `first_name` varchar(200) DEFAULT NULL,
  `last_name` varchar(200) DEFAULT NULL,
  `rank` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `service_no` (`service_no`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `service_no`, `role`, `pword`, `first_name`, `last_name`, `rank`) VALUES
(1, 'NDA001', 'NSA', '$2y$10$DGA1D/oOTSEqUaKAlmdzqO3uZdZSP/gdUXLZ8fpiaq7vdqJZyQBoy', 'ABC', 'DEF', ''),
(3, 'NDA002', 'Defence Minister', '$2y$10$DGA1D/oOTSEqUaKAlmdzqO3uZdZSP/gdUXLZ8fpiaq7vdqJZyQBoy', 'ABC', 'DEF', ''),
(4, 'NDA003', 'Army', '$2y$10$DGA1D/oOTSEqUaKAlmdzqO3uZdZSP/gdUXLZ8fpiaq7vdqJZyQBoy', 'ABC', 'DEF', ''),
(5, 'NDA004', 'Navy', '$2y$10$DGA1D/oOTSEqUaKAlmdzqO3uZdZSP/gdUXLZ8fpiaq7vdqJZyQBoy', 'ABC', 'DEF', ''),
(6, 'NDA005', 'Airforce', '$2y$10$DGA1D/oOTSEqUaKAlmdzqO3uZdZSP/gdUXLZ8fpiaq7vdqJZyQBoy', 'ABC', 'DEF', ''),
(7, 'NDA006', 'Police', '$2y$10$DGA1D/oOTSEqUaKAlmdzqO3uZdZSP/gdUXLZ8fpiaq7vdqJZyQBoy', 'ABC', 'DEF', ''),
(8, 'NDA007', 'Immigration', '$2y$10$DGA1D/oOTSEqUaKAlmdzqO3uZdZSP/gdUXLZ8fpiaq7vdqJZyQBoy', 'ABC', 'DEF', ''),
(9, 'NDA008', 'Customs', '$2y$10$DGA1D/oOTSEqUaKAlmdzqO3uZdZSP/gdUXLZ8fpiaq7vdqJZyQBoy', 'ABC', 'DEF', ''),
(10, 'NDA009', 'Civil Defense', '$2y$10$DGA1D/oOTSEqUaKAlmdzqO3uZdZSP/gdUXLZ8fpiaq7vdqJZyQBoy', 'ABC', 'DEF', ''),
(11, 'NDA0010', 'Prison Warders', '$2y$10$DGA1D/oOTSEqUaKAlmdzqO3uZdZSP/gdUXLZ8fpiaq7vdqJZyQBoy', 'ABC', 'DEF', '');

-- --------------------------------------------------------

--
-- Table structure for table `ammunitions`
--

DROP TABLE IF EXISTS `ammunitions`;
CREATE TABLE IF NOT EXISTS `ammunitions` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `brand_id` int(12) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL,
  `stock` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ammunitions`
--

INSERT INTO `ammunitions` (`id`, `brand_id`, `title`, `stock`) VALUES
(1, 1, 'AK 45', 200);

-- --------------------------------------------------------

--
-- Table structure for table `arms`
--

DROP TABLE IF EXISTS `arms`;
CREATE TABLE IF NOT EXISTS `arms` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `brand_id` int(12) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL,
  `stock` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `arms`
--

INSERT INTO `arms` (`id`, `brand_id`, `title`, `stock`) VALUES
(1, 1, 'AK 45', 20);

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
CREATE TABLE IF NOT EXISTS `brands` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `make` varchar(500) DEFAULT NULL,
  `company` text,
  `country` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `make`, `company`, `country`) VALUES
(1, 'AK', 'AK Coy', 'USA');

-- --------------------------------------------------------

--
-- Table structure for table `personels`
--

DROP TABLE IF EXISTS `personels`;
CREATE TABLE IF NOT EXISTS `personels` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `service_no` varchar(150) DEFAULT NULL,
  `first_name` varchar(200) DEFAULT NULL,
  `last_name` varchar(200) DEFAULT NULL,
  `rank` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `service_no` (`service_no`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `personels`
--

INSERT INTO `personels` (`id`, `service_no`, `first_name`, `last_name`, `rank`) VALUES
(1, 'abc', 'A', 'B', '13');

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
CREATE TABLE IF NOT EXISTS `purchases` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `admin_id` int(12) DEFAULT NULL,
  `updated_by` int(12) DEFAULT NULL,
  `pch_type` enum('Arms','Ammunitions') DEFAULT NULL,
  `title` varchar(500) DEFAULT NULL,
  `description` text,
  `total` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`id`, `admin_id`, `updated_by`, `pch_type`, `title`, `description`, `total`) VALUES
(1, 1, NULL, 'Arms', 'Testing Arms', 'Testing Arms', 100),
(2, 1, NULL, 'Arms', 'Testing Arms', 'Testing Arms', 100);

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
CREATE TABLE IF NOT EXISTS `reports` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `admin_id` int(12) DEFAULT NULL,
  `updated_by` int(12) DEFAULT NULL,
  `rp_type` enum(' Missing','Stolen') DEFAULT NULL,
  `title` varchar(500) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `admin_id` (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`id`, `admin_id`, `updated_by`, `rp_type`, `title`, `description`) VALUES
(1, NULL, NULL, ' Missing', 'Testing', 'ABC');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

DROP TABLE IF EXISTS `requests`;
CREATE TABLE IF NOT EXISTS `requests` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `admin_id` int(12) DEFAULT NULL,
  `updated_by` int(12) DEFAULT NULL,
  `title` varchar(500) DEFAULT NULL,
  `description` text,
  `total` int(12) NOT NULL,
  `status` enum('Approved','Declined') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`id`, `admin_id`, `updated_by`, `title`, `description`, `total`, `status`) VALUES
(1, NULL, 1, 'a', 'Buy 10 Guns', 100, 'Declined');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `personels` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
