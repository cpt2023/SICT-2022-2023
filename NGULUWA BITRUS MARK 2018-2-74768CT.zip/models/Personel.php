<?php
	#   Author of the script
	#   Name: Ezra Adamu
	#   Email: ezra00100@gmail.com
	#   Date created: 20/07/2022
	#   Date modified: 22/09/2023  

	include_once( 'App.php' );
	include_once( 'Encryption.php' );

	class Personel
	{
		//using Namespaces
		use App {
			App::__construct as private __appConst;
		}

		use Encryption;

		protected $table = '';
		const DB_TABLE = 'personels';

		function __construct()
	 	{
			$this->__appConst();
	 		$this->table = self::DB_TABLE;
	 	}

	 	function addNew( array $dt ) 
		{	
			$sql = "INSERT INTO $this->table ( service_no, first_name, last_name, rank ) VALUES ( ?, ?, ?, ? )";
			$res = $this->runQuery( $sql, $dt );
			
			return $res ?? false;	  
		}

		function getAll( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table ORDER BY id DESC";
			$res = $this->fetchAllData( $sql, $dt );

			return $res ?? [];
		}

		function getByServiceNumber( array $dt ) 
		{
			$sql = "SELECT COUNT( id ) AS total FROM $this->table WHERE service_no = ?";
			$res = $this->fetchData( $sql, $dt );

			return $res['total'] ?? 0;
		}

		function getCount( array $dt ) 
		{
			$sql = "SELECT COUNT( id ) AS total FROM $this->table";
			$res = $this->fetchData( $sql, $dt );

			return $res['total'] ?? 0;
		}

		function updateById( array $dt ) 
		{
			$sql = "UPDATE $this->table SET `first_name` = ?, `last_name` = ?, `rank` = ? WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}



	}

?>