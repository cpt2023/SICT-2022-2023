<?php
	#   Author of the script
	#   Name: Ezra Adamu
	#   Email: ezra00100@gmail.com
	#   Date created: 12/12/2023
	#   Date modified: 10/01/2024  

	include_once( 'App.php' );
	include_once( 'Encryption.php' );

	class Report
	{
		//using Namespaces
		use App {
			App::__construct as private __appConst;
		}

		use Encryption;

		protected $table = '';
		const DB_TABLE = 'reports';

		function __construct()
	 	{
			$this->__appConst();
	 		$this->table = self::DB_TABLE;
	 	}

	 	function addNew( array $dt ) 
		{	
			$sql = "INSERT INTO $this->table ( `admin_id`, `rp_type`, `title`, `description` ) VALUES ( ?, ?, ?, ? )";
			$res = $this->runQuery( $sql, $dt );
			
			return $res ?? false;	  
		}

		function getAll( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table ORDER BY id DESC";
			$res = $this->fetchAllData( $sql, $dt );

			return $res ?? [];
		}


		function updateById( array $dt ) 
		{
			$sql = "UPDATE $this->table SET `updated_by` = ?,  `rp_type` = ?, `title` = ?, `description` = ? WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}



	}

?>