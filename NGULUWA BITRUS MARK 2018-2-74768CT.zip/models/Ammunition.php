<?php
	#   Author of the script
	#   Name: Ezra Adamu
	#   Email: ezra00100@gmail.com
	#   Date created: 20/07/2022
	#   Date modified: 22/09/2023  

	include_once( 'App.php' );
	include_once( 'Encryption.php' );

	class Ammunition
	{
		//using Namespaces
		use App {
			App::__construct as private __appConst;
		}

		use Encryption;

		protected $table = '';
		const DB_TABLE = 'ammunitions';

		function __construct()
	 	{
			$this->__appConst();
	 		$this->table = self::DB_TABLE;
	 	}

	 	function addNew( array $dt ) 
		{	
			$sql = "INSERT INTO $this->table ( `brand_id`, `title`, `stock` ) VALUES ( ?, ?, ? )";
			$res = $this->runQuery( $sql, $dt );
			
			return $res ?? false;	  
		}

		function getAll( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table ORDER BY id DESC";
			$res = $this->fetchAllData( $sql, $dt );

			return $res ?? [];
		}

		function getCount( array $dt ) 
		{
			$sql = "SELECT COUNT( id ) AS total FROM $this->table";
			$res = $this->fetchData( $sql, $dt );

			return $res['total'] ?? 0;
		}

		function getStockCount( array $dt ) 
		{
			$sql = "SELECT SUM( stock ) AS total FROM $this->table";
			$res = $this->fetchData( $sql, $dt );

			return $res['total'] ?? 0;
		}

		function updateById( array $dt ) 
		{
			$sql = "UPDATE $this->table SET `brand_id` = ?, `title` = ?, `stock` = ? WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}



	}

?>