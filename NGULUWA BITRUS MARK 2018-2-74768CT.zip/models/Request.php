<?php
	#   Author of the script
	#   Name: Ezra Adamu
	#   Email: ezra00100@gmail.com
	#   Date created: 13/12/2023
	#   Date modified: 10/01/2024   

	include_once( 'App.php' );
	include_once( 'Encryption.php' );

	class Request
	{
		//using Namespaces
		use App {
			App::__construct as private __appConst;
		}

		use Encryption;

		protected $table = '';
		const DB_TABLE = 'requests';

		function __construct()
	 	{
			$this->__appConst();
	 		$this->table = self::DB_TABLE;
	 	}

	 	function addNew( array $dt ) 
		{	
			$sql = "INSERT INTO $this->table ( `admin_id`, `title`, `description`, `total` ) VALUES ( ?, ?, ?, ? )";
			$res = $this->runQuery( $sql, $dt );
			
			return $res ?? false;	  
		}

		function getAll( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table ORDER BY id DESC";
			$res = $this->fetchAllData( $sql, $dt );

			return $res ?? [];
		}


		function updateById( array $dt ) 
		{
			$sql = "UPDATE $this->table SET `updated_by` = ?,  `title` = ?, `description` = ?, `total` = ? WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}

		function updateStatusById( array $dt ) 
		{
			$sql = "UPDATE $this->table SET `updated_by` = ?, `status` = ? WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}
	}

?>