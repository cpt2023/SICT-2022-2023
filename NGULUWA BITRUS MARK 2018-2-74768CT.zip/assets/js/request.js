
$( document ).ready( () => {
   const setSessionAlert = ( data ) => {
      data = JSON.parse( data );
      
      if ( data )
      {
         //alert( data.msg )
         $( '#alert_msg' ).html( data.msg );

      }
   };
   
   $( '.update_status' ).change( ( e ) => {
      const dt_set = e.currentTarget.dataset;

      const request_id = dt_set.id;
      const status = $('#status').val();
      
      makeAjaxCall( '', 'POST', { 'update_status' : true, 'status' : status, 'request_id' : request_id }, true ).
      then( ( data ) => 
         setSessionAlert( data )
      );
   });

});

//set data on edit request modal box
$( document ).on( 'click', '.update_request_btn', ( e ) => {
   const dt_set = e.currentTarget.dataset;
   
   $('#request_id').val( dt_set.request_id );
   $('#edit_total').val( dt_set.total );
   $('#edit_title').val( dt_set.title );
   $('#edit_description').val( dt_set.description );
});
