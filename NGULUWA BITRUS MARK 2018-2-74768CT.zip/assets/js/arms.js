//set data on edit arms modal box
$( document ).on( 'click', '.update_arms_btn', ( e ) => {
	const dt_set = e.currentTarget.dataset;
	
	$('#arms_id').val( dt_set.arms_id );
	$('#e_brand').val( dt_set.brand_id );
	$('#e_title').val( dt_set.title );
	$('#e_stock').val( dt_set.stock );
});