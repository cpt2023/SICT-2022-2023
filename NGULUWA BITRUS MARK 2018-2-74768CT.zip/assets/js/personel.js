//set data on edit personel modal box
$( document ).on( 'click', '.update_personel_btn', ( e ) => {
	const dt_set = e.currentTarget.dataset;
	
	$('#personel_id').val( dt_set.personel_id );
	$('#e_first_name').val( dt_set.first_name );
	$('#e_last_name').val( dt_set.last_name );
	$('#e_service_no').val( dt_set.service_no );
	$('#e_rank').val( dt_set.rank );
});