//set data on edit arms modal box
$( document ).on( 'click', '.update_ammunitions_btn', ( e ) => {
	const dt_set = e.currentTarget.dataset;
	
	$('#ammunitions_id').val( dt_set.ammunitions_id );
	$('#e_brand').val( dt_set.brand_id );
	$('#e_title').val( dt_set.title );
	$('#e_stock').val( dt_set.stock );
});