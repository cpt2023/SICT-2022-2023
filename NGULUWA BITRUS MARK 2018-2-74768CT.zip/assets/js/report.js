//set data on edit report modal box
$( document ).on( 'click', '.update_report_btn', ( e ) => {
	const dt_set = e.currentTarget.dataset;
	
	$('#report_id').val( dt_set.report_id );
	$('#edit_rp_type').val( dt_set.rp_type );
	$('#edit_title').val( dt_set.title );
	$('#edit_description').val( dt_set.description );
});