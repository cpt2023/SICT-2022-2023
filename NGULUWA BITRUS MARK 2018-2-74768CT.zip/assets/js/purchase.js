
$( document ).ready( () => {
   const setSessionAlert = ( data ) => {
      data = JSON.parse( data );
      
      if ( data )
      {
         //alert( data.msg )
         $( '#alert_msg' ).html( data.msg );

      }
   };
});

//set data on edit purchase modal box
$( document ).on( 'click', '.update_purchase_btn', ( e ) => {
   const dt_set = e.currentTarget.dataset;
   
   $('#purchase_id').val( dt_set.purchase_id );
   $('#edit_total').val( dt_set.total );
   $('#edit_title').val( dt_set.title );
   $('#edit_pch_type').val( dt_set.pch_type );
   $('#edit_description').val( dt_set.description );
});
