<?php 

	include_once( 'App.php' );
	include_once( 'Encryption.php' );

	class Patient
	{
		//using Namespaces
		use App {
			App::__construct as private __appConst;
		}

		use Encryption;

		protected $table = '';
		const DB_TABLE = 'patients';

		function __construct()
	 	{
			$this->__appConst();
	 		$this->table = self::DB_TABLE;
	 	}

	 	function addNew( array $dt ) 
		{	
			$sql = "INSERT INTO $this->table ( `first_name`, `last_name`, `gender`, `blood_grp`, `dob`, `phone`, `email`, `address`, `m_status`, `age`, `bp`, `temp`, `pr`, `rr`, `wt`, `ht`, `password` ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";
			$res = $this->runQuery( $sql, $dt );
			
			return $res ?? false;	  
		}

		function getByEmail( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table WHERE email = ?";
			$res = $this->fetchData( $sql, $dt );

			return $res ?? [];
		}

		function getAll( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table ";
			$res = $this->fetchAllData( $sql, $dt );

			return $res ?? [];
		}

		function getFullNameById( array $dt ) 
		{
			$sql = "SELECT first_name, last_name FROM $this->table WHERE id = ? ";
			$res = $this->fetchData( $sql, $dt );

			return $res ?? [];
		}

		function getCount( array $dt ) 
		{
			$sql = "SELECT COUNT( id ) AS total FROM $this->table ";
			$res = $this->fetchData( $sql, $dt );

			return $res['total'] ?? 0;
		}

		function updateById( array $dt ) 
		{
			$sql = "UPDATE $this->table SET `password`= ? WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}

		function deleteById( array $dt ) 
		{
			$sql = "DELETE FROM $this->table WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}

	}

?>