<?php

	include_once( 'App.php' );
	include_once( 'Encryption.php' );

	class Payment
	{
		//using Namespaces
		use App {
			App::__construct as private __appConst;
		}

		use Encryption;

		protected $table = '';
		const DB_TABLE = 'payments';

		protected $table_appointment = '';
		const DB_TABLE_APPOINTMENT = 'appointments';

		protected $table_service = '';
		const DB_TABLE_SERVICE = 'services';

		protected $table_patient = '';
		const DB_TABLE_PATIENT = 'patients';

		function __construct()
	 	{
			$this->__appConst();
	 		$this->table = self::DB_TABLE;
	 		$this->table_appointment = self::DB_TABLE_APPOINTMENT;
	 		$this->table_service = self::DB_TABLE_SERVICE;
	 		$this->table_patient = self::DB_TABLE_PATIENT;
	 	}

		function getAll( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table py INNER JOIN $this->table_appointment appt INNER JOIN $this->table_service serv INNER JOIN $this->table_patient pat ON py.appointment_id = appt.id AND appt.service = serv.service AND py.patient_id = pat.id ORDER BY py.id DESC";
			$res = $this->fetchAllData( $sql, $dt );

			return $res ?? [];
		}

		function getBottomTransaction( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table py INNER JOIN $this->table_appointment appt INNER JOIN $this->table_service serv INNER JOIN $this->table_patient pat ON py.appointment_id = appt.id AND appt.service = serv.service AND py.patient_id = pat.id ORDER BY py.id DESC LIMIT 10";
			$res = $this->fetchAllData( $sql, $dt );

			return $res ?? [];
		}

		function getTotalSales( array $dt ) 
		{
			$sql = "SELECT SUM( fees ) AS total  FROM $this->table py INNER JOIN $this->table_appointment appt INNER JOIN $this->table_service serv ON py.appointment_id = appt.id AND appt.service = serv.service";
			$res = $this->fetchData( $sql, $dt );

			return $res['total'] ?? 0;
		}

		function getPaymentStatusByPatientId( array $dt ) 
		{
			$sql = "SELECT status  FROM $this->table WHERE appointment_id = ?";
			$res = $this->fetchData( $sql, $dt );

			return $res['status'] ?? 'Unpaid';
		}


	}

?>

