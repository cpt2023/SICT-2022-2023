<?php

	include_once( 'App.php' );
	include_once( 'Encryption.php' );

	class Admin
	{
		//using Namespaces
		use App {
			App::__construct as private __appConst;
		}

		use Encryption;

		protected $table = '';
		const DB_TABLE = 'admins';

		function __construct()
	 	{
			$this->__appConst();
	 		$this->table = self::DB_TABLE;
	 	}


		function getLoggedAdmin()
		{
			return $_COOKIE[ APP_SESS ] ?? 0;
		}

		function getLogin( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table WHERE email = ?";
			$res = $this->fetchData( $sql, $dt );

			return $res ?? [];
		}

		function updateById( array $dt ) 
		{
			$sql = "UPDATE $this->table SET `password`= ? WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}

	}

?>