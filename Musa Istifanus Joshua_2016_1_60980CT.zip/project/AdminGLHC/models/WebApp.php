<?php

	//include_once( 'App.php' );

	class WebApp
	{
		// use App;

		function fixUrl( $page ) 
		{
			return str_replace( '-', '_', $page );
		}

		function showAlert( $msg , $top = false )
		{
			if ( $top ) 
			{
		   	$mt = 'mt-2';

	        if ( isset( $_SESSION['msg'] ) ) 
	        {
	        		$msg = $_SESSION['msg'];
	         	unset( $_SESSION['msg'] );
	        }
  
	        return "<div id='main-msg' class='$mt'> $msg </div>";
			}
			else if ( isset( $msg ) ) 
		   {
            return $msg;
			}
		}
		
		function showAlertMsg( $type, $msg )
		{
			$icon_type  = '';

			if ( $type == 'success' ) 
			{
				$icon_type = "alert-success";
			} 
			else if( $type == 'info' ) 
			{
				$icon_type = "alert-info";
			}
			else if( $type == 'danger' ) 
			{
				$icon_type = "alert-danger";
			}

			$type = "alert-$type";
			$alert = "<div class=\"alert $icon_type\">
                    <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a>
                        $msg
                    </div>";

		   return $alert;
		}
		
		// persist user input
		function persistData( $data, $update = false, $clear = false ) 
		{
			$dt = '';

			if ( $clear ) 
			{
				return $dt;
			}
			
			if ( isset( $_POST[ $data ] ) ) 
			{
				$dt = $_POST[ $data ];
			}
			else 
			{
				if ( $update ) 
				{
					$dt = $data;
				}
			}

			return $dt;
		}

		function createOptions( array $data_arr, $sel_id )
      {
      	$options = ''; 

      	foreach ( $data_arr as $dt ) 
         {
				$sel = $sel_id == $dt ? 'selected' : '';
				$options .= "<option value='$dt' $sel >$dt</option>";
         }

         return $options;
      }

      function createOptions_2( array $data_arr, $sel_id )
      {
      	$options = ''; 

      	foreach ( $data_arr as $key => $dt ) 
         {
            $sel = $sel_id == $key ? 'selected' : '';
				$options .= "<option value='$key' $sel >$dt</option>";
         }

         return $options;
      }

		function fullName( array $data )
		{
			return $data[ 'first_name' ] . ' ' . $data[ 'last_name' ];
		}

		function genNos( $max_no = 10, $sel_id = 0 )
		{
			$options = '';

			for ( $i = 1; $i <= $max_no; $i++ ) 
			{ 
				$sel = $sel_id == $i ? 'selected' : '';
				$options .= "<option value='$i' $sel> $i </option>";
			}

			return $options;
		}


		function getCard( $card_title, $value, $icon_name, $icon_type )
		{
			return "<div class='col-md-6'>
					<div class='card info-card revenue-card'>
						<div class='card-body'>
							<h5 class='card-title'>$card_title</span></h5>

							<div class='d-flex align-items-center'>
								<div class='card-icon rounded-circle d-flex align-items-center justify-content-center bg-$icon_type text-white'>
									<i class='$icon_name'></i>
								</div>
								<div class='ps-2'>
								  <h6 class='fs-3'>$value</h6>
								</div>
						  	</div>
						</div>
					</div>
				</div>";
		}
	}
?>