<?php 

	include_once( 'App.php' );
	include_once( 'Encryption.php' );

	class Appointment
	{
		//using Namespaces
		use App {
			App::__construct as private __appConst;
		}

		use Encryption;

		protected $table = '';
		const DB_TABLE = 'appointments';

		function __construct()
	 	{
			$this->__appConst();
	 		$this->table = self::DB_TABLE;
	 	}

		function getAll( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table ORDER BY id DESC ";
			$res = $this->fetchAllData( $sql, $dt );

			return $res ?? [];
		}

		function getByDateTime( array $dt ) 
		{
			$sql = "SELECT COUNT( id ) AS total FROM $this->table WHERE date = ? AND time = ? AND status = ?  ";
			$res = $this->fetchData( $sql, $dt );

			return $res['total'] ?? [];
		}

		function getCount( array $dt ) 
		{
			$sql = "SELECT COUNT( id ) AS total FROM $this->table ";
			$res = $this->fetchData( $sql, $dt );

			return $res['total'] ?? 0;
		}

		function updateById( array $dt ) 
		{
			$sql = "UPDATE $this->table SET `password`= ? WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}

		function updateStatusById( array $dt ) 
		{
			$sql = "UPDATE $this->table SET `status`= ?, `comment`= ? WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}

		function updateSessionById( array $dt ) 
		{
			$sql = "UPDATE $this->table SET `session`= ? WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}

		function getAllBySessionState( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table WHERE ( session = ? OR session = ? ) AND status = ? ";
			$res = $this->fetchAllData( $sql, $dt );

			return $res ?? [];
		}


	}

?>