<!-- Page Heading -->
<div class="row">
  <div class="col-lg-12">
    <h1 class="page-header">
      Services
    </h1>
    <ol class="breadcrumb">
      <li>
        <i class="fa fa-dashboard"></i>  <a href="dashboard">Dashboard</a>
      </li>
      <li class="active">
        <i class="fa fa-table"></i>Services
      </li>
    </ol>
  </div>
</div>
<!-- /.row -->

<div class="row">
  <div class="col-lg-12">
    <?= $web_app->showAlert( $msg ) ?>
    <button class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#newServices"><i class="fa fa-fw fa-plus"></i> Add New Services</button>
    <div class="panel panel-default">
      <div class="panel-heading"><h4 class="panel-title text-center">List of Services</h4> </div>
      <div class="panel-body">
        <div class="table-responsive">
          <table class="table table-bordered table-hover">
            <thead>
              <tr>
                <th>S/N</th>
                <th>Service</th>
                <th>Fees</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
                if ( $services_arr ) 
                {
                  $sn = 1;
                  foreach ( $services_arr as $service_dt ) 
                  {
                    $id = $service_dt['id'];
              ?>
                  <tr>
                    <td><?= $sn ?></td>
                    <td><?= $service_dt['service'] ?></td>
                    <td><?= 'N'.$service_dt['fees'] ?></td>
                    <td>
                      <button class="btn btn-primary service_edit_btn" data-bs-toggle="modal" data-id="<?= $id ?>" data-service="<?= $service_dt['service'] ?>" data-fee="<?= $service_dt['fees'] ?>" data-bs-target="#editServices"><i class="fa fa-fw fa-pencil"></i> Edit </button>

                      <button class="btn btn-danger service_del_btn" data-bs-toggle="modal" data-id="<?= $id ?>" data-ques="do you really want to delete this service ?" data-bs-target="#delServices"><i class="fa fa-fw fa-trash"></i> Delete </button>
                    </td>
                  </tr>

              <?php
                    $sn++;
                  }
                }
              ?>
              </tbody>
          </table>
        </div>
      </div>
  </div>
</div>

<!-- Start Add Service Modal-->
<div class="modal fade mt-5" id="newServices" tabindex="-1">
  <div class="modal-dialog modal-lg mt-5">
    <div class="modal-content">
      <div class="modal-header"> <h3></h3></div>
      <div class="modal-body">
        <h3 class="modal-title"><strong>Add Service</strong></h3>
        <hr>
        <form method="POST">
          <div class="form-group col-md-6">
            <label class="control-label" for="service">Service <span class="text-danger">*</span></label>
            <input class="form-control" id="service" name="service" autofocus required type="text" value="<?= $web_app->persistData( 'service', false, $clear ) ?>">
          </div>
          <div class="form-group col-md-6">
            <label class="control-label" for="fees">Fee Charge <span class="text-danger">*</span></label>
            <input class="form-control" id="fees" name="fees" required type="text" value="<?= $web_app->persistData( 'fees', false, $clear ) ?>">
          </div>

          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" name="service_btn">Save</button>
            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
          </div>
                    
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Start Edit Service Modal-->
<div class="modal fade mt-5" id="editServices" tabindex="-1">
  <div class="modal-dialog modal-lg mt-5">
    <div class="modal-content">
      <div class="modal-header"> <h3></h3></div>
      <form method="POST">
        <div class="modal-body">
          <h3 class="modal-title"><strong>Edit Service</strong></h3>
          <hr>
          <input type="hidden" name="service_id" id="service_id" >
          <div class="form-group col-md-6">
            <label class="control-label" for="e_service">Service <span class="text-danger">*</span></label>
            <input class="form-control" id="e_service" name="e_service" autofocus required type="text">
          </div>
          <div class="form-group col-md-6">
            <label class="control-label" for="e_fees">Fee Charge <span class="text-danger">*</span></label>
            <input class="form-control" id="e_fees" name="e_fees" required type="text" >
          </div>      
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary" name="e_service_btn">Edit</button>
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Start Delete Service Modal-->
<div class="modal fade" id="delServices" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header"> <h3></h3></div>
      <div class="modal-body">
        <h4 class="modal-title text-capitalize py-2" id="del_title"></h4>
        <form method="POST">
          <input type="hidden" name="del_service_id" id="del_service_id" >
          <div class="modal-footer">
            <button type="submit" class="btn btn-danger" name="del_btn">Delete</button>
            <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Cancel</button>
          </div>
                    
        </form>
      </div>
    </div>
  </div>
</div>
