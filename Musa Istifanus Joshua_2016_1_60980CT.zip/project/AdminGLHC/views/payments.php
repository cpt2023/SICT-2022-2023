<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Transactions
        </h1>
        <ol class="breadcrumb">
            <li>
                <i class="fa fa-dashboard"></i>  <a href="dashboard">Dashboard</a>
            </li>
            <li class="active">
                <i class="fa fa-table"></i> Transactions
            </li>
        </ol>
    </div>
</div>

<div class="col-lg-12">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><i class="fa fa-money fa-fw"></i> Transactions Panel</h3>
        </div>
        <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover table-striped">
                    <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Names of Patient</th>
                            <th>Gender</th>
                            <th>Service</th>
                            <th>Title</th>
                            <th>Schedule</th>
                            <th>Amount Paid</th>
                            <th>Blood Group</th>
                            <th>Phone Number</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if ( $payments_arr ) 
                            {
                                $sn = 1;
                                foreach ( $payments_arr as $payment_dt ) 
                                {
                        ?>
                            <tr>
                               <td><?= $sn ?></td> 
                               <td><?= $payment_dt['first_name'].' '.$payment_dt['last_name'] ?></td> 
                               <td><?= $payment_dt['gender'] ?></td> 
                               <td><?= $payment_dt['service'] ?></td> 
                               <td><?= $payment_dt['title'] ?></td> 
                               <td><?= $payment_dt['date'].' '.$payment_dt['time'] ?></td> 
                               <td><?= $payment_dt['fees'] ?></td> 
                               <td><?= $payment_dt['blood_grp'] ?></td> 
                               <td><?= $payment_dt['phone'] ?></td> 
                            </tr>

                        <?php
                                    $sn++;
                                }
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
