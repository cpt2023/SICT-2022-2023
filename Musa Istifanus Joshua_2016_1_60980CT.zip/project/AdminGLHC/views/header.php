<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <meta name="description" content="">
  <meta name="author" content="">
  <title>Primary Health Care - Admin</title>
  <!-- Bootstrap core CSS -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icon.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template -->
  <link href="assets/css/sb-admin.css" rel="stylesheet">
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">

  <!-- Morris Charts CSS -->
  <link href="assets/css/plugins/morris.css" rel="stylesheet">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
  <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>-->


</head>
<?php 

if ( !in_array( $page, $header_blacklist_arr ) ) {
  include_once( 'models/Appointment.php' );
  include_once( 'models/Payment.php' );
  $h_appt = new Appointment();
  $h_pay = new Payment();
?>
<body>
  <div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header mr-auto" style="mr-auto">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="dashboard">Primary Health Care</a>
      </div>
      <!-- Top Menu Items -->
      <ul class="nav navbar-right top-nav">

        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?= $_SESSION['ad_name'] ?> <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li class="divider"></li>
            <li>
              <a data-bs-toggle="modal" data-bs-target="#modalSetting"><i class="fa fa-fw fa-cog"></i> Setting</a>
            </li>

            <li class="divider"></li>
            <li>
              <a href="logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
            </li>
          </ul>
        </li>
      </ul>
      <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
      <div class="collapse navbar-collapse navbar-ex1-collapse" >
        <ul class="nav navbar-nav side-nav" style="margin-left: -230px;">
          <li class="active mt-3">
            <a href="dashboard"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
          </li>
          <li>
            <a href="javascript:;" data-toggle="collapse" data-target="#patient"><i class="fa fa-fw fa-arrows-v"></i> Patient <i class="fa fa-fw fa-caret-down"></i></a>
            <ul id="patient" class="collapse">
              <li>
                <a href="appointments">Appointment</a>
              </li>
              <li>
                <a href="patient">Patient List</a>
              </li>
            </ul>
          </li>
          <li>
            <a href="javascript:;" data-toggle="collapse" data-target="#services"><i class="fa fa-fw fa-arrows-v"></i> Services <i class="fa fa-fw fa-caret-down"></i></a>
            <ul id="services" class="collapse">
                <li>
                  <a href="main_services">Services</a>
                </li>
            </ul>
          </li>
          <li>
            <a href="javascript:;" data-toggle="collapse" data-target="#medicine"><i class="fa fa-fw fa-arrows-v"></i> Medicine <i class="fa fa-fw fa-caret-down"></i></a>
            <ul id="medicine" class="collapse">
              <li>
                <a href="medicine">Medicine List</a>
              </li>
            </ul>
          </li>
          <li>
            <a href="javascript:;" data-toggle="collapse" data-target="#prescritpion"><i class="fa fa-fw fa-arrows-v"></i> Prescription <i class="fa fa-fw fa-caret-down"></i></a>
            <ul id="prescritpion" class="collapse">
              <li>
                <a href="prescription">Prescription List</a>
              </li>
            </ul>
          </li>

        </ul>
      </div>
      <!-- /.navbar-collapse -->
    </nav>
    <div id="page-wrapper">

      <div class="container-fluid mt-5">


<?php
      $running_appt = $h_appt->getAllBySessionState( [ 'ON', 'Start', 'Accepted' ] );

      foreach ( $running_appt as $running_dt ) 
      {
        $id = $running_dt['id'];
        //schedule date
        $db_date = $running_dt['date'];

        //schedule year, month and day
        $db_year = substr( $db_date, 0, 4 );
        $db_month = substr( $db_date, 5, 2 );
        $db_day = substr( $db_date, 8, 2 );

        //current year, month and day
        $current_year = date('Y');
        $current_month = date('m');
        $current_day = date('d');

        //schedule time
        $db_time = $running_dt['time'];

        //schedule hour, minute, and  meridian
        $db_hour = substr( $db_time, 0, 2 );
        $db_minute = substr( $db_time, 3, 2 );
        $db_meridian = substr( $db_time, 5, 2 );

        //current hour, minute and meridian
        date_default_timezone_set( 'AFRICA/LAGOS');
        $current_hour = date('H');
        $current_minute = date('i');
        $current_meridain = date('A');
        $payment_status = $h_pay->getPaymentStatusByPatientId( [ $id ] );

        if( ( $current_year == $db_year ) && ( $current_month == $db_month ) && ( $current_day == $db_day ) ) 
        {
          if ( ( ( $current_meridain == $db_meridian ) == 'AM' ) || ( ( $current_meridain == $db_meridian ) == 'PM' ) ) 
          {
            $appt_duration = $db_minute + 15;
            if ( $appt_duration <= 59 ) 
            {
              if ( $current_hour == $db_hour ) 
              {
                if ( $current_minute >= $db_minute && $current_minute <= $appt_duration ) 
                {
                  if( $payment_status == 'Paid' )
                  {
                    $h_appt->updateSessionById( [ 'Start', $id ] );
                  }
                  else
                  {
                    $h_appt->updateSessionById( [ 'Expired', $id ] );
                  }
                }
                elseif ( $current_minute > $appt_duration ) 
                {
                  $h_appt->updateSessionById( [ 'Expired', $id ] );
                }                
              }
              elseif ( $current_hour > $db_hour ) 
              {
                $h_appt->updateSessionById( [ 'Expired', $id ] );
              }
            }
            else
            {
              $appt_duration -= 60;
              $db_hour += 1;
              if ( $current_hour < $db_hour || $current_hour == $db_hour ) 
              {
                if ( $current_minute >= $db_minute || $current_minute <= $appt_duration ) 
                {
                  if( $payment_status == 'Paid' )
                  {
                    $h_appt->updateSessionById( [ 'Start', $id ] );
                  }
                  else
                  {
                    $h_appt->updateSessionById( [ 'Expired', $id ] );
                  }
                }
                elseif ( $current_minute > $appt_duration && $current_hour == $db_hour ) 
                {
                  $h_appt->updateSessionById( [ 'Expired', $id ] );
                }                
              }
            }
          }
          else
          {
            $h_appt->updateSessionById( [ 'Expired', $id ] );
          }
        }
        elseif( ( $current_year > $db_year ) || ( $current_month > $db_month && $current_year > $db_year ) || ( $current_day > $db_day  && $current_year > $db_year ) ) 
        {
          $h_appt->updateSessionById( [ 'Expired', $id ] );
        }
      }
      
   }

   if ( isset( $_POST['btnSave'] ) ) 
   {
      $pword = $_POST['txtPassword'];
      $re_pword = $_POST['txtRetypePassword'];

      if ( $pword && $re_pword ) 
      {
         if ( $pword == $re_pword ) 
         {
            $pword_hash = password_hash( $pword, PASSWORD_DEFAULT);
            $dt_01 = [ $pword_hash, $_SESSION[ APP_SESS ] ];

            $update_pword = $admin->updateById( $dt_01 );

            if ( $update_pword ) 
            {
               $msg_2 = $web_app->showAlertMsg( 'success', 'Password Updated.' );   
            } 
            else 
            {
               $msg_2 = $web_app->showAlertMsg( 'danger', 'Sorry, Password Not Updated.' );   
            }
         } 
         else 
         {
            $msg_2 = $web_app->showAlertMsg( 'danger', 'Sorry, Passwords dooes not match.' );   
         }         
      } 
      else 
      {
        $msg_2 = $web_app->showAlertMsg( 'info', 'Please, Required Fields.' );   
      }      
   }
?>
<div class="mt-5">
<?= $web_app->showAlert( $msg_2 ) ?>
</div>

