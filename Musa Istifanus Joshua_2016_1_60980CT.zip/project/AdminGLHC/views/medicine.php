<!-- Page Heading -->
<div class="row">
  <div class="col-lg-12">
    <h1 class="page-header">
      Medicines
    </h1>
    <ol class="breadcrumb">
      <li>
        <i class="fa fa-dashboard"></i>  <a href="dashboard">Dashboard</a>
      </li>
      <li class="active">
        <i class="fa fa-table"></i>Medicines
      </li>
    </ol>
  </div>
</div>
<!-- /.row -->

<div class="row">

  <div class="col-lg-12">
    <?= $web_app->showAlert( $msg ) ?>
    <button class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#newMedicine"><i class="fa fa-fw fa-plus"></i> Add New Medicine</button>
    <div class="panel panel-default">
      <div class="panel-heading"><h4 class="panel-title text-center">List of Medicines</h4> </div>
      <div class="panel-body">
        <div class="table-responsive">
          <table class="table table-bordered table-hover">
            <thead>
              <tr>
                <th>S/N</th>
                <th>Category</th>
                <th>Medicine</th>
                <th>Price</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
            <?php
              if ( $meds_arr ) 
              {
                $sn = 1;
                foreach ( $meds_arr as $med_dt ) 
                {
                  $id = $med_dt['id'];
            ?>
                <tr>
                  <td><?= $sn ?></td>
                  <td><?= $med_dt['category'] ?></td>
                  <td><?= $med_dt['medicine'] ?></td>
                  <td><?= 'N'.$med_dt['price'] ?></td>
                  <td>
                    <button class="btn btn-primary medicine_edit_btn" data-bs-toggle="modal" data-id="<?= $id ?>" data-category="<?= $med_dt['category'] ?>" data-medicine="<?= $med_dt['medicine'] ?>" data-price="<?= $med_dt['price'] ?>" data-bs-target="#editMedicine"><i class="fa fa-fw fa-pencil"></i> Edit </button>

                    <button class="btn btn-danger med_del_btn" data-bs-toggle="modal" data-id="<?= $id ?>" data-ques="do you reall want to delete this medicine ?" data-bs-target="#delMedicine"><i class="fa fa-fw fa-trash"></i> Delete </button>
                  </td>
                </tr>

              <?php
                    $sn++;
                  }
                }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

</div>

<!-- Start Add Medicine Modal-->
<div class="modal fade mt-5" id="newMedicine" tabindex="-1">
  <div class="modal-dialog modal-lg mt-5">
    <div class="modal-content">
      <div class="modal-header"> <h3></h3></div>
      <form method="POST">
        <div class="modal-body">
          <h3 class="modal-title"><strong>Add Medicine</strong></h3>
          <hr>
          <div class="form-group col-md-6">
            <label class="control-label" for="category">Category <span class="text-danger">*</span></label>
            <input class="form-control" id="category" name="category" autofocus required type="text" value="<?= $web_app->persistData( 'category', false, $clear ) ?>">
          </div>
          <div class="form-group col-md-6">
            <label class="control-label" for="medicine">Medicine <span class="text-danger">*</span></label>
            <input class="form-control" id="medicine" name="medicine" required type="text" value="<?= $web_app->persistData( 'medicine', false, $clear ) ?>">
          </div>
          <div class="form-group col-md-6">
            <label class="control-label" for="price">Price <span class="text-danger">*</span></label>
            <input class="form-control" id="price" name="price" required type="text" value="<?= $web_app->persistData( 'price', false, $clear ) ?>">
          </div>
        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-primary" name="med_btn">Save</button>
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>           
        </div>
                      
      </form>
    </div>
  </div>
</div>
<!-- End Add Medicine Modal-->

<!-- Start Edit Medicine Modal-->
<div class="modal fade mt-5" id="editMedicine" tabindex="-1">
   <div class="modal-dialog modal-lg mt-5">
      <div class="modal-content">
         <div class="modal-header"> <h3></h3></div>
         <div class="modal-body">
            <h3 class="modal-title"><strong>Edit Medicine</strong></h3>
            <hr>
            <form method="POST">
                <input type="hidden" name="med_id" id="med_id">
                <div class="form-group col-md-6">
                    <label class="control-label" for="e_category">Category <span class="text-danger">*</span></label>
                    <input class="form-control" id="e_category" name="e_category" autofocus required type="text" value="<?= $web_app->persistData( 'category', false, $clear ) ?>">
                </div>
                <div class="form-group col-md-6">
                    <label class="control-label" for="e_medicine">Medicine <span class="text-danger">*</span></label>
                    <input class="form-control" id="e_medicine" name="e_medicine" required type="text" value="<?= $web_app->persistData( 'medicine', false, $clear ) ?>">
                </div>
                <div class="form-group col-md-6">
                    <label class="control-label" for="e_price">Price <span class="text-danger">*</span></label>
                    <input class="form-control" id="e_price" name="e_price" required type="text" value="<?= $web_app->persistData( 'price', false, $clear ) ?>">
                </div>

              <div class="modal-footer">
                  <button type="submit" class="btn btn-primary" name="e_med_btn">Edit</button>
                  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>           
              </div>
                        
            </form>
         </div>
      </div>
   </div>
</div>
<!-- End Edit Medicine Modal-->

<!-- Start Delete Medicine Modal-->
<div class="modal fade" id="delMedicine" tabindex="-1">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header"> <h3></h3></div>
         <div class="modal-body">
            <h4 class="modal-title text-capitalize py-2" id="del_title"></h4>
            <form method="POST">
                <input type="hidden" name="del_med_id" id="del_med_id" >
              <div class="modal-footer">
                  <button type="submit" class="btn btn-danger" name="del_btn">Delete</button>
                  <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Cancel</button>
              </div>
                        
            </form>
         </div>
      </div>
   </div>
</div>