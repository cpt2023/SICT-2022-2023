<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Dashboard <small>Statistics Overview</small>
        </h1>
        <ol class="breadcrumb">
            <li class="active">
                <i class="fa fa-dashboard"></i> Dashboard
            </li>
        </ol>
    </div>
</div>
<!-- /.row -->

<div class="row">
    <div class="col-lg-12">
        <div class="alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <i class="fa fa-info-circle"></i>  This dashboard analyses everything that is going on the health center
        </div>
    </div>
</div>
<!-- /.row -->

<div class="row">
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-comments fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge">
                            <?= $total_pat ?>
                        </div>
                        <div>Patient!</div>
                    </div>
                </div>
            </div>
            <a href="patient">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-green">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-tasks fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?= $total_appointment ?></div>
                        <div>Appointment!</div>
                    </div>
                </div>
            </div>
            <a href="appointments">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-yellow">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-shopping-cart fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"> <?= $total_services ?>
                        </div>
                        <div>Services!</div>
                    </div>
                </div>
            </div>
            <a href="main_services">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-red">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa- fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge">
                            <?= 'N'. number_format( $total_sales ) ?>
                        </div>
                        <div>Amount generated!</div>
                    </div>
                </div>
            </div>
            <a href="payments">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
</div>
<!-- /.row -->

<div class="col-lg-12">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><i class="fa fa-money fa-fw"></i> Transactions Panel</h3>
        </div>
        <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover table-striped">
                    <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Names of Patient</th>
                            <th>Gender</th>
                            <th>Service</th>
                            <th>Title</th>
                            <th>Schedule</th>
                            <th>Amount Paid</th>
                            <th>Blood Group</th>
                            <th>Phone Number</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if ( $payments_arr ) 
                            {
                                $sn = 1;
                                foreach ( $payments_arr as $payment_dt ) 
                                {
                        ?>
                            <tr>
                               <td><?= $sn ?></td> 
                               <td><?= $payment_dt['first_name'].' '.$payment_dt['last_name'] ?></td> 
                               <td><?= $payment_dt['gender'] ?></td> 
                               <td><?= $payment_dt['service'] ?></td> 
                               <td><?= $payment_dt['title'] ?></td> 
                               <td><?= $payment_dt['date'].' '.$payment_dt['time'] ?></td> 
                               <td><?= $payment_dt['fees'] ?></td> 
                               <td><?= $payment_dt['blood_grp'] ?></td> 
                               <td><?= $payment_dt['phone'] ?></td> 
                            </tr>

                        <?php
                                    $sn++;
                                }
                            }
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="text-right">
                <a href="payments">View All Transactions <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>
</div>
