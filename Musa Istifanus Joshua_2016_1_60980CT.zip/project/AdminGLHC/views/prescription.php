<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Prescriptions
        </h1>
        <ol class="breadcrumb">
            <li>
                <i class="fa fa-dashboard"></i>  <a href="dashboard">Dashboard</a>
            </li>
            <li class="active">
                <i class="fa fa-table"></i>Prescriptions
            </li>
        </ol>
    </div>
</div>
<!-- /.row -->

<div class="row">

    <div class="col-lg-12">
        <?= $web_app->showAlert( $msg ) ?>
        <button class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#newPrescription"><i class="fa fa-fw fa-plus"></i> Add New Prescription</button>
        <div class="panel panel-default">
            <div class="panel-heading"><h4 class="panel-title text-center">Prescription List</h4> </div>
            <div class="panel-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                <tr>
                    <th>S/N</th>
                    <th>Prescription Title</th>
                    <th>Category</th>
                    <th>Service</th>
                    <th>Medicine</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    if ( $prescription_arr ) 
                    {
                        $sn = 1;
                        foreach ( $prescription_arr as $prescription_dt ) 
                        {
                            $id = $prescription_dt['id'];
                ?>
                    <tr>
                        <td><?= $sn ?></td>
                        <td><?= $prescription_dt['title'] ?></td>
                        <td><?= $prescription_dt['category'] ?></td>
                        <td><?= $prescription_dt['service'] ?></td>
                        <td><?= $prescription_dt['medicine'] ?></td>
                        <td>
                            <button class="btn btn-primary pres_edit_btn" data-bs-toggle="modal" data-id="<?= $id ?>" data-title="<?= $prescription_dt['title'] ?>" data-category="<?= $prescription_dt['category'] ?>" data-service="<?= $prescription_dt['service'] ?>" data-medicine="<?= $prescription_dt['medicine'] ?>"   data-bs-target="#editPrescription"><i class="fa fa-fw fa-pencil"></i> Edit </button>

                            <button class="btn btn-danger pres_del_btn" data-bs-toggle="modal" data-id="<?= $id ?>" data-ques="do you really want to delete this prescription ?" data-bs-target="#delPrescription"><i class="fa fa-fw fa-trash"></i> Delete </button>
                        </td>
                    </tr>

                <?php
                            $sn++;
                        }
                    }
                ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<!-- Start Add Prescription Modal-->
<div class="modal fade mt-5" id="newPrescription" tabindex="-1">
   <div class="modal-dialog modal-lg mt-5">
      <div class="modal-content">
         <div class="modal-header"> <h3></h3></div>
         <div class="modal-body">
            <h3 class="modal-title"><strong>Add Prescription</strong></h3>
            <hr>
            <form method="POST">

                <div class="form-group col-md-6">
                    <label class="control-label" for="title">Prescription Title <span class="text-danger">*</span></label>
                    <input class="form-control" id="title" name="title" autofocus required type="text" value="<?= $web_app->persistData( 'title', false, $clear ) ?>">
                </div>
                <div class="form-group col-md-6">
                    <label class="control-label" for="service">Service <span class="text-danger">*</span></label>
                    <select name="service" id="service" class="form-control" style="height: 40px" required>
                      <option>Select Service</option>
                      <?= $serv->loadServices( $service_arr, $web_app->persistData( 'service', false, $clear ) ) ?>
                    </select>                    
                </div>
                <div class="form-group col-md-6">
                    <label class="control-label" for="category">Medicine Category <span class="text-danger">*</span></label>
                    <select name="category" id="category" class="form-control" style="height: 40px" required>
                      <option>Select Medicine Category</option>
                      <?= $med->loadMed( $med_arr, $web_app->persistData( 'category', false, $clear ), 'category' ) ?>
                    </select>                    
                </div>
                <div class="form-group col-md-6">
                    <label class="control-label" for="medicine">Medicine <span class="text-danger">*</span></label>
                    <select name="medicine" id="medicine" class="form-control" style="height: 40px" required>
                      <option>Select Medicine</option>
                      <?= $med->loadMed( $med_arr, $web_app->persistData( 'medicine', false, $clear ), 'medicine' ) ?>
                    </select>                    
                </div>

              <div class="modal-footer">
                  <button type="submit" class="btn btn-primary" name="presc_btn">Save</button>
                  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
              </div>
                        
            </form>
         </div>
      </div>
   </div>
</div>

<!-- Start Edit Precription Modal-->
<div class="modal fade mt-5" id="editPrescription" tabindex="-1">
   <div class="modal-dialog modal-lg mt-5">
      <div class="modal-content">
         <div class="modal-header"> <h3></h3></div>
         <div class="modal-body">
            <h3 class="modal-title"><strong>Edit Prescription</strong></h3>
            <hr>
            <form method="POST">
                <input type="hidden" name="presc_id" id="presc_id">
                <div class="form-group col-md-6">
                    <label class="control-label" for="e_title">Prescription Title <span class="text-danger">*</span></label>
                    <input class="form-control" id="e_title" name="e_title" autofocus required type="text" value="<?= $web_app->persistData( 'e_title', false, $clear ) ?>">
                </div>
                <div class="form-group col-md-6">
                    <label class="control-label" for="e_service">Service <span class="text-danger">*</span></label>
                    <select name="e_service" id="e_service" class="form-control" style="height: 40px" required>
                      <option>Select Service</option>
                      <?= $serv->loadServices( $service_arr, $web_app->persistData( 'e_service', false, $clear ) ) ?>
                    </select>                    
                </div>
                <div class="form-group col-md-6">
                    <label class="control-label" for="e_category">Medicine Category <span class="text-danger">*</span></label>
                    <select name="e_category" id="e_category" class="form-control" style="height: 40px" required>
                      <option>Select Medicine Category</option>
                      <?= $med->loadMed( $med_arr, $web_app->persistData( 'e_category', false, $clear ), 'category' ) ?>
                    </select>                    
                </div>
                <div class="form-group col-md-6">
                    <label class="control-label" for="e_medicine">Medicine <span class="text-danger">*</span></label>
                    <select name="e_medicine" id="e_medicine" class="form-control" style="height: 40px" required>
                      <option>Select Medicine</option>
                      <?= $med->loadMed( $med_arr, $web_app->persistData( 'e_medicine', false, $clear ), 'medicine' ) ?>
                    </select>                    
                </div>

              <div class="modal-footer">
                  <button type="submit" class="btn btn-primary" name="e_presc_btn">Edit</button>
                  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
              </div>
                        
            </form>
         </div>
      </div>
   </div>
</div>

<!-- Start Delete Service Modal-->
<div class="modal fade" id="delPrescription" tabindex="-1">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header"> <h3></h3></div>
         <div class="modal-body">
            <h4 class="modal-title text-capitalize py-2" id="del_title"></h4>
            <form method="POST">
                <input type="hidden" name="del_presc_id" id="del_presc_id" >
              <div class="modal-footer">
                  <button type="submit" class="btn btn-danger" name="del_btn">Delete</button>
                  <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Cancel</button>
              </div>
                        
            </form>
         </div>
      </div>
   </div>
</div>
