<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Appointments
        </h1>
        <ol class="breadcrumb">
            <li>
                <i class="fa fa-dashboard"></i>  <a href="dashboard">Dashboard</a>
            </li>
            <li class="active">
                <i class="fa fa-table"></i> Appointments
            </li>
        </ol>
    </div>
</div>
<!-- /.row -->
<div class="row">
    <div class="col-lg-12">
        <?= $web_app->showAlert( $msg ) ?>
        <div class="panel panel-default">
            <div class="panel-heading"><h4 class="panel-title text-center">Appointments</h4> </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Full Name</th>
                            <th>Title</th>
                            <th>Fees</th>
                            <th>Service</th>
                            <th>Date & Time</th>
                            <th>Complain</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            if ( $appointments_arr ) 
                            {
                                $sn = 1;
                                foreach ( $appointments_arr as $appointment_dt ) 
                                {
                                    $id = $appointment_dt['id'];
                                    $service = $appointment_dt['service'] ;
                                    $fees = $serv->getFeesByService( [ $service ] );
                                    $status = $appointment_dt['status'];
                                    $patient_id = $appointment_dt['patient_id'];
                                    $patient_dt = $pat->getFullNameById( [ $patient_id ] );
                                    $schedule_state = $appointment_dt['session'];
                        ?>
                            <tr>
                                <td><?= $sn ?></td>
                                <td><?= $patient_dt['first_name'].' '. $patient_dt['last_name'] ?></td>
                                <td><?= $appointment_dt['title'] ?></td>
                                <td><?= $fees ?></td>
                                <td><?= $service ?></td>
                                <td><?= $appointment_dt['date'].' '. $appointment_dt['time'] ?></td>
                                <td><?= $appointment_dt['complain'] ?></td>
                                <td><?= $status ?></td>
                                <td class="text-center">
                                    <?php
                                        if( $schedule_state == 'Start' )
                                        {
                                    ?>
                                        <p class="badge bg-success py-3">Session Is Currently Ongoing</p>
                                    <?php
                                        }
                                        else if( $schedule_state == 'Expired')
                                        {
                                    ?>
                                        <p class="badge bg-secondary py-3">This Session Is Over</p>
                                    <?php
                                        }
                                        else
                                        {
                                          if ( $status == 'Pending' ) 
                                          {
 
                                    ?>

                                        <button class="btn btn-success status_btn" data-bs-toggle="modal" data-id="<?= $id ?>" data-date="<?= $appointment_dt['date'] ?>" data-time="<?= $appointment_dt['time'] ?>" data-status="Accept" data-bs-target="#statusModal"><i class="fa fa-fw fa-check"></i> Accept </button>

                                        <button class="btn btn-danger status_btn" data-bs-toggle="modal" data-id="<?= $id ?>" data-status="Reject" data-bs-target="#statusModal"><i class="fa fa-fw fa-times"></i> Reject </button>
                                    <?php
                                            }
                                            else 
                                            {
                                                echo "<p class='badge bg-info py-3'>This Appointment Has Been  $status </p>
";
                                            }
                                        }
                                    ?>
                                </td>
                            </tr>

                        <?php
                                    $sn++;
                                }
                            }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- Start Change Status Modal-->
<div class="modal fade" id="statusModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"> <h3></h3></div>
            <div class="modal-body">
                <p><b>Note: this can't be reverse!!!</b></p>
                <form method="POST">
                    <input type="hidden" name="appt_id" id="appt_id" >
                    <input type="hidden" name="date" id="date" >
                    <input type="hidden" name="time" id="time" >
                    <div>
                      <label>Status</label>
                      <input type="text" name="sel_status" id="sel_status" readonly class="form-control">
                    </div>
                    <div class="mt-2">
                      <label for="comment">Comment <span class="text-danger">*</span></label>
                      <textarea name="comment" id="comment" required class="form-control"></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="effect_btn" id="effect_btn"></button>
                        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Cancel</button>
                    </div>
                            
                </form>
            </div>
        </div>
    </div>
</div>