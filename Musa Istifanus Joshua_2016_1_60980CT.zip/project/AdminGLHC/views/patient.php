<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Patient List
        </h1>
        <ol class="breadcrumb">
            <li>
                <i class="fa fa-dashboard"></i>  <a href="dashboard">Dashboard</a>
            </li>
            <li class="active">
                <i class="fa fa-table"></i> Patient List
            </li>
        </ol>
    </div>
</div>
<!-- /.row -->

<div class="row">

    <div class="col-lg-12">
        <?= $web_app->showAlert( $msg ) ?>
        <button class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#newPatient"><i class="fa fa-fw fa-plus"></i> Add New Patient</button>
        <div class="panel panel-default">
            <div class="panel-heading"><h4 class="panel-title text-center">Patient List</h4> </div>
            <div class="panel-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                <tr>
                    <th>S/N</th>
                    <th>Name of Patient</th>
                    <th>Blood Group</th>
                    <th>Gender</th>
                    <th>Phone number</th>
                    <th>Email address</th>
                    <th>Civil Status</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    if ( $patient_arr ) 
                    {
                        $sn = 1;
                        foreach ( $patient_arr as $patient_dt ) 
                        {
                            $id = $patient_dt['id'];
                ?>
                    <tr>
                        <td><?= $sn ?></td>
                        <td><?= $patient_dt['first_name'] ?></td>
                        <td><?= $patient_dt['blood_grp'] ?></td>
                        <td><?= $patient_dt['gender'] ?></td>
                        <td><?= $patient_dt['phone'] ?></td>
                        <td><?= $patient_dt['email'] ?></td>
                        <td><?= $patient_dt['m_status'] ?></td>
                        <td>
                            <button class="btn btn-danger patient_del_btn" data-bs-toggle="modal" data-id="<?= $id ?>" data-ques="do you reall want to delete this Patient ?" data-bs-target="#delPatient"><i class="fa fa-fw fa-trash"></i> Delete </button>
                        </td>
                    </tr>

                <?php
                            $sn++;
                        }
                    }
                ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<!-- Start Reset Password Modal-->
<div class="modal fade mt-5" id="newPatient" tabindex="-1">
   <div class="modal-dialog modal-lg mt-5">
      <div class="modal-content" style="padding-top: 15%">
         <div class="modal-header"> <h3></h3></div>
         <div class="modal-body">
            <h3 class="modal-title"><strong>Add Patient</strong></h3>
            <hr>
            <form method="POST">

                <div class="form-group col-md-6">
                    <label class="control-label" for="first_name">First Name <span class="text-danger">*</span></label>
                    <input class="form-control" id="first_name" name="first_name" autofocus required type="text" value="<?= $web_app->persistData( 'first_name', false, $clear ) ?>">
                </div>
                <div class="form-group col-md-6">
                    <label class="control-label" for="last_name">Last Name <span class="text-danger">*</span></label>
                    <input class="form-control" id="last_name" name="last_name" required type="text" value="<?= $web_app->persistData( 'last_name', false, $clear ) ?>">
                </div>
                <div class="form-group col-md-6">
                    <label class="control-label" for="gender">Gender <span class="text-danger">*</span></label>
                   <select class="form-control" id="gender" name="gender" required style="height: 40px">
                       <option value="male">Male</option>
                       <option value="female">Female</option>
                   </select>
                </div>
                <div class="form-group col-md-6">
                    <label class="control-label" for="blood_grp">Blood Group <span class="text-danger">*</span></label>
                    <select class="form-control" id="blood_grp" name="blood_grp"  style="height: 40px" required>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>

                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label" for="dob">Birth of Date <span class="text-danger">*</span></label>
                    <input class="form-control" id="dob" name="dob" type="date" required value="<?= $web_app->persistData( 'dob', false, $clear )?>">
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label" for="phn_num">Phone number <span class="text-danger">*</span></label>
                    <input class="form-control" id="phn_num" name="phn_num" type="text" value="<?= $web_app->persistData( 'phn_num', false, $clear ) ?>">
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label" for="email">Email address <span class="text-danger">*</span></label>
                    <input class="form-control" id="email" name="email" required type="text" value="<?= $web_app->persistData( 'email', false, $clear )?>">
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label" for="address">Address <span class="text-danger">*</span></label>
                    <div>
                        <textarea class="form-control" id="address" required name="address"><?= $web_app->persistData( 'address', false, $clear ) ?></textarea>
                    </div>
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label" for="status">Civil Status <span class="text-danger">*</span></label>
                    <select class="form-control" id="status" name="status" required style="height: 40px">
                        <option value="single">Single</option>
                        <option value="married">Married</option>
                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label" for="age">Age <span class="text-danger">*</span></label>
                    <input class="form-control" id="age" name="age" type="text" required value="<?= $web_app->persistData( 'age', false, $clear )?>">
                </div>
                <div class="divider"></div>
                <div class="form-group col-md-4">
                    <label class="control-label" for="bp">BP <span class="text-danger">*</span></label>
                    <input class="form-control" id="bp" name="bp" required type="text" value="<?= $web_app->persistData( 'bp', false, $clear ) ?>">
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label" for="temp">Temp (°C) <span class="text-danger">*</span></label>
                    <input class="form-control" id="temp" name="temp" required type="text" value="<?= $web_app->persistData( 'temp', false, $clear ) ?>">
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label" for="pr">PR <span class="text-danger">*</span></label>
                    <input class="form-control" id="pr" name="pr" required type="text" value="<?= $web_app->persistData( 'pr', false, $clear ) ?>">
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label" for="pword">Password <span class="text-danger">*</span></label>
                    <input class="form-control" id="pword" type="password" required name="pword" value="<?= $web_app->persistData( 'pword', false, $clear ) ?>">
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label" for="rr">RR <span class="text-danger">*</span></label>
                    <input class="form-control" id="rr" type="text" required name="rr" value="<?= $web_app->persistData( 'rr', false, $clear ) ?>">
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label" for="wt">WT (Kg) <span class="text-danger">*</span></label>
                    <input class="form-control" id="wt" name="wt" required type="text" value="<?= $web_app->persistData( 'wt', false, $clear ) ?>">
                </div>
                <div class="form-group col-md-4">
                    <label class="control-label" for="ht">HT <span class="text-danger">*</span></label>
                    <input class="form-control" id="ht" name="ht" required type="text" value="<?= $web_app->persistData( 'ht', false, $clear ) ?>">
                </div>

                    </div>

              <div class="modal-footer">
                  <button type="submit" class="btn btn-primary" name="add_btn">Save</button>
                  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
              </div>
                        
            </form>
         </div>
      </div>
   </div>
</div>
<!-- End Reset Password Modal-->


<!-- Start Delete Patient Modal-->
<div class="modal fade" id="delPatient" tabindex="-1">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header"> <h3></h3></div>
         <div class="modal-body">
            <h4 class="modal-title text-capitalize py-2" id="del_title"></h4>
            <form method="POST">
                <input type="hidden" name="del_patient_id" id="del_patient_id" >
              <div class="modal-footer">
                  <button type="submit" class="btn btn-danger" name="del_btn">Delete</button>
                  <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Cancel</button>
              </div>
                        
            </form>
         </div>
      </div>
   </div>
</div>
