//load request modal
$( document ).on( 'click', '.status_btn', ( e ) => {
   const dt_set = e.target.dataset;

   $( '#appt_id' ).val( dt_set.id );
   $( '#sel_status' ).val( dt_set.status );
   $( '#date' ).val( dt_set.date );
   $( '#time' ).val( dt_set.time );
   if ( dt_set.status == 'Accept' ) 
   {
   		$( '#effect_btn' ).attr( 'class', 'btn btn-success' );
   } 
   else 
   {
   		$( '#effect_btn' ).attr( 'class', 'btn btn-danger' )
   }
   $( '#effect_btn' ).text( dt_set.status );
});