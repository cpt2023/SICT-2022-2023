//load edit medicine modal with the required info
$( document ).on( 'click', '.medicine_edit_btn', ( e ) => {
   const dt_set = e.target.dataset;

   $( '#med_id' ).val( dt_set.id );
   $( '#e_category' ).val( dt_set.category );
   $( '#e_medicine' ).val( dt_set.medicine );
   $( '#e_price' ).val( dt_set.price );
});

//delete modal
$( document ).on( 'click', '.med_del_btn', ( e ) => {
   const dt_set = e.target.dataset;

   $( '#del_med_id' ).val( dt_set.id );
   $( '#del_title' ).text( dt_set.ques );
});
