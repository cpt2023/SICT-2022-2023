//prescription edit modal
$( document ).on( 'click', '.pres_edit_btn', ( e ) => {
   const dt_set = e.target.dataset;

   $( '#presc_id' ).val( dt_set.id );
   $( '#e_title' ).val( dt_set.title);
   $( '#e_service' ).val( dt_set.service );
   $( '#e_category' ).val( dt_set.category );
   $( '#e_medicine' ).val( dt_set.medicine );
});

//delete modal
$( document ).on( 'click', '.pres_del_btn', ( e ) => {
   const dt_set = e.target.dataset;

   $( '#del_presc_id' ).val( dt_set.id );
   $( '#del_title' ).text( dt_set.ques );
});
