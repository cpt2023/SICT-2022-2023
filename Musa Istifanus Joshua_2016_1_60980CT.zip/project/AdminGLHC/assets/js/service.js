//load service eidt modal
$( document ).on( 'click', '.service_edit_btn', ( e ) => {
   const dt_set = e.target.dataset;

   $( '#service_id' ).val( dt_set.id );
   $( '#e_service' ).val( dt_set.service );
   $( '#e_fees' ).val( dt_set.fee );
});

//service delete modal 
$( document ).on( 'click', '.service_del_btn', ( e ) => {
   const dt_set = e.target.dataset;

   $( '#del_service_id' ).val( dt_set.id );
   $( '#del_title' ).text( dt_set.ques );
});
