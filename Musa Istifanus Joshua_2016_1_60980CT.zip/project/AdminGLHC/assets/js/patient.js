//Patient delete modal
$( document ).on( 'click', '.patient_del_btn', ( e ) => {
   const dt_set = e.target.dataset;

   $( '#del_patient_id' ).val( dt_set.id );
   $( '#del_title' ).text( dt_set.ques );
});