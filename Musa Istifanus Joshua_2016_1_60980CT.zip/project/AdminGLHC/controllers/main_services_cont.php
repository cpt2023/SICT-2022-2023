<?php 
	//auth
	include_once( 'user_auth.php' );

	//App Function
	include_once( 'models/Service.php');

	//Creating Instances
	$serv = new Service();

	if ( isset( $_POST['service_btn'] ) ) 
	{
		//Getting inputs
		$service = $_POST['service'];
		$fees = $_POST['fees'];

		if ( $service && $fees ) 
		{
			$get_service = $serv->getByService( [ $service ] );

			if ( !$get_service ) 
			{
				$dt_01 = [ $service, $fees ];

				$add_new = $serv->addNew( $dt_01 );

				if ( $add_new ) 
				{
					$msg = $web_app->showAlertMsg( 'success', ' Service Added.' ); 
					$clear = true;	
				} 
				else 
				{
					$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Service Not Added.' ); 		
				}				
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Service Already Exist.' ); 	
			}			
		}
		else
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
	}

	//Edit logic
	if ( isset( $_POST['e_service_btn'] ) ) 
	{
		$service = $_POST['e_service'];
		$fees = $_POST['e_fees'];
		$id = $_POST['service_id'];

		if ( $service && $fees && $id ) 
		{ 
			$dt_01 = [ $service, $fees, $id ];

			$update_service = $serv->updateById( $dt_01 ) ;

			if ( $update_service ) 
			{
				$msg = $web_app->showAlertMsg( 'success', ' Service Updated.' );
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Service Not Updated.' ); 		
			}				
		}
		else
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
	}

	//delete logic
	if ( isset( $_POST['del_btn'] ) ) 
	{
		$id = $_POST['del_service_id'];

		if ( $id ) 
		{ 
			$dt_01 = [ $id ];

			$del_service = $serv->deleteById( $dt_01 ) ;

			if ( $del_service ) 
			{
				$msg = $web_app->showAlertMsg( 'success', ' Service Deleted.' );
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Service Not Deleted.' ); 		
			}				
		}
		else{
			$msg = $web_app->showAlertMsg( 'danger', 'Please, Select a Service.' ); 		
		}
	}

	//Fetching services
	$services_arr = $serv->getAll( [] );

	//Main Services interface
	include_once( 'views/main_services.php' );
 ?>