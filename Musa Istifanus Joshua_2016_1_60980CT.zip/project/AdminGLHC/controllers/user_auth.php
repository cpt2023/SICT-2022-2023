<?php 

	$admin_id = $admin->getLoggedAdmin();

	//when not logged in
	if ( !$admin_id ) 
	{
		header( "Location: ./", true, 301 );
		exit();
	}

?>