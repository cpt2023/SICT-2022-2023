<?php 
	//auth
	include_once( 'user_auth.php' );

	//App Functions
	include_once( 'models/Patient.php');

	//Creating Instances
	$pat = new Patient();

	if ( isset( $_POST['add_btn'] ) ) 
	{
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$gender = $_POST['gender'];
		$blood_grp = $_POST['blood_grp'];
		$dob = $_POST['dob'];
		$phn_num = $_POST['phn_num'];
		$email = $_POST['email'];
		$address = $_POST['address'];
		$status = $_POST['status'];
		$age = $_POST['age'];
		$bp = $_POST['bp'];
		$temp = $_POST['temp'];
		$pr = $_POST['pr'];
		$pword = $_POST['pword'];
		$rr = $_POST['rr'];
		$wt = $_POST['wt'];
		$ht = $_POST['ht'];

		if ( $first_name && $last_name && $gender && $blood_grp && $dob && $phn_num && $email && $address && $status && $age && $bp && $temp && $pr && $pword && $rr && $wt && $ht ) 
		{
			$get_patient = $pat->getByEmail( [ $email ] );

			if ( !$get_patient ) 
			{
				$pword_hash = $pat->encPword( $pword );
				$dt_01 = [ $first_name, $last_name, $gender, $blood_grp, $dob, $phn_num, $email, $address, $status, $age, $bp, $temp, $pr, $rr, $wt, $ht, $pword_hash ];

				$add_new = $pat->addNew( $dt_01 );

				if ( $add_new ) 
				{
					$msg = $web_app->showAlertMsg( 'success', ' Patient Added.' ); 
					$clear = true;	
				} 
				else 
				{
					$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Patient Not Added.' ); 					}				
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Patient With This Email Already Exist.' ); 	
			}			
		}
		else
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
	}

	//Edit logic
	if ( isset( $_POST['del_btn'] ) ) 
	{
		$id = $_POST['del_patient_id'];

		if ( $id ) 
		{ 
			$dt_01 = [ $id ];

			$del_patient = $pat->deleteById( $dt_01 ) ;

			if ( $del_patient ) 
			{
				$msg = $web_app->showAlertMsg( 'success', 'Patient Deleted.' );
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Patient Not Deleted.' ); 		
			}				
		}
		else{
			$msg = $web_app->showAlertMsg( 'danger', 'Please, Select a Patient.' ); 		
		}
	}

	//Fetching Patient Data's
	$patient_arr = $pat->getAll( [] );

	//Patient interface
	include_once( 'views/patient.php' );
 ?>