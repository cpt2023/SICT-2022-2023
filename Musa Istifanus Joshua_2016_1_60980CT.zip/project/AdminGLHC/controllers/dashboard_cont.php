<?php 

	//auth
	include_once( 'user_auth.php' );

	//App Functions
	include_once( 'models/Patient.php' );
	include_once( 'models/Service.php' );
	include_once( 'models/Appointment.php' );
	include_once( 'models/Payment.php' );

	//Creating Instances
	$pat = new Patient();
	$serv = new Service();
	$appt = new Appointment();
	$payment = new Payment();

	//fetching dashboard indicators
	$total_pat = $pat->getCount( [] );
	$total_services = $serv->getCount( [] );
	$total_appointment = $appt->getCount( [] );
	$total_sales = $payment->getTotalSales( [] );
	$payments_arr = $payment->getBottomTransaction( [] );

	//Dashboard interface
	include_once( 'views/dashboard.php' );
 ?>