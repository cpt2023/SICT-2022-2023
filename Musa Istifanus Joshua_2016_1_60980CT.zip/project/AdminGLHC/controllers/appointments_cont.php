<?php 

	//auth
	include_once( 'user_auth.php' );

	//App functions
	include_once( 'models/Patient.php' );
	include_once( 'models/Service.php' );
	include_once( 'models/Appointment.php' );

	//Creating Instances
	$pat = new Patient();
	$serv = new Service();
	$appt = new Appointment();

	if ( isset( $_POST['effect_btn'] ) ) 
	{
		//Getting data
		$appt_id = $_POST['appt_id'];
		$status = $_POST['sel_status'].'ed';
		$comment = $_POST['comment'];

		if ( $appt_id && $status && $comment ) 
		{
			if ( $status == 'Accepted' ) 
			{
				$date = $_POST['date'];
				$time = $_POST['time'];

				if ( $date && $time ) 
				{
					$dt_01 = [ $date, $time, 'Accepted' ];

					$get_appt = $appt->getByDateTime( $dt_01 );

					if ( !$get_appt ) 
					{
						$dt_01 = [ $status, $comment, $appt_id ];

						$update_status = $appt->updateStatusById( $dt_01 );

						if ( $update_status ) 
						{
							$msg = $web_app->showAlertMsg( 'success', 'Status Updated.' );
						} 
						else 
						{
							$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Status Not Updated.' );
						}
					} 
					else 
					{
						$msg = $web_app->showAlertMsg( 'info', 'Sorry, An Appointment Has Been Schedule For This Time And Date.' );
					}
				} 
				else 
				{
					$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
				}
				
			}
			else
			{
				$dt_01 = [ $status, $comment, $appt_id ];

				$update_status = $appt->updateStatusById( $dt_01 );

				if ( $update_status ) 
				{
					$msg = $web_app->showAlertMsg( 'success', 'Status Updated.' );
				} 
				else 
				{
					$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Status Not Updated.' );
				}
			}			
		} 
		else 
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}		
	}

	//fetching appointments
	$appointments_arr = $appt->getAll( [] );

	//Appointments interface
	include_once( 'views/appointments.php' );
 ?>