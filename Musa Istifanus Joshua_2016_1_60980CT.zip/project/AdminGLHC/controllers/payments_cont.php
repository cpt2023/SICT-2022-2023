<?php 

	//auth
	include_once( 'user_auth.php' );

	//App Functions
	include_once( 'models/Payment.php' );

	//Creating Instances
	$payment = new Payment();

	//fetching transaction
	$payments_arr = $payment->getAll( [] );

	//Payments interface
	include_once( 'views/payments.php' );
 ?>