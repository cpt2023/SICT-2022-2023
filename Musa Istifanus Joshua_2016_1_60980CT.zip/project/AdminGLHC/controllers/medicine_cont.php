<?php 
	//auth
	include_once( 'user_auth.php' );

	//App Function
	include_once( 'models/Medicine.php');

	//Creating Instances
	$med = new Medicine();

	if ( isset( $_POST['med_btn'] ) ) 
	{
		//Getting Inputs
		$category = $_POST['category'];
		$medicine = $_POST['medicine'];
		$price = $_POST['price'];

		if ( $category && $medicine && $price ) 
		{
			$dt_01 = [ $category, $medicine, $price ];

			$add_new = $med->addNew( $dt_01 );

			if ( $add_new ) 
			{
				$msg = $web_app->showAlertMsg( 'success', ' Medicine Added.' ); 
				$clear = true;	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Medicine Not Added.' ); 		
			}				
		}
		else
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
	}

	//Edit Logic
	if ( isset( $_POST['e_med_btn'] ) ) 
	{
		$category = $_POST['e_category'];
		$medicine = $_POST['e_medicine'];
		$price = $_POST['e_price'];
		$id = $_POST['med_id'];

		if ( $category && $medicine && $price && $id ) 
		{
			$dt_01 = [ $category, $medicine, $price, $id ];

			$update_med = $med->updateById( $dt_01 );

			if ( $update_med ) 
			{
				$msg = $web_app->showAlertMsg( 'success', ' Medicine Updated.' ); 	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Medicine Not Updated.' ); 		
			}				
		}
		else
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
	}

	//Delete logic
	if ( isset( $_POST['del_btn'] ) ) 
	{
		$id = $_POST['del_med_id'];

		if ( $id ) 
		{ 
			$dt_01 = [ $id ];

			$del_med = $med->deleteById( $dt_01 ) ;

			if ( $del_med ) 
			{
				$msg = $web_app->showAlertMsg( 'success', ' Medicine Deleted.' );
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Medicine Not Deleted.' ); 		
			}				
		}
		else{
			$msg = $web_app->showAlertMsg( 'danger', 'Please, Select a Medicine.' ); 		
		}
	}


	$meds_arr = $med->getAll( [] );

	//Medicine interface
	include_once( 'views/medicine.php' );
 ?>