<?php 
	//auth
	include_once( 'user_auth.php' );

	//App Function
	include_once( 'models/Prescription.php');
	include_once( 'models/Service.php');
	include_once( 'models/Medicine.php');

	//Creating Instances
	$prescription = new Prescription();
	$serv = new Service();
	$med = new Medicine();

	if ( isset( $_POST['presc_btn'] ) ) 
	{
		$title = $_POST['title'];
		$service = $_POST['service'];
		$category = $_POST['category'];
		$medicine = $_POST['medicine'];

		if ( $service && $title && $category && $medicine ) 
		{
			$dt_01 = [ $title, $service, $category, $medicine ];

			$add_new = $prescription->addNew( $dt_01 );

			if ( $add_new ) 
			{
				$msg = $web_app->showAlertMsg( 'success', ' Prescription Added.' ); 
				$clear = true;	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Prescription Not Added.' ); 		
			}				
		}
		else
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
	}

	//Edit logic
	if ( isset( $_POST['e_presc_btn'] ) ) 
	{
		$title = $_POST['e_title'];
		$service = $_POST['e_service'];
		$category = $_POST['e_category'];
		$medicine = $_POST['e_medicine'];
		$id = $_POST['presc_id'];

		if ( $service && $title && $category && $medicine && $id ) 
		{ 
			$dt_01 = [ $title, $service, $category, $medicine, $id ];

			$update_prescription = $prescription->updateById( $dt_01 ) ;

			if ( $update_prescription ) 
			{
				$msg = $web_app->showAlertMsg( 'success', ' Prescription Updated.' );
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Prescription Not Updated.' ); 		
			}				
		}
		else
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
	}

	//Delete logic
	if ( isset( $_POST['del_btn'] ) ) 
	{
		$id = $_POST['del_presc_id'];

		if ( $id ) 
		{ 
			$dt_01 = [ $id ];

			$del_service = $prescription->deleteById( $dt_01 ) ;

			if ( $del_service ) 
			{
				$msg = $web_app->showAlertMsg( 'success', ' Prescription Deleted.' );
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Prescription Not Deleted.' ); 		
			}				
		}
		else{
			$msg = $web_app->showAlertMsg( 'danger', 'Please, Select a Service.' ); 		
		}
	}

	//Fetching data's
	$prescription_arr = $prescription->getAll( [] );
	$service_arr = $serv->getAll( [] );
	$med_arr = $med->getAll( [] );

	//Prescription interface
	include_once( 'views/prescription.php' );
 ?>