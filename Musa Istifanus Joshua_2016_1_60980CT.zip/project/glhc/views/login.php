<body class="bg-dark" style="display: flex; justify-content: center; height: 100vh; align-items: center;">

<div class="container col-md-5 col-lg-4">
    <div class="text-center">
        <h3 style="color: #fff;">GOOD LIFE HEALTH CARE</h3>
    </div>
    <div class="card card-login mx-auto">
        <div class="card-header fw-bold py-3">
            <big style="font-weight: bolder; font-size: 20px" >Patient Login</big>
            <?= $web_app->showAlert( $msg ) ?>
        </div>
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="email">Email address <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="email" autofocus required name="email" aria-describedby="emailHelp" placeholder="Enter email">
                </div>
                <div class="form-group">
                    <label for="pword">Password <span class="text-danger">*</span></label>
                    <input type="password" class="form-control" required id="pword" name="pword" placeholder="Password">
                </div>
                <div class="form-group">
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" class="form-check-input">
                            Remember Password
                        </label>
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit"  class="btn btn-primary" name="btnLogin">Login</button>
                </div>
            </form>

        </div>
    </div>
</div>