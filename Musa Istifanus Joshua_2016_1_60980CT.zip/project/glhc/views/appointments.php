<!-- Page Heading -->
<div class="row">
  <div class="col-lg-12">
    <h1 class="page-header">
      Appointments
    </h1>
    <ol class="breadcrumb">
      <li>
          <i class="fa fa-dashboard"></i>  <a href="dashboard">Dashboard</a>
      </li>
      <li class="active">
          <i class="fa fa-list"></i> Appointments
      </li>
    </ol>
  </div>
</div>

<div class="row">
  <div class="col-lg-12">
    <?= $web_app->showAlert( $msg ) ?>
    <button class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#appointment"><i class="fa fa-fw fa-plus"></i> Book Appointment</button>
    <div class="panel panel-default">
      <div class="panel-heading"><h4 class="panel-title text-center">Appointments</h4> </div>
      <div class="panel-body">
        <div class="table-responsive">
          <table class="table table-bordered table-hover">
            <thead>
              <tr>
                  <th>S/N</th>
                  <th>Title</th>
                  <th>Fees</th>
                  <th>Service</th>
                  <th>Date & Time</th>
                  <th>Complain</th>
                  <th>Status</th>
                  <th>Payment Status</th>
                  <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
                  if ( $appt_arr ) 
                  {
                      $sn = 1;
                      foreach ( $appt_arr as $appointment_dt ) 
                      {
                          $id = $appointment_dt['id'];
                          $service = $appointment_dt['service'] ;
                          $fees = $serv->getByService( [ $service ] );
                          $status = $appointment_dt['status']; 
                          $comment = $appointment_dt['comment'];
                          $schedule = $appointment_dt['date'].' '. $appointment_dt['time'];
                          $patient_id = $appointment_dt['patient_id'];
                          $schedule_state = $appointment_dt['session'];
                          $payment_status = $payment->getByAppointmentId( [ $id, $patient_id ] ); 
              ?>
                <tr>
                    <td><?= $sn ?></td>
                    <td><?= $appointment_dt['title'] ?></td>
                    <td><?= $fees ?></td>
                    <td><?= $service ?></td>
                    <td><?= $schedule ?></td>
                    <td><?= $appointment_dt['complain'] ?></td>
                    <td><?= $status ?></td>
                    <td><?= $payment_status ?></td>
                    <td class="text-center">
                      <?php
                        if ( $status == 'Accepted' ) 
                        {
                          if ( $schedule_state == 'Expired' && $payment_status == 'Unpaid' ) 
                          {
                      ?>
                            <span class="badge bg-secondary py-3">Session Expired</span>

                            <button class="btn btn-danger appt_del_btn" data-bs-toggle="modal" data-id="<?= $id ?>" data-ques="do you reall want to delete this Appointment ?" data-bs-target="#delAppointment"><i class="fa fa-fw fa-trash"></i> Delete </button>
                      <?php 
                          }
                          elseif( $schedule_state == 'Expired' && $payment_status == 'Paid'  )
                          {
                      ?>
                            <span class="badge bg-secondary py-3">This Session Is Over</span>
                      <?php
                          }
                          elseif( $schedule_state ==  'Start' )
                          { 
                      ?>
                            <span class="badge bg-success py-3">Session Is Currently Ongoing</span>
                      <?php 
                          }
                          elseif ( $schedule_state == 'ON' && $payment_status == 'Paid' ) 
                          {
                      ?>
                            <button class="btn btn-success payment_btn" data-bs-toggle="modal" data-id="<?= $id ?>" data-service="<?= $service ?>" data-service_fee="<?= $fees ?>" data-schedule="<?= $schedule ?>" data-patient_id="<?= $patient_id ?>" data-state="2" data-comment="<?= $comment ?>" data-bs-target="#paymentModal"><i class="fa fa-fw fa-info"></i> Appointment Details </button>
                      <?php 
                          }
                          elseif ( $schedule_state == 'ON' && $payment_status == 'Unpaid'  ) {
                      ?>
                            <button class="btn btn-success payment_btn" data-bs-toggle="modal" data-id="<?= $id ?>" data-service="<?= $service ?>" data-service_fee="<?= $fees ?>" data-schedule="<?= $schedule ?>" data-patient_id="<?= $patient_id ?>" data-state="1" data-comment="<?= $comment ?>" data-bs-target="#paymentModal"><i class="fa fa-fw fa-arrow-right"></i> Proceed with Payment </button>
                      <?php
                          }
                        }
                        elseif( $status == 'Rejected' )
                        {
                      ?>
                          <button class="btn btn-info payment_btn" data-bs-toggle="modal" data-id="<?= $id ?>" data-service="<?= $service ?>" data-service_fee="<?= $fees ?>" data-schedule="<?= $schedule ?>" data-state="0" data-patient_id="<?= $patient_id ?>" data-comment="<?= $comment ?>" data-bs-target="#paymentModal"><i class="fa fa-fw fa-info"></i> View Reason </button>
                          <button class="btn btn-danger appt_del_btn" data-bs-toggle="modal" data-id="<?= $id ?>" data-ques="do you reall want to delete this Appointment ?" data-bs-target="#delAppointment"><i class="fa fa-fw fa-trash"></i> Delete </button>

                      <?php                          
                        }
                        else
                        {
                      ?>
                          <button class="btn btn-danger appt_del_btn" data-bs-toggle="modal" data-id="<?= $id ?>" data-ques="do you reall want to delete this Appointment ?" data-bs-target="#delAppointment"><i class="fa fa-fw fa-trash"></i> Delete </button>
                      <?php   
                        }
                      ?>
                    </td>
                </tr>

              <?php
                    $sn++;
                  }
                }
              ?>
            </tbody>
          </table>
        </div>
      </div>
  </div>
</div>

<!-- Start Add Medicine Modal-->
<div class="modal fade mt-5" id="appointment" tabindex="-1">
   <div class="modal-dialog modal-lg mt-5">
      <div class="modal-content">
         <div class="modal-header"> <h3></h3></div>
         <div class="modal-body">
            <h3 class="modal-title"><strong>Book Appointment</strong></h3>
            <p>Note : This appointment is for a duration of 15 Minutes</p>
            <hr>
            <form method="POST">

                <div class="form-group col-lg-6">
                    <label class="control-label" for="title">Title <span class="text-danger">*</span></label>
                    <input class="form-control" id="title" name="title" autofocus required type="text" value="<?= $web_app->persistData( 'title', false, $clear ) ?>">
                </div>
                <div class="form-group col-lg-6">
                    <label class="control-label" for="service">Service <span class="text-danger">*</span></label>
                    <select name="service" id="service" required class="form-control" style="height: 37px">
                      <?= $serv->loadServices( $service_arr ) ?>
                    </select>
                </div>
                <div class="form-group col-lg-6">
                    <label class="control-label" for="datetime">Date & Time <span class="text-danger">*</span></label>
                    <div style="display: flex;">
                      <input class="form-control col-10" id="datetime" name="datetime" required type="datetime-local" value="<?= $web_app->persistData( 'datetime', false, $clear ) ?>">
                      <select id="meridian" name="meridian" class="form-control" style="height: 34px">
                        <option value="AM">AM</option>
                        <option value="PM">PM</option>                        
                      </select>
                    </div>
                </div>
                <div class="form-group col-lg-6">
                    <label class="control-label" for="complain">Complain <span class="text-danger">*</span></label>
                    <textarea name="complain" id="complain" class="form-control" required ><?= $web_app->persistData( 'complain', false, $clear ) ?></textarea>                
                </div>

              <div class="modal-footer">
                  <button type="submit" class="btn btn-primary" name="book_btn">Book</button>
                  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>           
              </div>
                        
            </form>
         </div>
      </div>
   </div>
</div>
<!-- End Add Medicine Modal-->

<!-- Start Add Medicine Modal-->
<div class="modal fade mt-5" id="paymentModal" tabindex="-1" style="margin-top: 10%">
   <div class="modal-dialog mt-5">
      <div class="modal-content" style="margin-top: 15%">
         <div class="modal-header"> <h3></h3></div>
         <div class="modal-body">
            <h3 class="modal-title" id="form-title"></h3>
            <p>Note : This appointment is for a duration of 15 Minutes</p>
            <hr>
            <form method="POST">
                <div class="text-right">
                  <button type="submit" name="pay_btn" id="pay_btn" class="btn btn-lg btn-success">Pay</button>
                </div>
                <input type="hidden" name="appointment_id" id="appointment_id">
                <input type="hidden" name="patient_id" id="patient_id">
                <div class="form-group service-div">
                    <label class="control-label" for="p_service">Payment For</label>
                    <input class="form-control" id="p_service" name="p_service" autofocus required type="text" readonly >
                </div>
                <div class="form-group charge-div">
                    <label class="control-label" for="charge">Amount</label>
                    <input type="text" name="charge" class="form-control" id="charge" readonly>
                </div>
                <div class="form-group">
                    <label class="control-label" for="schedule">Appointment Schedule</label>
                    <div>
                      <input class="form-control" id="schedule" name="schedule" required type="text" readonly="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label" for="d_comment">Comment</label>
                    <textarea name="d_comment" id="d_comment" class="form-control" readonly ><textarea>                
                </div>

              <div class="modal-footer">
                  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>           
              </div>
                        
            </form>
         </div>
      </div>
   </div>
</div>
<!-- End Add Medicine Modal-->

<!-- Start Edit Medicine Modal-->
<div class="modal fade" id="reason" tabindex="-1" style="margin-top: 20%">
   <div class="modal-dialog">
      <div class="modal-content" style="margin-top: 10%">
         <div class="modal-header"> <h3></h3></div>
         <div class="modal-body">
            <h3 class="modal-title"><strong>Reason</strong></h3>
            <div>
              <textarea id="reason" class="form-control">
                
              </textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>      
            </div>
         </div>
      </div>
   </div>
</div>
<!-- End Edit Medicine Modal-->

<!-- Start Delete Medicine Modal-->
<div class="modal fade" id="delAppointment" tabindex="-1">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header"> <h3></h3></div>
         <div class="modal-body">
            <h4 class="modal-title text-capitalize py-2" id="del_title"></h4>
            <form method="POST">
                <input type="hidden" name="del_appt_id" id="del_appt_id" >
              <div class="modal-footer">
                  <button type="submit" class="btn btn-danger" name="del_btn">Delete</button>
                  <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Cancel</button>
              </div>
                        
            </form>
         </div>
      </div>
   </div>
</div>