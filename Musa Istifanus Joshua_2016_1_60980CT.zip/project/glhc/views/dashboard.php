<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Dashboard <small>Patient Dashboard</small>
        </h1>
        <ol class="breadcrumb">
            <li class="active">
                <i class="fa fa-dashboard"></i> Appointment Overview
            </li>
        </ol>
    </div>
</div>

<!-- dashboard indicators -->
<div class="row">
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-comments fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge">
                            <?= $total_appt ?>
                        </div>
                        <div>Appointments</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-green">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-check fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge">
                            <?= $total_approved_appt ?>
                        </div>
                        <div>Approved Appointment</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-yellow">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-refresh fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge">
                            <?= $total_pending_appt ?>
                        </div>
                        <div>Pending Appointment</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-red">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-times fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge">
                            <?= $total_rejected_appt ?>
                        </div>
                        <div>Rejected Appointment</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Our Services -->
<div class="panel panel-default">
    <div class="panel-heading"><h4 class="panel-title text-center">List of Services</h4> </div>
    <div class="panel-body">
    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead>
            <tr>
                <th>S/N</th>
                <th>Service</th>
                <th>Fees</th>
            </tr>
            </thead>
            <tbody>
            <?php
                if ( $service_arr ) 
                {
                    $sn = 1;
                    foreach ( $service_arr as $service_dt ) 
                    {
                        $id = $service_dt['id'];
            ?>
                <tr>
                    <td><?= $sn ?></td>
                    <td><?= $service_dt['service'] ?></td>
                    <td><?= 'N'.$service_dt['fees'] ?></td>
                </tr>

            <?php
                        $sn++;
                    }
                }
            ?>
            </tbody>
        </table>
    </div>
</div>

</div>