<!-- Bootstrap core JavaScript -->
<script src="assets/vendor/jquery/jquery.min.js"></script>
<script src="assets/vendor/popper/popper.min.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="assets/js/bootstrap.min.js"></script>

<!-- Morris Charts JavaScript -->
<script src="assets/js/plugins/morris/raphael.min.js"></script>
<script src="assets/js/plugins/morris/morris.min.js"></script>
<script src="assets/js/appointment.js"></script>
<script src="assets/js/plugins/morris/morris-data.js"></script>
<script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>

<!-- Start Reset Password Modal-->
<div class="modal fade mt-5" id="modalSetting" tabindex="-1">
  <div class="modal-dialog mt-5">
    <div class="modal-content">
      <div class="modal-header"> <h3></h3></div>
      <div class="modal-body">
        <h3 class="modal-title"><strong>Update Password</strong></h3>
        <hr>
        <form method="POST">

          <div class="form-group">
            <label class="control-label">Password <span class="text-danger">*</span></label>
            <input type="password" class="form-control" id="txtPassword" required name="txtPassword">
          </div>
          <div class="form-group">
            <label class="control-label">Retype Password <span class="text-danger">*</span></label>
            <input class="form-control" type="password" id="txtRetypePassword" required name="txtRetypePassword">
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" name="btnSave">Save</button>
            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
          </div>
                    
        </form>
      </div>
    </div>
  </div>
</div>
<!-- End Reset Password Modal-->