<!-- Page Heading -->
<div class="row">
  <div class="col-lg-12">
    <h1 class="page-header">
        My Profile
    </h1>
    <ol class="breadcrumb">
      <li>
          <i class="fa fa-dashboard"></i>  <a href="dashboard">Dashboard</a>
      </li>
      <li class="active">
          <i class="fa fa-user"></i> My Profile
      </li>
    </ol>
  </div>
</div>

<?= $web_app->showAlert( $msg ) ?>
<div class="panel panel-default">
  <div class="panel-heading"><h4 class="panel-title text-center">My Profile</h4> </div>
    <form method="POST">
      <div class="panel-body">
        <div class="form-group col-md-6">
          <label class="control-label" for="first_name">First Name <span class="text-danger">*</span></label>
          <input class="form-control" id="first_name" name="first_name" autofocus required type="text" value="<?= $web_app->persistData( $first_name, true ) ?>">
        </div>
        <div class="form-group col-md-6">
          <label class="control-label" for="last_name">Last Name <span class="text-danger">*</span></label>
          <input class="form-control" id="last_name" name="last_name" required type="text" value="<?= $web_app->persistData( $last_name, true ) ?>">
        </div>
        <div class="form-group col-md-6">
          <label class="control-label" for="gender">Gender <span class="text-danger">*</span></label>
          <select class="form-control" id="gender" name="gender" required style="height: 40px">
            <?= $web_app->loadGender( $web_app->persistData( $gender, true ) ) ?>
          </select>
        </div>
        <div class="form-group col-md-6">
          <label class="control-label" for="blood_grp">Blood Group <span class="text-danger">*</span></label>
          <select class="form-control" id="blood_grp" name="blood_grp"  style="height: 40px" required>
            <?= $web_app->loadBloodGrps( $web_app->persistData( $blood_grp, true ) ) ?>
          </select>
        </div>
        <div class="form-group col-md-6">
          <label class="control-label" for="dob">Birth of Date <span class="text-danger">*</span></label>
          <input class="form-control" id="dob" name="dob" type="date" required value="<?= $web_app->persistData( $dob, true )?>">
        </div>
        <div class="form-group col-md-6">
          <label class="control-label" for="phn_num">Phone number <span class="text-danger">*</span></label>
          <input class="form-control" id="phn_num" name="phn_num" type="text" value="<?= $web_app->persistData( $phn_num, true ) ?>">
        </div>
        <div class="form-group col-md-6">
          <label class="control-label" for="email">Email address <span class="text-danger">*</span></label>
          <input class="form-control" id="email" name="email" readonly required type="text" value="<?= $web_app->persistData( $email, true )?>">
        </div>
        <div class="form-group col-md-6">
          <label class="control-label" for="address">Address <span class="text-danger">*</span></label>
          <div>
            <textarea class="form-control" id="address" required name="address"><?= $web_app->persistData( $address, true ) ?></textarea>
          </div>
        </div>
        <div class="form-group col-md-6">
          <label class="control-label" for="temp">Temp (°C) <span class="text-danger">*</span></label>
          <input class="form-control" id="temp" name="temp" required type="text" value="<?= $web_app->persistData( $temp, true ) ?>">
        </div>
        <div class="form-group col-md-6">
          <label class="control-label" for="pr">PR <span class="text-danger">*</span></label>
          <input class="form-control" id="pr" name="pr" required type="text" value="<?= $web_app->persistData( $pr, true ) ?>">
        </div>
        <div class="form-group col-md-4">
          <label class="control-label" for="rr">RR <span class="text-danger">*</span></label>
          <input class="form-control" id="rr" type="text" required name="rr" value="<?= $web_app->persistData( $rr, true ) ?>">
        </div>
        <div class="form-group col-md-4">
          <label class="control-label" for="wt">WT (Kg) <span class="text-danger">*</span></label>
          <input class="form-control" id="wt" name="wt" required type="text" value="<?= $web_app->persistData( $wt, true ) ?>">
        </div>
        <div class="form-group col-md-4">
          <label class="control-label" for="ht">HT <span class="text-danger">*</span></label>
          <input class="form-control" id="ht" name="ht" required type="text" value="<?= $web_app->persistData( $ht, true ) ?>">
        </div>
        <div class="form-group col-md-6">
          <label class="control-label" for="status">Civil Status <span class="text-danger">*</span></label>
          <select class="form-control" id="status" name="status" required style="height: 40px">
            <?= $web_app->loadStatus( $web_app->persistData( $m_status, true ) ) ?>
          </select>
        </div>
        <div class="form-group col-md-6">
          <label class="control-label" for="bp">BP <span class="text-danger">*</span></label>
          <input class="form-control" id="bp" name="bp" required type="text" value="<?= $web_app->persistData( $bp, true ) ?>">
        </div>
      </div>

      <div class="modal-footer">
        <button type="submit" class="btn btn-lg btn-primary" name="edit_btn">Edit</button>
      </div>
                    
    </form>
</div>