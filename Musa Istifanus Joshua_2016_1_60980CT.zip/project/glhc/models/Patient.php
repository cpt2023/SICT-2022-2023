<?php 

	include_once( 'App.php' );
	include_once( 'Encryption.php' );

	class Patient
	{
		//using Namespaces
		use App {
			App::__construct as private __appConst;
		}

		use Encryption;

		protected $table = '';
		const DB_TABLE = 'patients';

		function __construct()
	 	{
			$this->__appConst();
	 		$this->table = self::DB_TABLE;
	 	}

	 	function getLoggedPatient()
		{
			return $_COOKIE[ APP_SESS ] ?? 0;
		}

		function getLogin( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table WHERE email = ?";
			$res = $this->fetchData( $sql, $dt );

			return $res ?? [];
		}

		function getById( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table WHERE id = ?";
			$res = $this->fetchData( $sql, $dt );

			return $res ?? [];
		}

		function getByEmail( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table WHERE email = ?";
			$res = $this->fetchData( $sql, $dt );

			return $res ?? [];
		}

		function updateById( array $dt ) 
		{
			$sql = "UPDATE $this->table SET `password`= ? WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}

		function updateProfileById( array $dt ) 
		{
			$sql = "UPDATE $this->table SET `first_name` = ?, `last_name` = ?, `gender` = ?, `blood_grp` = ?, `dob` = ?, `phone` = ?, `email` = ?, `address` = ?, `m_status` = ?, `bp` = ?, `temp` = ?, `pr` = ?, `rr` = ?, `wt` = ?, `ht` = ? WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}

	}

?>