<?php 

	include_once( 'App.php' );
	include_once( 'Encryption.php' );

	class Appointment
	{
		//using Namespaces
		use App {
			App::__construct as private __appConst;
		}

		use Encryption;

		protected $table = '';
		const DB_TABLE = 'appointments';

		function __construct()
	 	{
			$this->__appConst();
	 		$this->table = self::DB_TABLE;
	 	}

	 	function addNew( array $dt ) 
		{	
			$sql = "INSERT INTO $this->table ( `title`, `date`, `time`, `status`,  `service`, `complain`, `patient_id` ) VALUES ( ?, ?, ?, ?, ?, ?, ? )";
			$res = $this->runQuery( $sql, $dt );
			
			return $res ?? false;	  
		}

		function getAll( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table WHERE patient_id = ? ORDER BY id DESC ";
			$res = $this->fetchAllData( $sql, $dt );

			return $res ?? [];
		}

		function getCount( array $dt ) 
		{
			$sql = "SELECT COUNT( id ) AS total FROM $this->table WHERE patient_id = ? ";
			$res = $this->fetchData( $sql, $dt );

			return $res['total'] ?? 0;
		}

		function getStatusCount( array $dt ) 
		{
			$sql = "SELECT COUNT( id ) AS total FROM $this->table WHERE patient_id = ? AND status = ? ";
			$res = $this->fetchData( $sql, $dt );

			return $res['total'] ?? 0;
		}


		function updateById( array $dt ) 
		{
			$sql = "UPDATE $this->table SET `category`= ?, `medicine`= ?, `price`= ? WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}

		function deleteById( array $dt ) 
		{
			$sql = "DELETE FROM $this->table WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}

		function getAllBySessionState( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table WHERE ( session = ? OR session = ? ) AND status = ? AND patient_id = ? ";
			$res = $this->fetchAllData( $sql, $dt );

			return $res ?? [];
		}

		function updateSessionById( array $dt ) 
		{
			$sql = "UPDATE $this->table SET `session`= ? WHERE id = ?";
			$res = $this->runQuery_2( $sql, $dt );

			return $res ?? false;
		}

		function loadMed( array $data, $sel_col = '', $column )
		{
			$options = '';

			if ( $data ) 
			{
				foreach ( $data as $dt ) 
				{
					$sel = '';
					$col = $dt[ $column ];

					if ( $sel_col == $col ) 
					{
						$sel = 'selected';
					}

					$options .= "<option value='$col' $sel >$col</option>";
				}
			}

			return $options;
		}

	}

?>