<?php 

	include_once( 'App.php' );
	include_once( 'Encryption.php' );

	class Service
	{
		//using Namespaces
		use App {
			App::__construct as private __appConst;
		}

		use Encryption;

		protected $table = '';
		const DB_TABLE = 'services';

		function __construct()
	 	{
			$this->__appConst();
	 		$this->table = self::DB_TABLE;
	 	}

		function getAll( array $dt ) 
		{
			$sql = "SELECT * FROM $this->table ";
			$res = $this->fetchAllData( $sql, $dt );

			return $res ?? [];
		}

		function getByService( array $dt ) 
		{
			$sql = "SELECT fees FROM $this->table WHERE service = ? ";
			$res = $this->fetchData( $sql, $dt );

			return $res['fees'] ?? [];
		}


		function loadServices( array $data, $sel_serv = '' )
		{
			$options = '';

			if ( $data ) 
			{
				foreach ( $data as $dt ) 
				{
					$sel = '';
					$service = $dt['service'];

					if ( $sel_serv == $service ) 
					{
						$sel = 'selected';
					}

					$options .= "<option value='$service' $sel >$service</option>";
				}
			}

			return $options;
		}

	}

?>