<?php 

  include_once( 'App.php' );
  include_once( 'Encryption.php' );

  class Payment
  {
    //using Namespaces
    use App {
      App::__construct as private __appConst;
    }

    use Encryption;

    protected $table = '';
    const DB_TABLE = 'payments';

    function __construct()
    {
      $this->__appConst();
      $this->table = self::DB_TABLE;
    }

    function addNew( array $dt ) 
    { 
      $sql = "INSERT INTO $this->table ( `patient_id`, `appointment_id`, `status` ) VALUES ( ?, ?, ? )";
      $res = $this->runQuery( $sql, $dt );
      
      return $res ?? false;   
    }

    function getByAppointmentId( array $dt ) 
    {
      $sql = "SELECT status FROM $this->table WHERE appointment_id = ? AND patient_id = ? ";
      $res = $this->fetchData( $sql, $dt );

      return $res['status'] ?? 'Unpaid';
    }

    function getAllBySessionState( array $dt ) 
    {
      $sql = "SELECT * FROM $this->table WHERE ( session = ? OR session = ? ) AND status = ? AND patient_id = ? ";
      $res = $this->fetchAllData( $sql, $dt );

      return $res ?? [];
    }

    function getPaymentStatusByPatientId( array $dt ) 
    {
      $sql = "SELECT status  FROM $this->table WHERE appointment_id = ? AND patient_id =? ";
      $res = $this->fetchData( $sql, $dt );

      return $res['status'] ?? 'Unpaid';
    }


  }


?>