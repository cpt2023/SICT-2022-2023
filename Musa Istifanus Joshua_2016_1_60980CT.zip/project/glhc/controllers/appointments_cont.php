<?php 
	//auth
	include_once( 'user_auth.php' );

	//App Functions
	include_once( 'models/Appointment.php');
	include_once( 'models/Service.php');
	include_once( 'models/Payment.php');

	//Creating Instances
	$appt = new Appointment();
	$serv = new Service();
	$payment = new Payment();

	if ( isset( $_POST['book_btn'] ) ) 
	{
		//getting inputs
		$title = $_POST['title'];
		$datetime = $_POST['datetime'];
		$service = $_POST['service'];
		$complain = $_POST['complain'];
		$meridian = $_POST['meridian'];

		//validating inputs
		if ( $title && $datetime && $service && $complain && $meridian ) 
		{
			$seperator = strpos( $datetime, 'T', 0 );
			//extract date and time
			$date = substr( $datetime, 0, $seperator ); 
			$time = substr( $datetime, $seperator + 1 ).$meridian; 

			$status = 'Pending';
			$dt_01 = [ $title, $date, $time, $status, $service, $complain, $pat_id ];

			$add_new = $appt->addNew( $dt_01 );

			if ( $add_new ) 
			{
				$msg = $web_app->showAlertMsg( 'success', ' Appointment Submitted.' ); 
				$clear = true;	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Appointment Not Submitted.' ); 		
			}				
		}
		else
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
	}

	if ( isset( $_POST['pay_btn'] ) ) 
	{
		//loadind appointment details (jquery)
		$appointment_id = $_POST['appointment_id'];
		$patient_id = $_POST['patient_id'];
		$service = $_POST['p_service'];
		$charge = $_POST['charge'];
		$schedule = $_POST['schedule'];
		$comment = $_POST['d_comment'];

		//validating details
		if ( $appointment_id && $patient_id && $service && $charge && $schedule && $comment ) 
		{
			$status = 'Paid';
			$dt_01 = [ $patient_id, $appointment_id, $status ];

			$add_payment = $payment->addNew( $dt_01 );

			if ( $add_payment ) 
			{
				$msg = $web_app->showAlertMsg( 'success', ' Your Appointment Has Been Successfully Booked.' ); 	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Appointment Not Booked.' ); 		
			}				
		}
		else
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
	}

	if ( isset( $_POST['del_btn'] ) ) 
	{
		//appointment ID
		$id = $_POST['del_appt_id'];

		if ( $id ) 
		{ 
			$dt_01 = [ $id ];

			$del_appt = $appt->deleteById( $dt_01 ) ;

			if ( $del_appt ) 
			{
				$msg = $web_app->showAlertMsg( 'success', ' Appointment Deleted.' );
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Appointment Not Deleted.' ); 		
			}				
		}
		else{
			$msg = $web_app->showAlertMsg( 'danger', 'Please, Select An Appointment.' ); 		
		}
	}

	//Fetching datas
	$appt_arr = $appt->getAll( [ $pat_id ] );
	$service_arr = $serv->getAll( [] );

	//Appointments interface
	include_once( 'views/appointments.php' );
 ?>