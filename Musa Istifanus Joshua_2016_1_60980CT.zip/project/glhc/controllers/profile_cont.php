<?php 
	//auth
	include_once( 'user_auth.php' );

	if ( isset( $_POST['edit_btn'] ) ) 
	{
		//Getting Inputs
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$gender = $_POST['gender'];
		$blood_grp = $_POST['blood_grp'];
		$dob = $_POST['dob'];
		$phn_num = $_POST['phn_num'];
		$email = $_POST['email'];
		$address = $_POST['address'];
		$status = $_POST['status'];
		$bp = $_POST['bp'];
		$temp = $_POST['temp'];
		$pr = $_POST['pr'];
		$rr = $_POST['rr'];
		$wt = $_POST['wt'];
		$ht = $_POST['ht'];

		if ( $first_name && $last_name && $gender && $blood_grp && $dob && $phn_num && $email && $address && $status && $bp && $temp && $pr && $rr && $wt && $ht ) 
		{

			$dt_01 = [ $first_name, $last_name, $gender, $blood_grp, $dob, $phn_num, $email, $address, $status,$bp, $temp, $pr, $rr, $wt, $ht, $pat_id ];

			$update_prof = $pat->updateProfileById( $dt_01 );

			if ( $update_prof ) 
			{
				$msg = $web_app->showAlertMsg( 'success', ' Profile Updated.' ); 
				$clear = true;	
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Profile Not Updated.' ); 			
			}				
			
		}
		else
		{
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter All Required Fields.' ); 	
		}
	}

	$patient_dt = $pat->getById( [ $pat_id ] );

	//Patient Datas
	$first_name = $patient_dt['first_name'];
	$last_name = $patient_dt['last_name'];
	$gender = $patient_dt['gender'];
	$blood_grp = $patient_dt['blood_grp'];
	$m_status = $patient_dt['m_status'];
	$ht = $patient_dt['ht'];
	$wt = $patient_dt['wt'];
	$rr = $patient_dt['rr'];
	$pr = $patient_dt['pr'];
	$temp = $patient_dt['temp'];
	$bp = $patient_dt['bp'];
	$age = $patient_dt['age'];
	$email = $patient_dt['email'];
	$phn_num = $patient_dt['phone'];
	$address = $patient_dt['address'];
	$dob = $patient_dt['dob'];

	//Profile interface
	include_once( 'views/profile.php' );
 ?>