<?php 
 

	//auth
	include_once( 'user_auth.php' );

	//app funtions
	include_once( 'models/Appointment.php');
	include_once( 'models/Service.php');

	//Creating instances
	$appt = new Appointment();
	$serv = new Service();

	$total_appt = $appt->getCount( [ $pat_id ] );
	$total_approved_appt = $appt->getStatusCount( [ $pat_id, 'Accepted' ] );
	$total_pending_appt = $appt->getStatusCount( [ $pat_id, 'Pending' ] );
	$total_rejected_appt = $appt->getStatusCount( [ $pat_id, 'Rejected' ] );
	$service_arr = $serv->getAll( [] );

	//Dashboard interface
	include_once( 'views/dashboard.php' );
 ?>