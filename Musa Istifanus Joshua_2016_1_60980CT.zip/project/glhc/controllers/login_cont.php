<?php    

	if ( isset( $_POST[ 'btnLogin' ] ) ) 
	{
		// Getting user inputs
		$email = $_POST[ 'email' ];
		$pword = $_POST[ 'pword' ]; 

		//Validating inputs
		if ( $email && $pword ) 
		{
			$dt_01 = [ $email ];
			$pat_dt = $pat->getLogin( $dt_01 );
			$pwordx = $pat_dt[ 'password' ] ?? '';
			
			//Match user password
			$match_pword = $pat->decPword( $pword, $pwordx );

			if ( $match_pword ) 
			{  
				$id = $pat_dt[ 'id' ];
				$_SESSION['pat_name'] = $pat_dt['first_name'].' '.$pat_dt['last_name'];

				//setting session and cookie
				$time_out = time() + APP_SESS_TIME;
				$_SESSION[ APP_SESS ] = $id;
				setcookie( APP_SESS, $id, $time_out );

				//redirect
				header( 'Location: ./dashboard', true, 301 );
				exit();
			} 
			else 
			{
				$msg = $web_app->showAlertMsg( 'danger', 'Sorry, Patient Does Not Exist!' ); 
			}
		}
		else 
		{  
			$msg = $web_app->showAlertMsg( 'info', 'Please, Enter Username And Password.' ); 	
		}
	}

	//login interface
	include_once( 'views/login.php' );
?>