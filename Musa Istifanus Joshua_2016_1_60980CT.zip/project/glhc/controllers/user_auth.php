<?php   
  
	$pat_id = $pat->getLoggedPatient();

	//when not logged in
	if ( !$pat_id ) 
	{
		header( "Location: ./", true, 301 );
		exit();
	}

?>