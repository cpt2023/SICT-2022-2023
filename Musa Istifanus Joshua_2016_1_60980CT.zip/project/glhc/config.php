<?php 

	const ENVIRONMENT = 'Test';//Test Live

   //DB Config
	const HOST = 'localhost';
	const USER = 'root';
	const PWORD = '';
	const DB = 'glhc_db';

	$msg = '';
   $msg_2 = '';
	$clear = false;

	const APP_SESS = 'patient_id';
	const APP_SESS_TIME = 5000;
	
   
	//url
   $server_name = ENVIRONMENT == 'Test' ? 'http://' : 'https://';
   $server_name .= $_SERVER['SERVER_NAME'];
   $uri = $_SERVER['REQUEST_URI'];
   $app_url = ( strlen( $uri ) > 1 ) ? "$server_name$uri" : "$server_name";
   
   //directory
   $root_dir = dirname( __DIR__ );
   $cur_dir = dirname( __FILE__ );
?> 