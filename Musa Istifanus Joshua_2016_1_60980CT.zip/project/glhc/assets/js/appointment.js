//trigger delete modal box and load appointment details 
$( document ).on( 'click', '.appt_del_btn', ( e ) => {
   const dt_set = e.target.dataset;

   $( '#del_appt_id' ).val( dt_set.id );
   $( '#del_title' ).text( dt_set.ques );
});

//trigger reason or details or payment modal box and load appointment details 

$( document ).on( 'click', '.payment_btn', ( e ) => {
   const dt_set = e.target.dataset;

   let state = dt_set.state;

   if ( state == 1 )  
   {
      $('#form-title').text('Payment Form');
      $('#pay_btn').attr( 'class', 'btn btn-lg btn-success' );
   }
   else if ( state == 2 )
   {
      $('#form-title').text('Appointment Details');
      $('#pay_btn').attr( 'class', 'd-none' );
   }
   else
   {
      $('#form-title').text('Reason');
      $('#pay_btn').attr( 'class', 'd-none' );
   }

   $( '#d_comment' ).val( dt_set.comment );
   $( '#appointment_id' ).val( dt_set.id );
   $( '#patient_id' ).val( dt_set.patient_id );
   $( '#p_service' ).val( dt_set.service );
   $( '#charge' ).val( dt_set.service_fee );
   $( '#schedule' ).val( dt_set.schedule );
});
