<footer class="footer footer-alt">
            2023 - <?php echo date ('Y');?> &copy; Digital Archieve System Dashboard.</a> 
</footer>