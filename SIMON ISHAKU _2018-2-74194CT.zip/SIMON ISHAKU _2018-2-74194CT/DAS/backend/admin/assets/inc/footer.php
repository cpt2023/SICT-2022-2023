<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                2023 - <?php echo date('Y'); ?> &copy; Digital Archieve System Dashboard.</a>
            </div>

        </div>
    </div>
</footer>