<?php
require_once 'include/config.php';
require_once 'include/functions.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   $email = sanitizeInput($_POST['email']);
    $phone = sanitizeInput($_POST['phone']);
    $password = $_POST['password'];
	$user_id=uniqid();

    $hashedPassword = hashPassword($password);

    // Check if the email is unique
    $checkEmailStmt = $conn->prepare("SELECT email FROM user_app_info WHERE email = ?");
    $checkEmailStmt->bind_param("s", $email);
    $checkEmailStmt->execute();
    $checkEmailStmt->store_result();

    if ($checkEmailStmt->num_rows > 0) {
        $_SESSION['flash_message'] = "Error: Email already exists.";
        $checkEmailStmt->close();
        header("Location: register.php"); // Redirect to registration form
        exit();
    }

    $checkEmailStmt->close();

    // Insert user data into the database
    $stmt = $conn->prepare("INSERT INTO user_app_info (user_id, email, mobile_no, password) VALUES (?, ?, ?,?)");
    $stmt->bind_param("ssss",$user_id, $email, $phone, $hashedPassword);

    if ($stmt->execute()) {
        $_SESSION['flash_message'] = "Registration successful!";
    } else {
        $_SESSION['flash_message'] = "Error during registration: " . $stmt->error;
    }

    $stmt->close();
    header("Location: register.php"); // Redirect to registration form
}

$conn->close();
?>
