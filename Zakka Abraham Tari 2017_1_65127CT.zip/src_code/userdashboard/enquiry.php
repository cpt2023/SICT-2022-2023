<?php
session_start();
include 'include/config.php';
include 'include/head.php';
///
?>

<div class="content-body">
<!-- row -->
<div class="container-fluid">

<div class="col-xl-6 col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Enquiry Form</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form>
                                    <div class="mb-3 col-md-6">
                                                <label class="form-label">Message Title</label>
                                                <input type="text" class="form-control" placeholder="Message Title">
                                            </div>
                        <div class="col-xl-6 col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Message</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form>
                                        <div class="mb-3">
                                            <textarea class="form-control" rows="12" id="comment"></textarea>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
					</div>    
                    <div class="mb-3 row">
                                            <div class="col-sm-10">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
					</div>
</div>
</div>

<?php
include 'include/footer.php';
?>