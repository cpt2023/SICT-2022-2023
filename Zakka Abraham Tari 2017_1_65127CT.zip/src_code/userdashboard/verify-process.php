<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("location: login.php");
    exit();
}
include 'include/config.php';
include 'include/head.php';
?>
<?php
$user_id=$_SESSION['user_id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = sanitizeInput($_POST['fname']);
    $lname = sanitizeInput($_POST['lname']);
    $state = sanitizeInput($_POST['state']);
    $lga = sanitizeInput($_POST['lga']);
    $address = sanitizeInput($_POST['address']);
    $dob = sanitizeInput($_POST['dob']);
    $occupation = sanitizeInput($_POST['occupation']);
    $gender = sanitizeInput($_POST['gender']);
    $nin = sanitizeInput($_POST['nin']);
    $title = sanitizeInput($_POST['title']);

$uploadedFile1 = $_FILES['image']['front'];
$tempFile1 = $_FILES['image']['tmp_name'];

// Generate a unique name for the image
$newFileName1 = uniqid() . '_' . $uploadedFile1;


// Set the path to the target directory and file
$targetFile1 = $targetDirectory . $newFileName1;

// Check if the file was successfully uploaded
if (move_uploaded_file($tempFile1, $targetFile1)) {
    // Store data in the database
    
    $sql = "UPDATE user_app_info SET first_name='$fname', last_name='$lname', title='$title', state='$state', lga='$lga', dob='$dob', current_address='$address', active_status='2', email_verify='2', phone_verify='2', address_verify='2', nin_verify='2', occupation='$occupation', gender='$gender', nin_number='$nin', nin_front='$targetFile1' WHERE user_id='$user_id'";
    if ($conn->query($sql) === TRUE) {
        echo "Data and the file $newFileName have been uploaded and stored successfully.<br>";
    } else {
        echo "Error storing data: " . $conn->error;
    }
} else {
    echo "Sorry, there was an error uploading your file.";
}
}
$conn->close();
?>


/*
function generateUniqueFilename($originalFilename){
    $timestamp=time();
    $randomString = md5(uniqid(mt_rand(),true));
    $extension = $pathinfo($originslFilename, PATHINFO_EXTENSION);
    return $timestamp.'_'.$randomString. '.' . $extension;
}
   $user_id = $_SESSION['user_id'];
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $fname = sanitizeInput($_POST['fname']);
        $lname = sanitizeInput($_POST['lname']);
        $state = sanitizeInput($_POST['state']);
        $lga = sanitizeInput($_POST['lga']);
        $address = sanitizeInput($_POST['address']);
        $dob = sanitizeInput($_POST['dob']);
        $occupation = sanitizeInput($_POST['occupation']);
        $optradio = sanitizeInput($_POST['optradio']);
        $nin = sanitizeInput($_POST['nin']);
        $title = sanitizeInput($_POST['title']);

        $image1=$_FILES["image1"]["name"];
        $image3=$_FILES["image2"]["name"];
        $image3=$_FILES["image3"]["name"];
        
        $newImage1= generateUniqueFilename($image1);
        $newImage2= generateUniqueFilename($image2);
        $newImage3= generateUniqueFilename($image3);

        move_uploaded_file($_FILES["image1"]["tmp_name"], "uploads/".$newImage1);
        move_uploaded_file($_FILES["image2"]["tmp_name"], "uploads/".$newImage2);
        move_uploaded_file($_FILES["image3"]["tmp_name"], "uploads/".$newImage3);

        $sql = "UPDATE user_app_info SET first_name='$fname',front='$newImage1', nin_back='$newImage2', nin_holder='$newImage2' WHERE user_id='$user_id'";
        
        if($conn->query($sql)===TRUE){
            echo "success";
        }
        else{
            echo "fail";
        }
    }
    $conn->close();
    ?>
*/


