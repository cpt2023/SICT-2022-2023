<?php
session_start();
include 'include/config.php';
include 'include/head.php';
?>
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="d-flex align-items-center mb-4">
					<h3 class="me-auto">User Profile</h3>
				
				</div>
				<div class="row">
					<div class="col-xl-12">
						<div class="card">
							<div class="card-header border-0 flex-wrap align-items-start">
								<div class="col-md-8">
									<div class="user d-sm-flex d-block pe-md-5 pe-0">
										<img src="images/user.jpg" alt="">
										<div class="ms-sm-3 ms-0 me-md-5 md-0">
											<h5 class="mb-1 font-w600"><a href="javascript:void(0);" class="text-black">Andrew Jonson</a></h5>
											<div class="listline-wrapper mb-2">
												<span class="item"><i class="text-primary far fa-envelope"></i>andrewjohnson@gmail.com</span>
												
												<span class="item"><i class="text-primary fas fa-map-marker-alt"></i>Niger State</span>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-md-4 col-12 text-end">	
									
									<div class="mt-3">
										<h6 class="text-start">Verification Level
											<span class="float-end">85%</span>
										</h6>
										<div class="progress ">
											<div class="progress-bar bg-danger progress-animated" style="width: 85%; height:6px;" role="progressbar">
												<span class="sr-only">60% Complete</span>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="card-body pt-0">
								<h4 class="fs-20">Description</h4>
								<div class="row">
									<div class="col-xl-6 col-md-6">
										<p class="font-w600 mb-2 d-flex"><span class="custom-label-2">Full Name : </span><span class="font-w400">Andrew Jonson</span></p>
										
										<p class="font-w600 mb-2 d-flex"><span class="custom-label-2">Current Occupation : </span><span class="font-w400">Civil Servant</span></p>
										
										
										
										<p class="font-w600 mb-2 d-flex"><span class="custom-label-2">Gender : </span><span class="font-w400">Male</span></p>
										
										
										
									</div>
									<div class="col-xl-6 col-md-6">
										
										<p class="font-w600 mb-2 d-flex"><span class="custom-label-2">Email :</span> <span class="font-w400">andrew@gmail.com</span></p>
										<p class="font-w600 mb-2 d-flex"><span class="custom-label-2">Phone : </span><span class="font-w400">08035647322</span></p>
									
										<p class="font-w600 mb-2 d-flex"><span class="custom-label-2">Date Of Birth : </span><span class="font-w400">13 June 1996</span></p>
										
										
										<p class="font-w600 mb-2 d-flex"><span class="custom-label-2">Permanent Address :</span> <span class="font-w400">House 12, London Street, Minna, Niger State</span></p>
										
									</div>
								</div>
							</div>
							<div class="card-footer d-flex flex-wrap justify-content-between align-items-center">
								
								<div>
									
									
									<a href="edit-profile.php" class="btn btn-info btn-sm me-2">Edit Profile</a>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
		
		<?php
		include 'include/footer.php';
		?>