<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("location: login.php");
    exit();
}
include 'include/config.php';
include 'include/head.php';
?>
		
		<!--**********************************
            Content body start
        ***********************************-->

	 <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="d-flex align-items-center mb-4 flex-wrap">
					<h3 class="me-auto">Account Verification</h3>
					
				</div>

				
                <div class="col-xl-6 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Basic Information</h4>
                        </div>
                        <div class="card-body">
                            <div class="basic-form">
                                <form  action="verify-process.php" method="post" enctype="multipart/form-data">

                                    <div class="row">
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label">First Name</label>
                                            <input type="text" name="fname" class="form-control" placeholder="first name">
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label">Last Name</label>
                                            <input type="text" name="lname" class="form-control" placeholder="last name" required>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label">Title</label>
                                            <select name="title" id="inputState" class="default-select form-control wide" required>
                                                <option selected>Choose...</option>
                                                <option value="mr">Mr</option>
                                                <option value="mrs">Mrs</option>
                                                <option value="others">Others</option>
                                            </select>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label">State</label>
                                            <select name="state" id="inputState" class="default-select form-control wide" required>
                                                <option selected>Choose...</option>
                                                <option value="Niger">Niger</option>
                                                <option value="Lagos">Lagos</option>
                                                <option value="FCT">Fct</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label">Local Govt Area</label>
                                            <input name="lga" type="text" class="form-control" placeholder="LGA" required>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label">Current Address</label>
                                            <input name="address" type="text" class="form-control" placeholder="adrress" required>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-xl-3 col-xxl-6 col-md-6 mb-3">
                                            <label class="form-label">Date of Birth</label>
                                            <input name="dob" type="date" class="form-control" placeholder="2017-06-04" id="mdate" required>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label">Occupation</label>
                                            <input name="occupation" type="text" class="form-control" placeholder="LGA" required>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-6">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h4 class="card-title">Gender</h4>
                                                </div>
                                                <div class="card-body">
                                                    <div class="basic-form">
                                                        
                                                            <div class="mb-3 mb-0">
                                                                <label class="radio-inline me-3"><input type="radio" value="male" name="gender" class="form-check-input"> Male</label>
                                                                <label class="radio-inline me-3"><input type="radio" value="female" name="gender" class="form-check-input"> Female</label>
                                                                
                                                            </div>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-3 col-xxl-6 col-md-6 mb-3">
                                            <label class="form-label">Front Page</label>
                                            <img  class= width="100" height="100"  src="card_front.png">
                                        </div>
                                        <div class="mb-6">
                                            <label for="formFile"  class="form-label">front image</label>
                                            <input name="front" class="form-control" type="file" id="formFile" accept="image/*" required>
                                          </div>
                                    </div>
                                    <div class="row">
                                        <div class="mb-3 col-md-6">
                                            <label class="form-label">NIN Number</label>
                                            <input type="text" name="nin" class="form-control" placeholder="Enter NIN Number">
                                        </div>
                                        
                                    </div>
                                    <div class="mb-3">
                                       
                                    </div>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
					
				
				
				
            </div>
        </div>


        <!--**********************************
            Content body end
        ***********************************-->
		
		<?php
include 'include/footer.php';
?> 