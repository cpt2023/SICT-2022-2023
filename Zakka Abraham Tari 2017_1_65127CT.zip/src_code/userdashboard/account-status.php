<?php
session_start();
include 'include/config.php';
include 'include/head.php';
///
?>
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="d-flex align-items-center mb-4">
					<h3 class="me-auto">User Status</h3>
					
				</div>
				<div class="row">
					<div class="col-xl-12">
						<div class="card">
							<div class="card-header border-0 flex-wrap align-items-start">
								<div class="col-md-8">
									<div class="user d-sm-flex d-block pe-md-5 pe-0">
										<img src="images/user.jpg" alt="">
										<div class="ms-sm-3 ms-0 me-md-5 md-0">
											<h5 class="mb-1 font-w600"><a href="javascript:void(0);" class="text-black">Andrew Jonson</a></h5>
											<div class="listline-wrapper mb-2">
												<span class="item"><i class="text-primary far fa-envelope"></i>andrewjohnson@gmail.com</span>
												
												<span class="item"><i class="text-primary fas fa-map-marker-alt"></i>Niger State</span>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-md-4 col-12 text-end">	
									
									<div class="mt-3">
										<h6 class="text-start">Verification Level
											<span class="float-end">100%</span>
										</h6>
										<div class="progress ">
											<div class="progress-bar bg-success progress-animated" style="width: 100%; height:6px;" role="progressbar">
												<span class="sr-only">100% Complete</span>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="card-body pt-0">
								<h4 class="fs-20"> </h4>
								<div class="row">
									<div class="col-xl-6 col-md-6">
										<p class="font-w600 mb-2 d-flex"><span class="custom-label-2">Prove Of Address : </span><span class="font-w400"><a href="javascript:void(0);" class="btn btn-success btn-sm me-2">Verified</a></span></p>
										
										<p class="font-w600 mb-2 d-flex"><span class="custom-label-2">Type of ID : </span><span class="font-w400">NIMC</span></p>
										
										<p class="font-w600 mb-2 d-flex"><span class="custom-label-2">Email : </span><span class="font-w400"><a href="javascript:void(0);" class="btn btn-success btn-sm me-2">Verified</a></span> <span class="font-w400">  </span></p>
										
										
										
										
										
									</div>
									<div class="col-xl-6 col-md-6">
										<p class="font-w600 mb-2 d-flex"><span class="custom-label-2">National ID:</span> <span class="font-w400"><span class="font-w400"><a href="javascript:void(0);" class="btn btn-success btn-sm me-2">Verified</a></span> </span></p>
										
										<p class="font-w600 mb-2 d-flex"><span class="custom-label-2">Phone : </span><span class="font-w400"><a href="javascript:void(0);" class="btn btn-success btn-sm me-2">Verified</a></span> <span class="font-w400">  </span></p>
									
										
										
										
										
										
									</div>
								</div>
							</div>
						
						</div>
					</div>
				</div>
            </div>
        </div>
		
        <!--**********************************
            Content body end
        ***********************************-->
		<?php
include 'include/footer.php';
?>