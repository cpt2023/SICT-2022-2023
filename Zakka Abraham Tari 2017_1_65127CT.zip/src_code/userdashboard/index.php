<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("location: login.php");
    exit();
}
include 'include/config.php';
include 'include/head.php';
?>
<?php
$id= $_SESSION['user_id'];

$bailapp;
$pendingap;
$payments;
$feedback;

$sql1= "SELECT COUNT(*) FROM bail_applications WHERE user_id = $id";
$result1= $conn->query($sql1);
$bailapp= $conn->affected_rows;

?>
<div class="content-body">
<!-- row -->
<div class="container-fluid">
        <div class="row">
        <div class="col-xl-6">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row separate-row">
                                <div class="col-sm-6">
                                    <div class="job-icon pb-4 d-flex justify-content-between">
                                        <div>
                                            <div class="d-flex align-items-center mb-1">
                                                <h2 class="mb-0 lh-1">3 </h2>
                                                
                                            </div>	
                                            <span class="fs-14 d-block mb-2">Bail Applications</span>
                                        </div>	
                                        <div id="NewCustomers"></div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="job-icon pb-4 pt-4 pt-sm-0 d-flex justify-content-between">
                                        <div>
                                            <div class="d-flex align-items-center mb-1">
                                                <h2 class="mb-0 lh-1">2</h2>
                                            </div>	
                                            <span class="fs-14 d-block mb-2">Pending Applications</span>
                                        </div>	
                                        <div id="NewCustomers1"></div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="job-icon pt-4 pb-sm-0 pb-4 pe-3 d-flex justify-content-between">
                                        <div>
                                            <div class="d-flex align-items-center mb-1">
                                                <h2 class="mb-0 lh-1">0</h2>
                                                
                                            </div>	
                                            <span class="fs-14 d-block mb-2">Payments</span>
                                        </div>	
                                        <div id="NewCustomers2"></div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="job-icon pt-4  d-flex justify-content-between">
                                        <div>
                                            <div class="d-flex align-items-center mb-1">
                                                <h2 class="mb-0 lh-1">1</h2>
                                            </div>	
                                            <span class="fs-14 d-block mb-2">Bail Feedbacks</span>
                                        </div>	
                                        <div id="NewCustomers3"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                                            <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header border-0 pb-0">
                            <h4 class="fs-20 mb-0">Recent Activity</h4>
                        
                        </div>
                        <div class="card-body loadmore-content dlab-scroll height370 recent-activity-wrapper" id="RecentActivityContent">
                            <div class="d-flex recent-activity">
                                <span class="me-3 activity">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17">
                                      <circle  cx="8.5" cy="8.5" r="8.5" fill="#f93a0b"/>
                                    </svg>
                                </span>
                                <div class="d-flex align-items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="71" height="71" viewBox="0 0 71 71">
                                      <g  transform="translate(-457 -443)">
                                        <rect  width="71" height="71" rx="12" transform="translate(457 443)" fill="#c5c5c5"/>
                                        <g  transform="translate(457 443)">
                                          <rect  data-name="placeholder" width="71" height="71" rx="12" fill="#2769ee"/>
                                          <circle  data-name="Ellipse 12" cx="18" cy="18" r="18" transform="translate(15 20)" fill="#fff"/>
                                          <circle  data-name="Ellipse 11" cx="11" cy="11" r="11" transform="translate(36 15)" fill="#ffe70c" style="mix-blend-mode: multiply;isolation: isolate"/>
                                        </g>
                                      </g>
                                    </svg>
                                    <div class="ms-3">
                                        <h5 class="mb-1">Bail Application Filled for James Carson, Case Number NFP2023/10/1/48.</h5>
                                        <span>8min ago</span>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex recent-activity">
                                <span class="me-3 activity">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17">
                                      <circle  cx="8.5" cy="8.5" r="8.5" fill="#d9d9d9"/>
                                    </svg>
                                </span>
                                <div class="d-flex align-items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="71" height="71" viewBox="0 0 71 71">
                                          <g  transform="translate(-457 -443)">
                                            <rect  width="71" height="71" rx="12" transform="translate(457 443)" fill="#c5c5c5"/>
                                            <g  transform="translate(457 443)">
                                              <rect  data-name="placeholder" width="71" height="71" rx="12" fill="#eeac27"/>
                                              <circle  data-name="Ellipse 12" cx="18" cy="18" r="18" transform="translate(15 20)" fill="#fff"/>
                                              <circle  data-name="Ellipse 11" cx="11" cy="11" r="11" transform="translate(36 15)" fill="#ffe70c" style="mix-blend-mode: multiply;isolation: isolate"/>
                                            </g>
                                          </g>
                                    </svg>
                                    <div class="ms-3">
                                        <h5 class="mb-1">Bail Bond Paid for Case Number NFP2023/10/6/67, Ref No:2023/10/9ADR/1, sum of 5 million Naira.</h5>
                                        <span>55min ago</span>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex recent-activity">
                                <span class="me-3 activity">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17">
                                      <circle  cx="8.5" cy="8.5" r="8.5" fill="#d9d9d9"/>
                                    </svg>
                                </span>
                                <div class="d-flex align-items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="71" height="71" viewBox="0 0 71 71">
                                          <g  transform="translate(-457 -443)">
                                            <rect  width="71" height="71" rx="12" transform="translate(457 443)" fill="#c5c5c5"/>
                                            <g  transform="translate(457 443)">
                                              <rect  data-name="placeholder" width="71" height="71" rx="12" fill="#22bc32"/>
                                              <circle  data-name="Ellipse 12" cx="18" cy="18" r="18" transform="translate(15 20)" fill="#fff"/>
                                              <circle  data-name="Ellipse 11" cx="11" cy="11" r="11" transform="translate(36 15)" fill="#ffe70c" style="mix-blend-mode: multiply;isolation: isolate"/>
                                            </g>
                                          </g>
                                    </svg>
                                    <div class="ms-3">
                                        <h5 class="mb-1">Bail Application Filled for Thomas Davis, Case Number NFP2023/104/1/648.</h5>
                                        <span>2 months ago</span>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex recent-activity">
                                <span class="me-3">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17">
                                      <circle  cx="8.5" cy="8.5" r="8.5" fill="#d9d9d9"/>
                                    </svg>
                                </span>
                                <div class="d-flex align-items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="71" height="71" viewBox="0 0 71 71">
                                          <g  transform="translate(-457 -443)">
                                            <rect  width="71" height="71" rx="12" transform="translate(457 443)" fill="#c5c5c5"/>
                                            <g  transform="translate(457 443)">
                                              <rect  data-name="placeholder" width="71" height="71" rx="12" fill="#9933cb"/>
                                              <circle  data-name="Ellipse 12" cx="18" cy="18" r="18" transform="translate(15 20)" fill="#fff"/>
                                              <circle  data-name="Ellipse 11" cx="11" cy="11" r="11" transform="translate(36 15)" fill="#ffe70c" style="mix-blend-mode: multiply;isolation: isolate"/>
                                            </g>
                                          </g>
                                    </svg>
                                <div class="ms-3">
                                    <h5 class="mb-1">Bail Fine Paid for Case Number:2023/8/34AD/2, Refercence Number:330/WD/345, Sum of Two Hundred Thousand Naira.</h5>
                                    <span>4 months ago</span>
                                </div>
                                </div>
                            </div>
                        
                        </div>
                



        
    </div>	
</div>
</div>

///


<?php
include 'include/footer.php';
?>