
<?php
session_start();
include 'include/config.php';
include 'include/head.php';
?>
<div class="content-body">
	<!-- row -->
	<div class="container-fluid">
		<div class="d-flex align-items-center mb-4 flex-wrap">
			<h3 class="me-auto">Bail Application</h3>
			
		</div>
		<div class="col-xl-6 col-lg-12">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title">Bail Parameter</h4>
				</div>
				<div class="card-body">
					<div class="basic-form">
						<form>
							<div class="row">
								<div class="mb-3 col-md-6">
									<label class="form-label">Search Name</label>
									<input type="text" class="form-control" placeholder="Enter Name">
								</div>
								 <div class="input-group">
											<span class="input-group-text">Enter Age Range</span>
											<input type="text" class="form-control">
											<input type="text" class="form-control">
										</div>
							</div>
							
							
   
							<div class="row">
								<div class="col-xl-6 col-lg-6">
									<div class="card">
										<div class="card-header">
											<h4 class="card-title">Gender</h4>
										</div>
										<div class="card-body">
											<div class="basic-form">
												<form>
													<div class="mb-3 mb-0">
														<label class="radio-inline me-3"><input type="radio" name="optradio" class="form-check-input"> Male</label>
														<label class="radio-inline me-3"><input type="radio" name="optradio" class="form-check-input"> Female</label>
														
													</div>
												</form>
											</div>
										</div>
									</div>
								</div> 
							</div>

							<div class="row">
								<div class="mb-3 col-md-6">
									<label class="form-label">Station Location</label>
									<select id="inputState" class="default-select form-control wide">
										<option selected>Choose...</option>
										<option>Niger</option>
										<option>Fct</option>
										<option>Kaduna</option>
									</select>
								</div>
								<div class="mb-3 col-md-6">
									<label class="form-label">L.G.A</label>
									<select id="inputState" class="default-select form-control wide">
										<option selected>Choose...</option>
										<option>Niger</option>
										<option>Lagos</option>
										<option>Fct</option>
									</select>
								</div>
							</div>
							<div class="mb-3">
							   
							</div>
							<button type="submit" class="btn btn-primary">Submit</button>
						</form>
					</div>
				</div>
			</div>
		</div>
			
		
		
		
	</div>
</div>
<?php
include 'include/footer.php';
?>