<?php
session_start();
require_once 'include/config.php';
require_once 'include/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitizeInput($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT user_id, password FROM station_users WHERE user_id = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($email, $hashedPassword);
    $stmt->fetch();
    $stmt->close();

    if ($email && verifyPassword($password, $hashedPassword)) {
	$_SESSION['email']=$email;
        $_SESSION['flash_message'] = "Login successful!";
        header("Location: index.php");
    } else {
        $_SESSION['flash_message'] = "Invalid username or password!";
        header("Location: login.php");   
    }

     // Redirect to login form
}

$conn->close();
?>
