<?php
session_start();
include 'include/config.php';
include 'include/head.php';

?>
<div class="content-body">
<!-- row -->
<div class="container-fluid">
        <div class="row">
        <div class="col-xl-6">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row separate-row">
                	
                             				
                               	<div class="col-xl-3 col-xxl-6 col-lg-6 col-sm-6">
						<div class="widget-stat card bg-info">
							<div class="card-body p-4">
								<div class="media">
									<span class="me-3">
										<i class="flaticon-381-heart"></i>
									</span>
									<div class="media-body text-white text-end">
										<p class="mb-1">Total Defendants</p>
										<h3 class="text-white">56</h3>
									</div>
								</div>
							</div>
						</div>
                    </div>
                
					
					
					
					

                            </div>
                        </div>
                    </div>
                    
                </div>
                                            <div class="col-xl-12">        
    </div>	
</div>
</div>

<?php
include 'include/footer.php';
?>