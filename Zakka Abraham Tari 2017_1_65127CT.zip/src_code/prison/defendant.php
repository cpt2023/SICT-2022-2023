<?php
session_start();
include 'include/config.php';
include 'include/head.php';

?>

<div class="content-body">
            <div class="container-fluid">
				
				<div class="row page-titles">
					<ol class="breadcrumb">
						<li class="breadcrumb-item active"><a href="javascript:void(0)">Prison</a></li>
						<li class="breadcrumb-item"><a href="javascript:void(0)">Defendant</a></li>
					</ol>
                </div>
                <!-- row -->


                <div class="row">
					<div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Defendants</h4>
                                
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example5" class="display" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>
													<div class="form-check custom-checkbox ms-0">
														<input type="checkbox" class="form-check-input" id="checkAll" required="">
														<label class="form-check-label" for="checkAll"></label>
													</div>
												</th>
                                                <th>Name</th>
                                                <th>Age</th>
                                                 <th>Status</th> 
                                                 <th>Contact Phone</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
												<td>
													<div class="form-check custom-checkbox ms-2">
														<input type="checkbox" class="form-check-input" id="customCheckBox20" required="">
														<label class="form-check-label" for="customCheckBox20"></label>
													</div>
												</td>
                                                <td>John Tinubu</td>
                                                <td>56</td>
                                                 <td>
                                                    <span class="badge light badge-danger">
														<i class="fa fa-circle text-danger me-1"></i>
														In Custody
													</span>
                                                </td>
                                                <td>08048294502</td>
												<td>
													<div class="dropdown ms-auto text-end">
														<div class="btn-link" data-bs-toggle="dropdown">
															<svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><rect x="0" y="0" width="24" height="24"></rect><circle fill="#000000" cx="5" cy="12" r="2"></circle><circle fill="#000000" cx="12" cy="12" r="2"></circle><circle fill="#000000" cx="19" cy="12" r="2"></circle></g></svg>
														</div>
														<div class="dropdown-menu dropdown-menu-end">
															<a class="dropdown-item" href="#">View Details</a>
                                                            
														</div>
													</div>
												</td>
                                            </tr>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
				</div>
            </div>
        </div>
<?php
include 'include/footer.php';
?>


 <!-- Modal -->
 <div class="modal fade" id="basicModal">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">User Form</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Register Users</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form>

                                        <div class="row">
                                            <div class="mb-3 col-md-6">
                                                <label class="form-label">Name</label>
                                                <input type="text" class="form-control">
                                            </div>
                                            
                                            <div class="mb-3 col-md-6">
                                                <label class="form-label">Age</label>
                                                <input type="number" class="form-control">
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label class="form-label">Address</label>
                                                <input type="text" class="form-control">
                                            </div>
                                         </div>
                                        
                                        <div class="row">
                                            <div class="mb-3 col-md-6">
                                                <label class="form-label">State</label>
                                                <select id="inputState" class="default-select form-control wide">
                                                    <option selected>Choose...</option>
                                                    <option>Option 1</option>
                                                    <option>Option 2</option>
                                                    <option>Option 3</option>
                                                </select>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label class="form-label">L.G.A</label>
                                                <select id="inputState" class="default-select form-control wide">
                                                    <option selected>Choose...</option>
                                                    <option>Option 1</option>
                                                    <option>Option 2</option>
                                                    <option>Option 3</option>
                                                </select>
                                            </div>
                                            
                                        </div>

                                        <div class="row">
                                            <div class="mb-3 col-md-6">
                                                <label class="form-label">Mobile Number</label>
                                                <input type="text" class="form-control">
                                            </div>
                                            
                                            <div class="mb-3 col-md-6">
                                                <label class="form-label">Occupation</label>
                                                <input type="number" class="form-control">
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label class="form-label">Contact Name</label>
                                                <input type="text" class="form-control">
                                            </div>
                                         </div>

                                         <div class="row">
                                            <div class="mb-3 col-md-6">
                                                <label class="form-label">Contact Address</label>
                                                <input type="text" class="form-control">
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label class="form-label">Contact Mobile Number</label>
                                                <input type="text" class="form-control">
                                            </div>
                                         </div>


                                     
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>