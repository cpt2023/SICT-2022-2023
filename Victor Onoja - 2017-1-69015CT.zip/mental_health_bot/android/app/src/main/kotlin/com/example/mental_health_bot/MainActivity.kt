package com.example.mental_health_bot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
