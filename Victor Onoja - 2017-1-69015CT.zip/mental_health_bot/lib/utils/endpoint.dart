class Endpoints {
  Endpoints();

  static const String baseUrl = 'https://api.openai.com/v1/';

  static const String chat = 'chat/completions';
}
