part of 'chat_bloc.dart';

abstract class ChatEvent extends Equatable {}

class SendMessageEvent extends ChatEvent {
  final String content;
  SendMessageEvent({required this.content});

  @override
  List<Object?> get props => [content];
}
