import 'dart:async';
import 'dart:developer';

import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mental_health_bot/core/repository/api_service.dart';
import 'package:mental_health_bot/models/message.dart';

part 'chat_state.dart';
part 'chat_event.dart';

class ChatBloc extends Bloc<ChatEvent, ChatState> {
  final ApiRepository apiRepository;

  ChatBloc({required this.apiRepository}) : super(ChatInitialState()) {
    on<SendMessageEvent>(_handleSendMessage);
  }

  Future<void> _handleSendMessage(
    SendMessageEvent event,
    Emitter<ChatState> emit,
  ) async {
    try {
      emit(ChatLoadingState());

      _messageList.add(Message(
          content: event.content, isUser: true, timeSent: DateTime.now()));
      _chatController.add(_messageList);

      final response = await apiRepository.sendMessage(event.content);
      _messageList.add(response);
      _chatController.add(_messageList);

      emit(ChatIdleState());
    } catch (e) {
      ChatErrorState(error: e.toString());
      log("Failed to send message", error: e);
    }
  }

  final _messageList = <Message>[];
  final _chatController = StreamController<List<Message>>.broadcast();

  Stream<List<Message>> messages() => _chatController.stream;
}
