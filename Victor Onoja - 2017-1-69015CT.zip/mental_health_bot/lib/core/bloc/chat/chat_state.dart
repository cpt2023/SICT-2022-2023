part of 'chat_bloc.dart';

abstract final class ChatState extends Equatable {}

final class ChatInitialState extends ChatState {
  @override
  List<Object?> get props => [];
}

final class ChatRecievedState extends ChatState {
  ChatRecievedState({required this.message});
  final Message message;

  @override
  List<Object?> get props => [message];
}

final class ChatLoadingState extends ChatState {
  @override
  List<Object?> get props => [];
}

final class ChatIdleState extends ChatState {
  @override
  List<Object?> get props => [];
}

final class ChatErrorState extends ChatState {
  @override
  List<Object?> get props => [error];

  final String error;
  ChatErrorState({required this.error});
}
