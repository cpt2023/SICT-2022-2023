import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:mental_health_bot/core/bloc/auth/auth_state.dart';
import 'package:mental_health_bot/screens/login/login_screen.dart';

class AuthBloc extends Cubit<AuthState> {
  AuthBloc() : super(AuthInitialState());

  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  void login() async {
    emit(AuthLoadingState());

    try {
      // select google account
      final userAccount = await _googleSignIn.signIn();

      // user dismissed the account dialog
      if (userAccount == null) {
        emit(AuthInitialState()); // Reset state to initial state
        return;
      }

      // get authentication object from account
      final GoogleSignInAuthentication googleAuth =
          await userAccount.authentication;

      // create OAuthCredentials from auth object
      final credential = GoogleAuthProvider.credential(
          accessToken: googleAuth.accessToken, idToken: googleAuth.idToken);

      // login to firebase using credentials
      final userCredential = await _auth.signInWithCredential(credential);

      // add a new document for the user in users collection if it doesn't already exists
      _firestore.collection('users').doc(userCredential.user!.uid).set({
        'uid': userCredential.user!.uid,
        'email': userCredential.user!.email,
      }, SetOptions(merge: true));

      emit(AuthSuccessState(userCredential.user!));
    } catch (e) {
      emit(AuthFailedState(e.toString()));
      log("Failed to login", error: e);
    }
  }

  void logout(BuildContext context) async {
    try {
      await FirebaseAuth.instance.signOut();

      await GoogleSignIn().signOut();

      // Navigate to the login screen using MaterialPageRoute
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const LoginScreen()),
      );

      // emit(AuthSuccessState(userCredential.user!));
    } catch (e) {
      emit(AuthFailedState(e.toString()));
      log("Failed to logout", error: e);
    }
  }
}
