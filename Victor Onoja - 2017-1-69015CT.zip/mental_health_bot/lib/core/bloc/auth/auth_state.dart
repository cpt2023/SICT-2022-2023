import 'package:firebase_auth/firebase_auth.dart';

abstract class AuthState {}

class AuthInitialState extends AuthState {}

class AuthLoadingState extends AuthState {}

class AuthSuccessState extends AuthState {
  final User user;
  AuthSuccessState(this.user);
}

class AuthFailedState extends AuthState {
  final String error;
  AuthFailedState(this.error);
}
