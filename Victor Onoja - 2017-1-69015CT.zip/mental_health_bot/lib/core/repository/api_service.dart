// 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

// 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

import 'dart:convert';
import 'dart:developer';

import 'package:http/http.dart' as http;
import 'package:mental_health_bot/models/message.dart';
import 'package:mental_health_bot/utils/endpoint.dart';

class ApiRepository {
  Future<Message> sendMessage(String message) async {
    final response =
        await http.post(Uri.parse("${Endpoints.baseUrl}${Endpoints.chat}"),
            headers: {
              'Content-Type': 'application/json',
              'Authorization':
                  'Bearer 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'
            },
            body: json.encode({
              "model": "gpt-3.5-turbo",
              "messages": [
                {
                  "role": "system",
                  "content":
                      "You are a mental health professional support, you will only respond to mental health related questions or issues, you know nothing else. You will give tips and guide for mental issues"
                },
                {"role": "user", "content": message},
                {
                  "role": "system",
                  "content":
                      "You are a mental health professional support, you will only respond to mental health related questions or issues, you know nothing else. You will give tips and guide for mental issues."
                }
              ],
              "temperature": 0.2
            }));

    final decodedResponse = json.decode(response.body);

    log("Res $decodedResponse");

    if (response.statusCode != 200) {
      throw Exception("Failed to post message");
    }

    final botResponse = decodedResponse['choices'][0]['message']['content'];

    return Message(
        content: botResponse, isUser: false, timeSent: DateTime.now());
  }
}
