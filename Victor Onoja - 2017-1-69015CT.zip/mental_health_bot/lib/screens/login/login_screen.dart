import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mental_health_bot/core/bloc/auth/auth_bloc.dart';
import 'package:mental_health_bot/core/bloc/auth/auth_state.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Image.asset(
            'lib/assets/images/steptodown.com131802.jpg',
            width: 200,
            height: 200,
          ),
          const Text(
            'MindMate',
            style: TextStyle(
                color: Colors.black,
                fontSize: 32,
                fontFamily: 'LionelTextDiesel'),
            textAlign: TextAlign.center,
          ),
          const Text(
            'A Mental Health Assistant Chatbot',
            style: TextStyle(
              color: Colors.black,
              fontSize: 18,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 5),
          const Text(
            'Developed by Victor Onoja.\nDepartment of Computer Science Futminna.',
            style: TextStyle(
                color: Colors.black, fontSize: 14, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          const SizedBox(
            height: 50,
          ),
          BlocConsumer<AuthBloc, AuthState>(
              builder: ((context, state) {
                return ElevatedButton(
                    style: ButtonStyle(
                        backgroundColor:
                            MaterialStateProperty.all<Color>(Color(0xFF503424)),
                        fixedSize:
                            MaterialStateProperty.all<Size>(Size(200, 50))),
                    onPressed: state is AuthLoadingState
                        ? null
                        : () {
                            context.read<AuthBloc>().login();
                          },
                    child: state is AuthLoadingState
                        ? const CircularProgressIndicator(
                            color: Colors.white,
                          )
                        : const Text(
                            'Login with Google',
                            style: TextStyle(color: Colors.white),
                          ));
              }),
              listener: ((context, state) {}))
        ]),
      ),
    );
  }
}
