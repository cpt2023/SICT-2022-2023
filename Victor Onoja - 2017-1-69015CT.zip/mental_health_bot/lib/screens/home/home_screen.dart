import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:mental_health_bot/components/custom_suggestion_button.dart';
import 'package:mental_health_bot/components/nav_drawer.dart';
import 'package:mental_health_bot/core/bloc/auth/auth_bloc.dart';
import 'package:mental_health_bot/core/bloc/chat/chat_bloc.dart';
import 'package:mental_health_bot/core/repository/api_service.dart';
import 'package:mental_health_bot/models/message.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late TextEditingController textEditingController;
  late ScrollController _scrollController;

  @override
  void initState() {
    textEditingController = TextEditingController();
    _scrollController = ScrollController();
    super.initState();
  }

  @override
  void dispose() {
    textEditingController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
          ChatBloc(apiRepository: context.read<ApiRepository>()),
      child: BlocBuilder<ChatBloc, ChatState>(
        builder: (context, state) => Scaffold(
          drawer: NavDrawer(),
          appBar: const _ChatAppBar(),
          backgroundColor: const Color(0xFFf8f4f4),
          body: Column(
            children: [
              Expanded(
                child: StreamBuilder<List<Message>>(
                    stream: context.read<ChatBloc>().messages(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return SingleChildScrollView(
                          child: Center(
                            // A placeholder widget when there are no messages
                            child: Column(
                              children: [
                                const SizedBox(
                                  height: 10,
                                ),
                                const Text(
                                  'Mental Health',
                                  style: TextStyle(
                                      color: Color(0xFF503424),
                                      fontSize: 50,
                                      fontFamily: 'LionelTextDiesel'),
                                ),
                                const Text(
                                  'AI Chatbot.',
                                  style: TextStyle(
                                      color: Color(0xFF9db16b),
                                      fontSize: 45,
                                      fontFamily: 'LionelTextDiesel'),
                                ),
                                const Text(
                                  'Developed by Victor Onoja.\nDepartment of Computer Science Futminna.',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: 50),
                                Column(
                                  children: [
                                    const Text(
                                      "Here are some suggestions",
                                      style: TextStyle(fontSize: 16),
                                    ),
                                    CustomSuggestionButton(
                                      buttonText1:
                                          'How can I manage stress better?',
                                      buttonText2:
                                          'Tell me more about coping with anxiety.',
                                      onButtonPressed: (text) {
                                        textEditingController.text = text;
                                      },
                                    ),
                                    CustomSuggestionButton(
                                      buttonText1:
                                          'Share tips for improving my mood.',
                                      buttonText2:
                                          'What strategies work for dealing with depression?',
                                      onButtonPressed: (text) {
                                        textEditingController.text = text;
                                      },
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      }
                      return ListView.builder(
                        controller: _scrollController,
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        itemCount: snapshot.data?.length,
                        itemBuilder: (context, index) {
                          final message = snapshot.data![index];

                          return Align(
                            alignment: message.isUser
                                ? Alignment.centerRight
                                : Alignment.centerLeft,
                            child: Container(
                                decoration: BoxDecoration(
                                  color: message.isUser
                                      ? const Color(0xFF503424)
                                      : const Color(0xFFe8ddd9),
                                  borderRadius: BorderRadius.circular(15)
                                      .copyWith(
                                          bottomRight: message.isUser
                                              ? Radius.zero
                                              : null,
                                          bottomLeft: !message.isUser
                                              ? Radius.zero
                                              : null),
                                ),
                                padding: const EdgeInsets.all(10),
                                margin: const EdgeInsets.all(15),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Icon(
                                      message.isUser
                                          ? Icons.person
                                          : Icons.android,
                                      color: message.isUser
                                          ? Colors.white
                                          : Colors.black,
                                      size: 40,
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      message.content,
                                      style: TextStyle(
                                        color: message.isUser
                                            ? Colors.white
                                            : Colors.black,
                                        fontSize: 18,
                                      ),
                                      textAlign: TextAlign.left,
                                    ),
                                  ],
                                )),
                          );
                        },
                      );
                    }),
              ),
              if (state is ChatLoadingState) ...[
                const SpinKitThreeBounce(
                  color: Color(0xFF503424),
                  size: 18,
                ),
                const SizedBox(
                  height: 2,
                ),
              ],
              Container(
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.all(15),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          keyboardType: TextInputType.text,
                          textInputAction: TextInputAction.done,
                          style: const TextStyle(color: Colors.black),
                          controller: textEditingController,
                          maxLines: null,
                          onSubmitted: (value) {
                            // context.read<ChatBloc>().add(
                            //       SendMessageEvent(
                            //         content: textEditingController.text,
                            //       ),
                            //     );
                            // textEditingController.clear();
                          },
                          decoration: InputDecoration(
                            hintText: 'Hello, how can I help you?',
                            hintStyle: const TextStyle(color: Colors.black38),
                            filled: true,
                            fillColor: const Color(0xFFf8f4f4),
                            contentPadding: const EdgeInsets.symmetric(
                                horizontal: 16.0, vertical: 12.0),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0),
                              borderSide: BorderSide.none,
                            ),
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          if (textEditingController.text.isEmpty) {
                          } else {
                            context.read<ChatBloc>().add(
                                  SendMessageEvent(
                                    content: textEditingController.text,
                                  ),
                                );
                            textEditingController.clear();

                            // Scroll to the bottom with animation
                            _scrollController.animateTo(
                              _scrollController.position.maxScrollExtent,
                              duration: const Duration(milliseconds: 500),
                              curve: Curves.easeInOut,
                            );
                          }
                        },
                        icon: const CircleAvatar(
                          backgroundColor: Color(0xFF503424),
                          radius: 20,
                          child: Icon(
                            Icons.send,
                            color: Colors.white,
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ChatAppBar extends StatelessWidget implements PreferredSizeWidget {
  const _ChatAppBar({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return AppBar(
      iconTheme: const IconThemeData(color: Colors.black),
      backgroundColor: Colors.white,
      surfaceTintColor: Colors.white,
      title: const Text(
        'New chat',
        style: TextStyle(color: Colors.black),
      ),
      centerTitle: true,
      // leading: IconButton(
      //   icon: const Icon(
      //     Icons.menu,
      //     color: Colors.white,
      //   ), // The menu icon
      //   onPressed:
      //       () {}, // An empty method that can be replaced with custom functionality
      // ),
      actions: [
        Container(
          padding: const EdgeInsets.only(right: 10),
          child: PopupMenuButton(
            surfaceTintColor: Colors.white,
            child: const Icon(
              Icons.more_vert,
              color: Colors.black,
            ),
            onSelected: (value) {
              if (value == "profile") {
                // add desired output
              } else if (value == "settings") {
                // add desired output
              } else if (value == "logout") {
                // add desired output
              }
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry>[
              PopupMenuItem(
                child: Row(
                  children: [
                    const Padding(
                      padding: EdgeInsets.only(right: 8.0),
                      child: Icon(Icons.person, color: Colors.black),
                    ),
                    Text(
                      FirebaseAuth.instance.currentUser!.email!,
                      style: const TextStyle(fontSize: 15),
                    ),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: "settings",
                child: Row(
                  children: [
                    Padding(
                      padding: EdgeInsets.only(right: 8.0),
                      child: Icon(
                        Icons.settings,
                        color: Colors.black,
                      ),
                    ),
                    Text(
                      'Settings',
                      style: TextStyle(fontSize: 15),
                    ),
                  ],
                ),
              ),
              PopupMenuItem(
                value: "logout",
                child: const Row(
                  children: [
                    Padding(
                      padding: EdgeInsets.only(right: 8.0),
                      child: Icon(
                        Icons.logout,
                        color: Colors.black,
                      ),
                    ),
                    Text(
                      'Logout',
                      style: TextStyle(fontSize: 15),
                    ),
                  ],
                ),
                onTap: () async {
                  context.read<AuthBloc>().logout(context);
                },
              ),
            ],
          ),
        )
      ],
    );
  }

  @override
  Size get preferredSize => AppBar().preferredSize;
}
