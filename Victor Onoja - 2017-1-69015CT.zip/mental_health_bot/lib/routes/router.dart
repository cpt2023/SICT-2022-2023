// import 'package:flutter/material.dart';

// class CustomRouter {
//   static late GoRouter _router;

//   static void setupRouter() {
//     _router = GoRouter(
//       navigatorKey: GlobalKey<NavigatorState>(),
//       initialLocation: '/login',
//       navigatorBuilder: (context, state, action, navigator) {
//         // Customize your navigator here if needed
//         return navigator(state, action);
//       },
//       initialNavigator: (context) {
//         // Optionally, you can return a custom initial navigator
//         return Navigator(onGenerateRoute: (settings) {
//           return MaterialPageRoute(builder: (context) => const LoginScreen());
//         });
//       },
//       builder: (BuildContext context, GoRouterState state) {
//         return Navigator(
//           key: state.navigatorKey,
//           pages: [
//             MaterialPage(child: const LoginScreen(), path: '/login'),
//             if (state.matches('/home'))
//               MaterialPage(
//                 child: const HomeScreen(),
//                 path: '/home',
//                 onPopPage: (route, result) => route.didPop(result),
//               ),
//           ],
//         );
//       },
//     );
//   }

//   static void navigateToHome(BuildContext context) {
//     _router.go('/home');
//   }

//   static void navigateBack(BuildContext context) {
//     _router.pop();
//   }

//   static void navigateToLogin(BuildContext context) {
//     _router.go('/login');
//   }

//   static Future<void> replaceWithHome(BuildContext context) async {
//     await _router.go('/home', replaceCurrent: true);
//   }

//   static Future<void> replaceWithLogin(BuildContext context) async {
//     await _router.go('/login', replaceCurrent: true);
//   }
// }
