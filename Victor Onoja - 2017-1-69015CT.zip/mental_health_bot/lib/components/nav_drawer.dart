import 'package:flutter/material.dart';
import 'package:mental_health_bot/screens/home/home_screen.dart';

class NavDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.70,
      child: Drawer(
        child: Container(
          color: Color(0xFFf8f4f4),
          child: ListView(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black,
                  ),
                  child: const Row(
                    children: [
                      Icon(
                        Icons.add,
                        size: 22,
                        color: Colors.white,
                      ),
                      Text(
                        "New",
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      )
                    ],
                  ),
                ),
              ),
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(10.0),
                  child: Text(
                    "Message history",
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              ListTile(
                title: const Text('Chat conversation 1'),
                textColor: Colors.black,
                trailing: const Icon(
                  Icons.chat_bubble_outline,
                  color: Colors.black,
                ),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const HomeScreen())),
              ),
              ListTile(
                title: const Text('Chat conversation 2'),
                textColor: Colors.black,
                trailing: const Icon(
                  Icons.chat_bubble_outline,
                  color: Colors.black,
                ),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const HomeScreen())),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
