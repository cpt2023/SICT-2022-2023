import 'package:flutter/material.dart';

class UserMessageWidget extends StatelessWidget {
  final String content;

  const UserMessageWidget(this.content);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.blue, // Customize as needed
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Text(
          content,
          style: TextStyle(color: Colors.white, fontSize: 18),
        ),
      ),
    );
  }
}

class BotMessageWidget extends StatelessWidget {
  final String content;

  const BotMessageWidget(this.content);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.green, // Customize as needed
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Text(
          content,
          style: TextStyle(color: Colors.white, fontSize: 18),
        ),
      ),
    );
  }
}
