import 'package:equatable/equatable.dart';
import 'package:mental_health_bot/models/message.dart';

class Conversation extends Equatable {
  final String id;
  final String name;
  final DateTime lastMessageTime;
  final List<Message> messages;

  const Conversation({
    required this.id,
    required this.name,
    required this.lastMessageTime,
    required this.messages,
  });

  Conversation copyWith({
    String? id,
    String? name,
    DateTime? lastMessageTime,
    List<Message>? messages,
  }) {
    return Conversation(
      id: id ?? this.id,
      name: name ?? this.name,
      lastMessageTime: lastMessageTime ?? this.lastMessageTime,
      messages: messages ?? List.from(this.messages),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'lastMessageTime': lastMessageTime.toIso8601String(),
      'messages': messages.map((message) => message.toMap()).toList(),
    };
  }

  factory Conversation.fromMap(Map<String, dynamic> map) {
    return Conversation(
      id: map['id'] as String,
      name: map['name'] as String,
      lastMessageTime: DateTime.parse(map['lastMessageTime'] as String),
      messages: List<Message>.from(
        (map['messages'] as List<dynamic>)
            .map<Message>((e) => Message.fromMap(e as Map<String, dynamic>)),
      ),
    );
  }

  @override
  List<Object> get props => [id, name, lastMessageTime, messages];
}
