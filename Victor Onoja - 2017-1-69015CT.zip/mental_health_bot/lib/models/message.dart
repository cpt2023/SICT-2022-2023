import 'package:equatable/equatable.dart';

class Message extends Equatable {
  final String content;
  final bool isUser;
  final DateTime timeSent;

  const Message({
    required this.content,
    required this.isUser,
    required this.timeSent,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'content': content,
      'isUser': isUser,
      'timeSent': timeSent.toIso8601String(),
    };
  }

  factory Message.fromMap(Map<String, dynamic> map) {
    return Message(
      content: map['content'] as String,
      isUser: map['isUser'] as bool,
      timeSent: DateTime.parse(map['timeSent'] as String),
    );
  }

  Message copyWith({
    String? content,
    bool? isUser,
    DateTime? timeSent,
  }) {
    return Message(
      content: content ?? this.content,
      isUser: isUser ?? this.isUser,
      timeSent: timeSent ?? this.timeSent,
    );
  }

  @override
  bool? get stringify => true;

  @override
  List<Object> get props => [content, isUser, timeSent];
}
