import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.preprocessing.sequence import TimeseriesGenerator
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# Assuming you have a custom function to load sequence data and corresponding targets
def create_sequence_generator(data, targets, length, batch_size):
    return TimeseriesGenerator(data, targets, length=length, batch_size=batch_size)

# Load your traffic data
traffic_data = pd.read_csv('traffic-prediction-dataset.csv')

# Preprocess your data (example: assuming 'features' and 'labels' columns)
features = traffic_data.drop('labels', axis=1)  # Adjust based on your data structure
labels = traffic_data['labels']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.2, random_state=42)

# Standardize the data
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Reshape data for LSTM (adjust based on your input shape)
X_train_lstm = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 1))
X_test_lstm = np.reshape(X_test, (X_test.shape[0], X_test.shape[1], 1))

# Build LSTM model
lstm_model = Sequential()
lstm_model.add(LSTM(units=50, activation='relu', input_shape=(X_train_lstm.shape[1], 1)))
lstm_model.add(Dense(units=1, activation='sigmoid'))
lstm_model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Set up data generators with augmentation for image data (CNN)
img_datagen = ImageDataGenerator(
    rescale=1./255,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True
)

# Assuming you have specified image directories
train_img_dir = 'path_to_train_images'
valid_img_dir = 'path_to_valid_images'

# Assuming you have a custom function to load image data
train_img_gen = img_datagen.flow_from_directory(
    train_img_dir,
    target_size=(128, 128),
    batch_size=32,
    class_mode='binary'
)

valid_img_gen = img_datagen.flow_from_directory(
    valid_img_dir,
    target_size=(128, 128),
    batch_size=32,
    class_mode='binary'
)

# Assuming you have specified sequence lengths for TimeseriesGenerator
sequence_length = 10

# Create sequence data generators
train_seq_gen = create_sequence_generator(X_train_lstm, y_train, sequence_length, batch_size=32)
valid_seq_gen = create_sequence_generator(X_test_lstm, y_test, sequence_length, batch_size=32)

# Build hybrid LSTM-CNN model
lstm_cnn_model = Sequential()
lstm_cnn_model.add(lstm_model)
lstm_cnn_model.add(Conv2D(filters=32, kernel_size=(3, 3), activation='relu'))
lstm_cnn_model.add(MaxPooling2D(pool_size=(2, 2)))
lstm_cnn_model.add(Flatten())
lstm_cnn_model.add(Dense(units=1, activation='sigmoid'))

# Compile the combined model
lstm_cnn_model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Train the combined model
lstm_cnn_model.fit(
    x=[train_seq_gen, train_img_gen],
    epochs=10,
    batch_size=32,
    validation_data=([valid_seq_gen, valid_img_gen], y_test)
)
lstm_cnn_model.save('trafficPredictionIsPeak.h5')