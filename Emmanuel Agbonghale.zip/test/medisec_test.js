const MediSec = artifacts.require("./medisec.sol");

contract("MediSec", accounts => {
    it("Confirm initial deployment & constructor execution", async () => {
        const MediSecInstance = await MediSec.deployed();
        console.log(await MediSecInstance.methods);

        // Set value of 89
        // await simpleStorageInstance.set(89, { from: accounts[0] });
        await MediSecInstance.AddHospital("1234567890", "Mantle Castle", "Abuja", 
        { from: accounts[0]});

        // Get stored value
        // const storedData = await simpleStorageInstance.get.call();
        const adminAddress = await MediSecInstance.administrator.call();
        console.log(adminAddress)

        assert.equal(adminAddress, '0x2B0b2F530896201e1ffeF30d20a84945743a4FF6', "Admin Address Set Correctly");
    });

    it("")
});
