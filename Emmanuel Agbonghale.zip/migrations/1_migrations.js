var MyContract = artifacts.require("MediSec");

module.exports = function(deployer) {
  // deployment steps
  deployer.deploy(MyContract);
};

