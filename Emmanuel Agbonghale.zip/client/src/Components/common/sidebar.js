import React from "react";
import '../css/sidebar.css'
function Sidebar(){

    patients = this.props.patient_list;
    return <div className="sidebar">
        
    </div>
}