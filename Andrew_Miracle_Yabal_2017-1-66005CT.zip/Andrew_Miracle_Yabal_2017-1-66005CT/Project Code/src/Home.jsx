import React from 'react'
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div>
        <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
        <h1 className="text-4xl mb-8">Welcome to FUTMX Cert</h1>
        <div className="flex space-x-8">
          <Card title="University" to="/university"/>
          <Card title="Verifier" to="/verifier"/>
        </div>
      </div>
    </div>
  )
}

const Card = ({ title, to }) => {
    return (
        <Link to={to}>
            <div className="bg-white p-8 border rounded-md hover:shadow-lg transition duration-300 ease-in-out">
            <h2 className="text-2xl font-bold mb-4">{title}</h2>
            <p className="text-gray-600">Click to explore {title.toLowerCase()} features</p>
            </div>
        </Link>
    );
  };

export default Home