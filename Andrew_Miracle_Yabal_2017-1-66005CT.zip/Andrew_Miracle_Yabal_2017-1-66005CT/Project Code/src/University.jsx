import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {ethers} from 'ethers'
import abi from './abi/abi.json'

const University = () => {
  const [fileImg, setFileImg] = useState(null);
  const [ipfsHash, setIpfsHash] = useState('');
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    matricNo: '',
    gpa: '',
    department: '',
  });

  const sendFileToIPFS = async (e) => {
    e.preventDefault();

    if (fileImg) {
      try {
        setLoading(true);

        const formDataIpfs = new FormData();
        formDataIpfs.append('file', fileImg);

        const resFile = await axios.post("https://api.pinata.cloud/pinning/pinFileToIPFS", formDataIpfs, {
          headers: {
            'pinata_api_key': `3f08f2abfc296009b6ef`,
            'pinata_secret_api_key': `bbae2027e5124158982171fc23f9bbcf1d69947317844dfbaffb87270f65fff1`,
            'Content-Type': 'multipart/form-data',
          },
        });

        const ImgHash = `ipfs://${resFile.data.IpfsHash}`;
        setIpfsHash(ImgHash);
        console.log(ImgHash);

        // Reset file input after successful upload
        setFileImg(null);

        // Handle further actions if needed

      } catch (error) {
        console.log('Error sending File to IPFS: ');
        console.log(error);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Check if a document is uploaded
    if (!ipfsHash) {
      console.log('Please upload a document before submitting.');
      return;
    }


    if(!connected) return alert("Please connect wallet")

    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner()
    const contract = new ethers.Contract("0x5b3A4Ea1de40b5587dc0D1e0C2dCf4272f0bc335", abi, signer)

    const tx = await contract.addStudent(formData.name, formData.matricNo, formData.gpa, formData.department, ipfsHash)
    console.log("tx: ", tx);

    await tx.wait()
    log("saved!")



    // Optionally, reset form data and IPFS hash after submission
    setFormData({
      name: '',
      matricNo: '',
      gpa: '',
      department: '',
    });
    setIpfsHash('');
  };

    // a flag for keeping track of whether or not a user is connected
    const [connected, setConnected] = useState(false);

    // handler for when user switch from one account to another or completely disconnected
    const handleAccountChanged = async (accounts) => {
      if(!!accounts.length) {
        const networkId = await window.ethereum.request({method: "eth_chainId"})
        if(Number(networkId) !== 5) return alert("You are connected to the wrong network, please switch to goerli")
        setConnected(true)
      }else {
        setConnected(false)
      }
    }
  
    // handler for handling chain/network changed
    const handleChainChanged = async (chainid) => {
      if(Number(chainid) !== 5) {
        setConnected(false)
        
        return alert("You are connected to the wrong network, please switch to goerli")
      }else {
        const provider = new ethers.BrowserProvider(window.ethereum);
        const accounts = await provider.listAccounts();
        if(!accounts.length) return
        setConnected(true)
        }
    }
  
    // an handler to eagerly connect user and fetch their data
    const eagerConnect = async () => {
      const networkId = await window.ethereum.request({method: "eth_chainId"})
      if(Number(networkId) !== 5) return
      const provider = new ethers.BrowserProvider(window.ethereum);
      const accounts = await provider.listAccounts();
      if(!accounts.length) return
      setConnected(true)
    }
  
    useEffect(() => {
      if(!window.ethereum) return;

      eagerConnect()
      window.ethereum.on("accountsChanged", handleAccountChanged)
      window.ethereum.on('chainChanged', handleChainChanged);

      return () => {
              // binding handlers to wallet events we care about
      window.ethereum.removeListener("accountsChanged", handleAccountChanged)
      window.ethereum.removeListener('chainChanged', handleChainChanged);
      }
    }, [])
  
    const connectWallet = async () => {
      if(!!window.ethereum || !!window.web3) {
        await window.ethereum.request({method: "eth_requestAccounts"})
      } else {
        alert("please use an etherum enabled browser");
      }
    }

  return (
    <div className="flex items-center justify-center h-screen text-black">
      <div className="absolute top-0 right-0 m-4">
      {connected ? <span className='bg-green-700 text-white px-4 py-2 rounded-md'>Connected</span>
      :
        <button onClick={connectWallet} className="bg-purple-700 text-white px-4 py-2 rounded-md hover:bg-purple-600">
          Connect wallet
        </button>
      }
    </div>

      <form onSubmit={sendFileToIPFS} className="max-w-md p-8 bg-white rounded-md shadow-lg overflow-y-auto max-h-screen">
        <h2 className="text-3xl font-bold mb-6 text-purple-700">Upload Student Certificate</h2>
        <div className="mb-4">
          <label htmlFor="fileImg" className="block text-sm font-medium text-gray-700">Upload Image:</label>
          <input type="file" id="fileImg" onChange={(e) => setFileImg(e.target.files[0])} className="mt-1 p-2 w-full border rounded-md" required />
        </div>
        <button type='submit' className="bg-purple-700 text-white px-4 py-2 rounded-md hover:bg-purple-800">
          {loading ? 'Uploading...' : 'Upload'}
        </button>
        {ipfsHash && (
          <div className="mt-4">
            <p className="text-sm font-medium text-gray-700">IPFS Hash:</p>
            <p className="text-lg font-semibold text-purple-700">{ipfsHash}</p>
          </div>
        )}
      </form>

      <form onSubmit={handleSubmit} className="max-w-md p-8 bg-white rounded-md shadow-lg mt-8">
        <h2 className="text-3xl font-bold mb-6 text-purple-700">Submit Student Information</h2>
        <div className="mb-4">
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name:</label>
          <input type="text" id="name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="mt-1 p-2 w-full border rounded-md" required />
        </div>
        <div className="mb-4">
          <label htmlFor="matricNo" className="block text-sm font-medium text-gray-700">Matric No.:</label>
          <input type="text" id="matricNo" value={formData.matricNo} onChange={(e) => setFormData({ ...formData, matricNo: e.target.value })} className="mt-1 p-2 w-full border rounded-md" required />
        </div>
        <div className="mb-4">
          <label htmlFor="department" className="block text-sm font-medium text-gray-700">Department:</label>
          <input type="text" id="department" value={formData.department} onChange={(e) => setFormData({ ...formData, department: e.target.value })} className="mt-1 p-2 w-full border rounded-md" required />
        </div>
        <div className="mb-4">
          <label htmlFor="gpa" className="block text-sm font-medium text-gray-700">GPA:</label>
          <input type="text" id="gpa" value={formData.gpa} onChange={(e) => setFormData({ ...formData, gpa: e.target.value })} className="mt-1 p-2 w-full border rounded-md" required />
        </div>
        <button type='submit' className={`bg-purple-700 text-white px-4 py-2 rounded-md hover:bg-purple-800 ${!ipfsHash && 'cursor-not-allowed opacity-50'}`} disabled={!ipfsHash}>
          Submit
        </button>
      </form>
    </div>
  );
};

export default University;
