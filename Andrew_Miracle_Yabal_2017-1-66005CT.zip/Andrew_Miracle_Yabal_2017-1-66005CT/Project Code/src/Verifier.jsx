import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {ethers} from 'ethers'
import abi from './abi/abi.json'

const toIpfsToHttp = (uri) => {
  const hash = uri.match(/^ipfs:(\/\/)?(.*)$/i)?.[2];
  return `https://ipfs.io/ipfs/${hash}/`
};


const Verifier = () => {
  const [verificationCode, setVerificationCode] = useState('');
  const [isVerified, setIsVerified] = useState(false);
  const [studentData, setStudentData] = useState(null);

  useEffect(() => {
    // Fetch additional student data when verification is successful
    if (isVerified) {
      // Replace this with your API endpoint or data fetching logic
      axios.get(`YOUR_API_ENDPOINT/${verificationCode}`)
        .then((response) => {
          setStudentData(response.data);
        })
        .catch((error) => {
          console.error('Error fetching student data:', error);
        });
    }
  }, [isVerified, verificationCode]);

  const handleVerify = async () => {
    if (verificationCode.trim() !== '') {
      
      const provider = new ethers.JsonRpcProvider("https://goerli.chainnodes.org/020840d0-0847-4443-9047-08f051452cde")
      const contract = new ethers.Contract("0x5b3A4Ea1de40b5587dc0D1e0C2dCf4272f0bc335", abi, provider)
      const data = await contract.getStudent(verificationCode);
      const dataArray = data.toArray()

    if(dataArray[0]==='')return alert("no record found!")

      setStudentData({
        matricNo: verificationCode,
        name: dataArray[0],
        gpa: dataArray[2],
        department: dataArray[3],
        imageUrl: toIpfsToHttp(dataArray[4]),
      })

      setIsVerified(true);
    }
  };

  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">
      <div className="bg-white p-8 rounded-md shadow-lg">
        <h2 className="text-3xl font-bold mb-6 text-purple-700">Student Information</h2>
        {!isVerified ? (
          // Display this content if verification is not successful or field is empty
          <>
            <div className="mb-4">
              <label htmlFor="verificationCode" className="block text-sm font-medium text-gray-700">
                Student Unique ID:
              </label>
              <input
                type="text"
                id="verificationCode"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value)}
                className="mt-1 p-2 w-full border rounded-md"
                placeholder="Enter Student ID"
                required
              />
            </div>
            <button
              onClick={handleVerify}
              className="bg-purple-700 text-white px-4 py-2 rounded-md hover:bg-purple-800"
            >
              Verify
            </button>
          </>
        ) : (
          // Display this content if verification is successful and field is not empty
          <>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">Student Information:</label>
              <div className="mt-2">
                <p><span className="font-bold">Name:</span> {studentData?.name}</p>
                <p><span className="font-bold">Matric No:</span> {studentData?.matricNo}</p>
                <p><span className="font-bold">Department:</span> {studentData?.department}</p>
                <p><span className="font-bold">GPA:</span> {studentData?.gpa}</p>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Student Image:</label>
              <img
                src={studentData.imageUrl}
                alt="Student Image"
                className="mt-2 max-w-full h-auto"
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Verifier;
