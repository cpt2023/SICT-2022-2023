import React from 'react'

const Student = () => {
  return (
    <div>Student</div>
  )
}

export default Student