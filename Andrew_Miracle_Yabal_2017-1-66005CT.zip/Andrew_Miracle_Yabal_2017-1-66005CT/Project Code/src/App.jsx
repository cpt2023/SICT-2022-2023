import './App.css'
import { BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import Home from './Home';
import University from './University';
import Student from './Student';
import Verifier from './Verifier';

function App() {



  return (
    <>
    <Router>
      <Routes>
        <Route exact path="/" element={<Home />} />
        <Route path="/university" element={<University />} />
        <Route path="/student" element={<Student />} />
        <Route path="/verifier" element={<Verifier />} />
      </Routes>
    </Router>
    </>
  )
}


export default App;
