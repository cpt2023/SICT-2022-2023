require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config();

module.exports = {
  solidity: "0.8.0",
  networks: {
    goerli: {
      url: 'https://goerli.chainnodes.org/020840d0-0847-4443-9047-08f051452cde',
      accounts: ['0x9830bdb85209e34046f748e52b90aebecbc3332f4ef7955cb8f6ede9ed46b875'],
      gas: 2100000,
      gasPrice: 8000000000,
      saveDeployments: true,
    },
  }
};