async function main() {
  const signers = await ethers.getSigners()
  console.log("signers:", signers)
  const StudentVerification = await ethers.getContractFactory("StudentVerification");
  console.log("Deploying StudentVerification...");
  const studentVerification = await StudentVerification.deploy();
  await studentVerification.waitForDeployment();

  console.log("StudentVerification deployed to:", studentVerification.target);
}

main()
  .then(() => process.exit(0))
  .catch(error => {
    console.error(error);
    process.exit(1);
  });
