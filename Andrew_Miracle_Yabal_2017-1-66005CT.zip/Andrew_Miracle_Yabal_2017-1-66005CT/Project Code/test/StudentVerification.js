import { expect } from "chai";

describe("StudentVerification Contract", function () {
  let StudentVerification;
  let studentVerification;
  let owner;

  beforeEach(async () => {
    [owner] = await ethers.getSigners(); // Get the first account as the owner
    StudentVerification = await ethers.getContractFactory("StudentVerification");
    studentVerification = await StudentVerification.deploy();
    await studentVerification.waitForDeployment();
  });

  it("Should add a student and emit StudentAdded event", async function () {
    const name = "John Doe";
    const matricNo = "12345";
    const gpa = "3.5";
    const department = "Computer Science";
    const ipfsHash = "Qmabcdef1234567890";

    await expect(studentVerification.connect(owner).addStudent(name, matricNo, gpa, department, ipfsHash))
      .to.emit(studentVerification, "StudentAdded")
      .withArgs(owner.address, name, matricNo, gpa, department, ipfsHash);

    const student = await studentVerification.getStudent();
    expect(student.name).to.equal(name);
    expect(student.matricNo).to.equal(matricNo);
    expect(student.gpa).to.equal(gpa);
    expect(student.department).to.equal(department);
    expect(student.ipfsHash).to.equal(ipfsHash);
  });

  it("Should get student details", async function () {
    const name = "Jane Doe";
    const matricNo = "54321";
    const gpa = "4.0";
    const department = "Electrical Engineering";
    const ipfsHash = "Qmabcdef0987654321";

    await studentVerification.connect(owner).addStudent(name, matricNo, gpa, department, ipfsHash);

    const student = await studentVerification.getStudent();
    expect(student.name).to.equal(name);
    expect(student.matricNo).to.equal(matricNo);
    expect(student.gpa).to.equal(gpa);
    expect(student.department).to.equal(department);
    expect(student.ipfsHash).to.equal(ipfsHash);
  });
});
