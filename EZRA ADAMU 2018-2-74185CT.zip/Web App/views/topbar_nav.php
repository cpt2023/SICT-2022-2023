<nav class="navbar">
   <a href="#" class="sidebar-toggler">
      <i data-feather="menu"></i>
   </a>
   <div class="navbar-content">
      
   </div>
</nav>