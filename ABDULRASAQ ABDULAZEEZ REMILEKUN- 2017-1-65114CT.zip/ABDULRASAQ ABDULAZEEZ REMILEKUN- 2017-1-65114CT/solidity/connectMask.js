


require ("web3");
import { Abi, contractAdd } from "./KYCBlockchain-master/mykyc/public/data.js";


let account;
const connectbu = document.getElementById("");
connectmask.onclick = connect;
const connectmask = async () => {
  
  if(window.ethereum!=="undefined"){
    const accounts= await ethereum.request({method:"eth_requestAccounts"});
    account=accounts[0];
    //await alert("your account address is",account);
    //document.getElementById("acc").innerHTML=account;
    //conection to contract start from here
    const Address = contractAdd;//note the  his address is contract address after deployment
    const abi = Abi;
   window.web3 = await new Web3(window.ethereum);
   window.contract= await new window.web3.eth.Contract(Abi,Address);
    
  document.getElementById("contract").innerHTML="connected to smart contract";
  
  //window.location.assign("customer.html")
  
//   const retData1= await window.contract.methods.regUdata(Email,Pass).send({from:account});
//    alert("Details added sucessful");
//document.write ("<h5 class='alert alert-danger'>$email already exist, choose another email...</h5>");

  
 }
}