const express = require("express");
const path = require("path");
const app = express();

app.get('/',function(req,res) {
	res.sendFile(path.join(__dirname+"/KYCBlockchain-master/mykyc/public/home.html"));
});
app.get('/business',function(req,res) {
	res.sendFile(path.join(__dirname+"/KYCBlockchain-master/mykyc/public/business.html"));
});
app.get('/customer',function(req,res) {
	res.sendFile(path.join(__dirname+"/KYCBlockchain-master/mykyc/public/customer.html"));
});
app.get('/boot',function(req,res) {
	res.sendFile(path.join(__dirname+"/bootstrap-icons/envelope-fill.svg"));
});
const server = app.listen(5000);
const portNumber = server.address().port;
console.log("server:",portNumber);