from solcx import compile_standard, install_solc
from web3 import Web3
import os
from dotenv import load_dotenv
import json

compiler_version = "0.8.21"
install_solc(compiler_version)
with open("lesson3.sol", "r") as file:
    myfile = file.read()
# print(myfile)
MyCompilier = compile_standard(
    {
        "language": "Solidity",
        "sources": {"lesson3.sol": {"content": myfile}},
        "settings": {
            "outputSelection": {
                "*": {"*": ["abi", "metadata", "evm.bytecode", "evm.sourceMap"]}
            }
        },
    },
    solc_version=compiler_version,
)
with open("compiled_data.json", "w") as file:
    json.dump(MyCompilier, file)
# we need to access abi and bytecode
Abi = MyCompilier["contracts"]["lesson3.sol"]["KYC"]["abi"]
ByteCode = MyCompilier["contracts"]["lesson3.sol"]["KYC"]["evm"]["bytecode"]["object"]
# print(ByteCode)
# working with local seerver that's gaanache to connect to ganache we need to get
# 1 chain_id,2 http 3 address 4 private key,5 nonce
# hhow to connect to alchemy chain
# Setup
"""from web3 import Web3

alchemy_url = "https://eth-mainnet.g.alchemy.com/v2/PVlrN7Olx1EhbPsGaifzf--2JlBcBNZV"
w3 = Web3(Web3.HTTPProvider(alchemy_url))

# Print if web3 is successfully connected
print(w3.isConnected())

# Get the latest block number
latest_block = w3.eth.get_block("latest")
print(latest_block)"""

Provider = Web3(Web3.HTTPProvider("HTTP://127.0.0.1:8545"))
print(Provider.is_connected())
chain_id = 5
MYAddress = "0xFFcf8FDEE72ac11b5c542428B35EEF5769C409f0"
mynonce = Provider.eth.get_transaction_count(MYAddress)
MyPrivateKey = "0x6cbed15c793ce57650b9877cf6fa156fbef513c4e6134f022a85b1ffdd59b2a1"  # os.getenv("PRIVATE_KEY")
print(MYAddress)
# To build transaction we need to first create contract
createContract = Provider.eth.contract(abi=Abi, bytecode=ByteCode)
myvalue = Provider.to_wei(1, "ether")
GasPrice = Provider.eth.gas_price
GasLimit = 366119
Mytransaction = createContract.constructor()._build_transaction(
    {
        "from": MYAddress,
        "nonce": mynonce,
        "gasPrice": GasPrice,
        "gas": GasLimit,
        "value": myvalue,
    }
)
print(Mytransaction)
# To sign transaction
signTxn = Provider.eth.account.sign_transaction(Mytransaction, private_key=MyPrivateKey)
print(signTxn)
# To send transaction
print("going to send")
sendTxN = Provider.eth.send_raw_transaction(signTxn.rawTransaction)
waitTxn = Provider.eth.wait_for_transaction_receipt(sendTxN)
accessCont = Provider.eth.contract(address=waitTxn.contractAddress, abi=Abi)
tra = accessCont.functions.reportBank(
    "0x22d491Bde2303f2f43325b2108D26f1eAbA1e32b0x22d491Bde2303f2f43325b2108D26f1eAbA1e32b"
)._transact
print(tra)
print("hello world")
# alchemy api
# PVlrN7Olx1EhbPsGaifzf--2JlBcBNZV
# alchemyhttp
# https://eth-mainnet.g.alchemy.com/v2/PVlrN7Olx1EhbPsGaifzf--2JlBcBNZV
# alchemy websocket
# wss://eth-mainnet.g.alchemy.com/v2/PVlrN7Olx1EhbPsGaifzf--2JlBcBNZV

# to interact with the  contract
# mycontract=createContract.contracts.functions.CheckBal().c


"""from solcx import compile_standard,install_solc
import json
from dotenv import load_dotenv
load_dotenv()
import os
from  web3 import Web3
_SolVersion="0.8.21"
install_solc(_SolVersion)
with open("./lesson3.sol","r") as file:
    mySolFile=file.read()
    #print(mySolFile)
MyCompilier=compile_standard(
    {
        "language":"Solidity",
        "sources":{"lesson3.sol":{"content":mySolFile}},
        "settings":{"outputSelection":{"*":{"*":["abi","metadata","evm.bytecode","evm.sourceMap"]}}},
    },
    solc_version=_SolVersion
)
#print(MyCompilier)
with open("SolfileToJson.json","w") as file:
    json.dump(MyCompilier,file)
    # to get the bytecode compile name->contracts->filename.sol->contractname->evm->bytecode->object
bytecode=MyCompilier["contracts"]["lesson3.sol"]["TransferFund"]["evm"]["bytecode"]["object"]
# to get the Abi
abi=MyCompilier["contracts"]["lesson3.sol"]["TransferFund"]["abi"]
 #For connecting to ganache
Private_Key=os.getenv("PRIVATE_KEY")
HTTP_provider=Web3(Web3.HTTPProvider("HTTP://127.0.0.1:7545"))
Chain_id=5777
MY_Address="0xe4d3b8a9F2FDf5b6217F8D231CD424BE397Bc169"
#print(Private_Key)
#to create contract in python// be mindful that lesson3 and HTTP_Povider are just variable not built-in variable
lesson3=HTTP_provider.eth.contract(abi=abi,bytecode=bytecode)
#print(lesson3)
get_nonce=HTTP_provider.eth.get_transaction_count(MY_Address)
#print(get_nonce)
#To build transction
d_recipent="0xcb8F4311AC0eF218A8B2559E8a41B09ACa74cB49"
gasPrice=HTTP_provider.eth.gas_price
gasLimit=366119
value=HTTP_provider.to_wei(1,"ether")
Mytransaction=lesson3.constructor()._build_transaction({"from":MY_Address,"nonce":get_nonce,"gas":gasLimit,"gasPrice":gasPrice,"value":value})
#print(Mytransaction)
# To Sign transaction

SignMyTxn=HTTP_provider.eth.account.sign_transaction(Mytransaction,private_key=Private_Key)
#print(SignMyTxn)
sendTxn=HTTP_provider.eth.send_raw_transaction(SignMyTxn.rawTransaction)
 """
