const { error } = require("console");
const process = require("process");
const Web3=require("web3");
require("dotenv").config();
const { ethers,JsonRpcProvider} = require("ethers");
const fs = require("fs-extra");
const { ContractFactory } = require("ethers");
const my_address = process.env.ADDRESS;
const Private_key = process.env.PRIVATE_KEY;
 async function main() {
    console.log("hello world");
     const provider = new JsonRpcProvider("http:127.0.0.1:8545");
        // JsonRpcProvider("http:127.0.0.1:8545");
     const wallet = new ethers.Wallet(Private_key, provider);
     const abi = fs.readFileSync("./spyKyc_sol_Kyc.abi", "utf8");
     const bin = fs.readFileSync("./spyKyc_sol_Kyc.bin", "utf8");
    console.log(abi);
      const contractFac = new ethers.ContractFactory(abi, bin, wallet);
      console.log("deploying please wait...");
      const contract = await contractFac.deploy();
      console.log(contract);
      const deployReceipt = await contract.deploymentTransaction().wait(0);
      
      console.log("this is the transaction Receipt:");
      console.log(deployReceipt);
    //  to access functionin in my solidity code
     console.log("going to get contract" )
   // const getdata = await contract.greet("good morning");

     //console.log(getdata);

     
     
//      const nonce = await wallet.getNonce();
//      const tx = {
//          nonce: nonce,
//            gasPrice: 20000000000  ,
//           gasLimit: 6721975,
//             to:"0x6Ba4B3719Abac21d992fd3a7EdD77ae76aa37bad",
//            value: 0,
   
//           chainId: 1337,
//        };
//        const signedTxn = await wallet.signTransaction(tx);
   
//        const sendTxn = await wallet.sendTransaction(tx);
//        await sendTxn.wait(1);
//        console.log(signedTxn);
//      console.log(sendTxn);

   

 }
main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
            
    });


    